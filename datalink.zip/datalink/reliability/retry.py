from typing import Dict, Any, Optional, Callable, Type, List
import asyncio
from datetime import datetime
from logging import Logger
import random

class RetryStrategy:
    """重试策略"""
    def __init__(self, logger: Logger,
                 max_attempts: int = 3,
                 initial_delay: float = 1.0,
                 max_delay: float = 30.0,
                 exponential_base: float = 2.0,
                 jitter: bool = True):
        self.logger = logger
        self.max_attempts = max_attempts
        self.initial_delay = initial_delay
        self.max_delay = max_delay
        self.exponential_base = exponential_base
        self.jitter = jitter
        self.retryable_exceptions: List[Type[Exception]] = []

    def register_exception(self, exception: Type[Exception]):
        """注册可重试异常"""
        if exception not in self.retryable_exceptions:
            self.retryable_exceptions.append(exception)

    def should_retry(self, exception: Exception) -> bool:
        """判断是否应该重试"""
        return any(
            isinstance(exception, ex_type)
            for ex_type in self.retryable_exceptions
        )

    async def execute(self, func: Callable, *args, **kwargs):
        """执行带重试的操作"""
        attempt = 1
        last_exception = None

        while attempt <= self.max_attempts:
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                if not self.should_retry(e):
                    raise

                if attempt < self.max_attempts:
                    delay = self._calculate_delay(attempt)
                    self.logger.warning(
                        f"Retry attempt {attempt}/{self.max_attempts} "
                        f"after {delay:.2f}s due to {type(e).__name__}",
                        exc_info=True
                    )
                    await asyncio.sleep(delay)
                    attempt += 1
                else:
                    break

        raise MaxRetriesExceeded(
            f"Max retries ({self.max_attempts}) exceeded"
        ) from last_exception

    def _calculate_delay(self, attempt: int) -> float:
        """计算重试延迟"""
        delay = min(
            self.initial_delay * (self.exponential_base ** (attempt - 1)),
            self.max_delay
        )
        
        if self.jitter:
            delay = random.uniform(0, delay)
            
        return delay

class MaxRetriesExceeded(Exception):
    """超过最大重试次数异常"""
    pass
