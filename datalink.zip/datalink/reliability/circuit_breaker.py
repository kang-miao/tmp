from typing import Dict, Any, Optional, Callable
import asyncio
from datetime import datetime, timedelta
from enum import Enum
from logging import Logger

class CircuitState(Enum):
    """熔断器状态"""
    CLOSED = "closed"      # 正常状态
    OPEN = "open"         # 熔断状态
    HALF_OPEN = "half_open"  # 半开状态

class CircuitBreaker:
    """熔断器"""
    def __init__(self, logger: Logger, name: str,
                 failure_threshold: int = 5,
                 recovery_timeout: int = 60,
                 half_open_timeout: int = 30):
        self.logger = logger
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_timeout = timedelta(seconds=recovery_timeout)
        self.half_open_timeout = timedelta(seconds=half_open_timeout)
        
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.last_failure_time: Optional[datetime] = None
        self.last_state_change: datetime = datetime.now()
        
        self._lock = asyncio.Lock()
        self._stats = {
            'success_count': 0,
            'failure_count': 0,
            'rejection_count': 0
        }

    async def execute(self, func: Callable, *args, **kwargs):
        """执行受保护的操作"""
        async with self._lock:
            if not self._can_execute():
                self._stats['rejection_count'] += 1
                raise CircuitBreakerError(
                    f"Circuit {self.name} is {self.state.value}"
                )

        try:
            result = await func(*args, **kwargs)
            await self._on_success()
            return result
        except Exception as e:
            await self._on_failure(e)
            raise

    async def _on_success(self):
        """处理成功"""
        async with self._lock:
            self._stats['success_count'] += 1
            if self.state == CircuitState.HALF_OPEN:
                await self._close_circuit()

    async def _on_failure(self, error: Exception):
        """处理失败"""
        async with self._lock:
            self._stats['failure_count'] += 1
            self.failure_count += 1
            self.last_failure_time = datetime.now()

            if self.state == CircuitState.CLOSED:
                if self.failure_count >= self.failure_threshold:
                    await self._open_circuit()
            elif self.state == CircuitState.HALF_OPEN:
                await self._open_circuit()

    def _can_execute(self) -> bool:
        """检查是否可以执行"""
        if self.state == CircuitState.CLOSED:
            return True
        elif self.state == CircuitState.OPEN:
            if datetime.now() - self.last_state_change >= self.recovery_timeout:
                self.state = CircuitState.HALF_OPEN
                self.last_state_change = datetime.now()
                self.logger.info(
                    f"Circuit {self.name} switched to half-open"
                )
                return True
            return False
        elif self.state == CircuitState.HALF_OPEN:
            return True
        return False

    async def _open_circuit(self):
        """开启熔断"""
        self.state = CircuitState.OPEN
        self.last_state_change = datetime.now()
        self.logger.warning(
            f"Circuit {self.name} opened due to failures"
        )

    async def _close_circuit(self):
        """关闭熔断"""
        self.state = CircuitState.CLOSED
        self.last_state_change = datetime.now()
        self.failure_count = 0
        self.logger.info(
            f"Circuit {self.name} closed after recovery"
        )

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return {
            'name': self.name,
            'state': self.state.value,
            'failure_count': self.failure_count,
            'last_failure': self.last_failure_time.isoformat() 
                if self.last_failure_time else None,
            'last_state_change': self.last_state_change.isoformat(),
            **self._stats
        }

class CircuitBreakerError(Exception):
    """熔断器错误"""
    pass
