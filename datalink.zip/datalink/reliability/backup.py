from typing import Dict, Any, Optional, List
from pathlib import Path
import asyncio
import json
import shutil
from datetime import datetime
from logging import Logger
import aiofiles
import aiofiles.os
import asyncpg

class BackupManager:
    """备份管理器"""
    def __init__(self, logger: Logger, backup_dir: Path):
        self.logger = logger
        self.backup_dir = backup_dir
        self.backup_dir.mkdir(parents=True, exist_ok=True)

    async def create_backup(self, data: Dict[str, Any],
                          backup_type: str) -> str:
        """创建备份"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_id = f"{backup_type}_{timestamp}"
        backup_path = self.backup_dir / f"{backup_id}.json"

        try:
            async with aiofiles.open(backup_path, 'w') as f:
                await f.write(json.dumps({
                    'backup_id': backup_id,
                    'backup_type': backup_type,
                    'timestamp': datetime.now().isoformat(),
                    'data': data
                }, indent=2))

            self.logger.info(
                f"Created backup: {backup_id}",
                extra={'backup_path': str(backup_path)}
            )
            return backup_id

        except Exception as e:
            self.logger.error(
                f"Failed to create backup: {str(e)}",
                exc_info=True
            )
            raise

    async def restore_backup(self, backup_id: str) -> Dict[str, Any]:
        """恢复备份"""
        backup_path = self.backup_dir / f"{backup_id}.json"

        try:
            if not backup_path.exists():
                raise FileNotFoundError(f"Backup not found: {backup_id}")

            async with aiofiles.open(backup_path, 'r') as f:
                content = await f.read()
                backup_data = json.loads(content)

            self.logger.info(
                f"Restored backup: {backup_id}",
                extra={'backup_path': str(backup_path)}
            )
            return backup_data['data']

        except Exception as e:
            self.logger.error(
                f"Failed to restore backup: {str(e)}",
                exc_info=True
            )
            raise

    async def list_backups(self, backup_type: Optional[str] = None
                          ) -> List[Dict[str, Any]]:
        """列出备份"""
        backups = []
        for backup_file in self.backup_dir.glob('*.json'):
            try:
                async with aiofiles.open(backup_file, 'r') as f:
                    content = await f.read()
                    backup_data = json.loads(content)
                    
                if (backup_type is None or
                        backup_data['backup_type'] == backup_type):
                    backups.append({
                        'backup_id': backup_data['backup_id'],
                        'backup_type': backup_data['backup_type'],
                        'timestamp': backup_data['timestamp'],
                        'size': backup_file.stat().st_size
                    })
            except Exception as e:
                self.logger.error(
                    f"Error reading backup {backup_file}: {str(e)}",
                    exc_info=True
                )

        return sorted(
            backups,
            key=lambda x: x['timestamp'],
            reverse=True
        )

    async def delete_backup(self, backup_id: str):
        """删除备份"""
        backup_path = self.backup_dir / f"{backup_id}.json"

        try:
            if not backup_path.exists():
                raise FileNotFoundError(f"Backup not found: {backup_id}")

            await aiofiles.os.remove(backup_path)
            self.logger.info(
                f"Deleted backup: {backup_id}",
                extra={'backup_path': str(backup_path)}
            )

        except Exception as e:
            self.logger.error(
                f"Failed to delete backup: {str(e)}",
                exc_info=True
            )
            raise

class DatabaseBackup:
    """数据库备份"""
    def __init__(self, logger: Logger, backup_dir: Path,
                 db_config: Dict[str, Any]):
        self.logger = logger
        self.backup_dir = backup_dir
        self.db_config = db_config
        self.backup_dir.mkdir(parents=True, exist_ok=True)

    async def create_backup(self) -> str:
        """创建数据库备份"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_file = self.backup_dir / f"db_backup_{timestamp}.sql"

        try:
            # 使用pg_dump创建备份
            process = await asyncio.create_subprocess_exec(
                'pg_dump',
                '-h', self.db_config['host'],
                '-p', str(self.db_config['port']),
                '-U', self.db_config['user'],
                '-d', self.db_config['database'],
                '-f', str(backup_file),
                env={'PGPASSWORD': self.db_config['password']}
            )
            
            await process.wait()
            
            if process.returncode == 0:
                self.logger.info(
                    f"Created database backup: {backup_file.name}"
                )
                return backup_file.name
            else:
                raise Exception("Database backup failed")

        except Exception as e:
            self.logger.error(
                f"Failed to create database backup: {str(e)}",
                exc_info=True
            )
            raise

    async def restore_backup(self, backup_file: str):
        """恢复数据库备份"""
        backup_path = self.backup_dir / backup_file

        try:
            if not backup_path.exists():
                raise FileNotFoundError(
                    f"Backup file not found: {backup_file}"
                )

            # 使用psql恢复备份
            process = await asyncio.create_subprocess_exec(
                'psql',
                '-h', self.db_config['host'],
                '-p', str(self.db_config['port']),
                '-U', self.db_config['user'],
                '-d', self.db_config['database'],
                '-f', str(backup_path),
                env={'PGPASSWORD': self.db_config['password']}
            )
            
            await process.wait()
            
            if process.returncode == 0:
                self.logger.info(
                    f"Restored database from backup: {backup_file}"
                )
            else:
                raise Exception("Database restore failed")

        except Exception as e:
            self.logger.error(
                f"Failed to restore database: {str(e)}",
                exc_info=True
            )
            raise
