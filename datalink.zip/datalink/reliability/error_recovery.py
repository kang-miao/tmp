from typing import Dict, Any, Optional, Callable, Type
import asyncio
from datetime import datetime
from logging import Logger
from enum import Enum

class RecoveryStrategy(Enum):
    """恢复策略"""
    RETRY = "retry"
    FALLBACK = "fallback"
    RESET = "reset"
    IGNORE = "ignore"

class ErrorContext:
    """错误上下文"""
    def __init__(self, error: Exception, operation: str,
                 details: Dict[str, Any]):
        self.error = error
        self.operation = operation
        self.timestamp = datetime.now()
        self.details = details
        self.recovery_attempts = 0
        self.recovered = False

class ErrorRecoveryManager:
    """错误恢复管理器"""
    def __init__(self, logger: Logger):
        self.logger = logger
        self.recovery_handlers: Dict[Type[Exception], Callable] = {}
        self.error_history: List[ErrorContext] = []
        self.max_history = 1000

    async def handle_error(self, error: Exception, operation: str,
                          details: Dict[str, Any]) -> bool:
        """处理错误"""
        context = ErrorContext(error, operation, details)
        self.error_history.append(context)
        self._trim_history()

        try:
            # 查找对应的处理器
            handler = self._find_handler(error)
            if handler:
                context.recovered = await handler(context)
                return context.recovered
            else:
                self.logger.warning(
                    f"No recovery handler for {type(error).__name__}",
                    extra={'operation': operation}
                )
                return False

        except Exception as e:
            self.logger.error(
                f"Error during recovery: {str(e)}",
                exc_info=True,
                extra={'operation': operation}
            )
            return False

    def register_handler(self, error_type: Type[Exception],
                        handler: Callable):
        """注册错误处理器"""
        self.recovery_handlers[error_type] = handler
        self.logger.info(
            f"Registered recovery handler for {error_type.__name__}"
        )

    def _find_handler(self, error: Exception) -> Optional[Callable]:
        """查找错误处理器"""
        for error_type, handler in self.recovery_handlers.items():
            if isinstance(error, error_type):
                return handler
        return None

    def _trim_history(self):
        """清理历史记录"""
        if len(self.error_history) > self.max_history:
            self.error_history = self.error_history[-self.max_history:]

    def get_error_stats(self) -> Dict[str, Any]:
        """获取错误统计"""
        stats = {}
        for context in self.error_history:
            error_type = type(context.error).__name__
            if error_type not in stats:
                stats[error_type] = {
                    'count': 0,
                    'recovered': 0,
                    'failed': 0
                }
            stats[error_type]['count'] += 1
            if context.recovered:
                stats[error_type]['recovered'] += 1
            else:
                stats[error_type]['failed'] += 1
        return stats
