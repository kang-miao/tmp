-- schemas/tdengine/tables.sql

-- 创建数据库
CREATE DATABASE IF NOT EXISTS market_data KEEP 365 PRECISION 'ms';

-- 切换到市场数据库
USE market_data;

-- 交易数据超级表
CREATE STABLE IF NOT EXISTS trade_data (
    `ts`          TIMESTAMP,           -- 时间戳
    `price`       DOUBLE,              -- 价格
    `volume`      DOUBLE,              -- 数量
    `amount`      DOUBLE,              -- 金额
    `side`        NCHAR(4),            -- 买卖方向
    `trade_id`    NCHAR(64),           -- 交易ID
    `maker`       BOOL,                -- 是否maker
    `created_at`  TIMESTAMP            -- 数据创建时间
) TAGS (
    `market_type` NCHAR(20),           -- 市场类型
    `exchange`    NCHAR(20),           -- 交易所
    `symbol`      NCHAR(30)            -- 交易对
);

-- K线数据超级表
CREATE STABLE IF NOT EXISTS kline_data (
    `ts`          TIMESTAMP,           -- 时间戳
    `open`        DOUBLE,              -- 开盘价
    `high`        DOUBLE,              -- 最高价
    `low`         DOUBLE,              -- 最低价
    `close`       DOUBLE,              -- 收盘价
    `volume`      DOUBLE,              -- 成交量
    `amount`      DOUBLE,              -- 成交额
    `trade_count` INT,                 -- 成交笔数
    `created_at`  TIMESTAMP            -- 数据创建时间
) TAGS (
    `market_type` NCHAR(20),           -- 市场类型
    `exchange`    NCHAR(20),           -- 交易所
    `symbol`      NCHAR(30),           -- 交易对
    `interval`    NCHAR(10)            -- K线周期
);

-- 订单簿快照超级表
CREATE STABLE IF NOT EXISTS order_book_data (
    `ts`          TIMESTAMP,           -- 时间戳
    `bid_price`   DOUBLE,              -- 买一价
    `bid_volume`  DOUBLE,              -- 买一量
    `ask_price`   DOUBLE,              -- 卖一价
    `ask_volume`  DOUBLE,              -- 卖一量
    `depth_data`  BINARY(2048),        -- 深度数据(JSON)
    `created_at`  TIMESTAMP            -- 数据创建时间
) TAGS (
    `market_type` NCHAR(20),           -- 市场类型
    `exchange`    NCHAR(20),           -- 交易所
    `symbol`      NCHAR(30)            -- 交易对
);

-- 市场指标超级表
CREATE STABLE IF NOT EXISTS market_metrics (
    `ts`          TIMESTAMP,           -- 时间戳
    `vwap`        DOUBLE,              -- 成交量加权平均价
    `bid_ask_spread` DOUBLE,           -- 买卖价差
    `depth_imbalance` DOUBLE,          -- 深度不平衡
    `volume_momentum` DOUBLE,          -- 成交量动量
    `price_momentum` DOUBLE,           -- 价格动量
    `created_at`  TIMESTAMP            -- 数据创建时间
) TAGS (
    `market_type` NCHAR(20),           -- 市场类型
    `exchange`    NCHAR(20),           -- 交易所
    `symbol`      NCHAR(30)            -- 交易对
);

-- 数据质量指标超级表
CREATE STABLE IF NOT EXISTS data_quality_metrics (
    `ts`          TIMESTAMP,           -- 时间戳
    `missing_rate` DOUBLE,             -- 数据缺失率
    `duplicate_rate` DOUBLE,           -- 数据重复率
    `delay`       DOUBLE,              -- 数据延迟(ms)
    `error_rate`  DOUBLE,              -- 错误率
    `created_at`  TIMESTAMP            -- 数据创建时间
) TAGS (
    `market_type` NCHAR(20),           -- 市场类型
    `exchange`    NCHAR(20),           -- 交易所
    `symbol`      NCHAR(30),           -- 交易对
    `data_type`   NCHAR(20)            -- 数据类型
);

-- 系统监控指标超级表
CREATE STABLE IF NOT EXISTS system_metrics (
    `ts`          TIMESTAMP,           -- 时间戳
    `cpu_usage`   DOUBLE,              -- CPU使用率
    `memory_usage` DOUBLE,             -- 内存使用率
    `disk_usage`  DOUBLE,              -- 磁盘使用率
    `net_in`      DOUBLE,              -- 网络入流量
    `net_out`     DOUBLE,              -- 网络出流量
    `created_at`  TIMESTAMP            -- 数据创建时间
) TAGS (
    `component`   NCHAR(30),           -- 组件名称
    `instance`    NCHAR(50)            -- 实例标识
);

-- 创建降采样规则
CREATE TABLE IF NOT EXISTS trade_data_1m 
    AS SELECT first(price) as open, max(price) as high, min(price) as low, 
              last(price) as close, sum(volume) as volume, sum(amount) as amount, 
              count(*) as trade_count
    FROM trade_data 
    INTERVAL(1m) 
    FILL(NONE);

CREATE TABLE IF NOT EXISTS trade_data_1h
    AS SELECT first(price) as open, max(price) as high, min(price) as low,
              last(price) as close, sum(volume) as volume, sum(amount) as amount,
              count(*) as trade_count
    FROM trade_data
    INTERVAL(1h)
    FILL(NONE);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_trade_id ON trade_data(trade_id);

-- 创建连续查询
CREATE TRIGGER trigger_update_metrics AFTER INSERT ON trade_data DO 
    INSERT INTO market_metrics 
    SELECT 
        ts,
        sum(price * volume) / sum(volume) as vwap,
        NULL as bid_ask_spread,
        NULL as depth_imbalance,
        sum(volume) - (LAG(sum(volume), 1) OVER w) as volume_momentum,
        last(price) - first(price) as price_momentum,
        NOW as created_at
    FROM trade_data
    WINDOW w AS (PARTITION BY market_type, exchange, symbol 
                ORDER BY ts RANGE '1h' PRECEDING);