-- schemas/risingwave/views.sql

-- 创建源表连接器 (Redpanda)
CREATE SOURCE IF NOT EXISTS trade_stream (
    market_type VARCHAR,
    exchange VARCHAR,
    symbol VARCHAR,
    timestamp TIMESTAMP,
    price DOUBLE PRECISION,
    volume DOUBLE PRECISION,
    amount DOUBLE PRECISION,
    side VARCHAR,
    trade_id VARCHAR,
    maker BOOLEAN
) WITH (
    connector = 'kafka',
    topic = 'trades.raw',
    properties.bootstrap.server = 'redpanda:9092',
    scan.startup.mode = 'latest'
) FORMAT PLAIN ENCODE JSON;

CREATE SOURCE IF NOT EXISTS order_book_stream (
    market_type VARCHAR,
    exchange VARCHAR,
    symbol VARCHAR,
    timestamp TIMESTAMP,
    bids ARRAY[ROW(price DOUBLE PRECISION, volume DOUBLE PRECISION)],
    asks ARRAY[ROW(price DOUBLE PRECISION, volume DOUBLE PRECISION)]
) WITH (
    connector = 'kafka',
    topic = 'orderbooks.raw',
    properties.bootstrap.server = 'redpanda:9092',
    scan.startup.mode = 'latest'
) FORMAT PLAIN ENCODE JSON;

-- 实时交易统计视图
CREATE MATERIALIZED VIEW IF NOT EXISTS mv_trade_stats AS
SELECT
    market_type,
    exchange,
    symbol,
    window_start AS timestamp,
    COUNT(*) AS trade_count,
    SUM(volume) AS total_volume,
    SUM(amount) AS total_amount,
    SUM(CASE WHEN side = 'buy' THEN volume ELSE 0 END) AS buy_volume,
    SUM(CASE WHEN side = 'sell' THEN volume ELSE 0 END) AS sell_volume,
    AVG(price) AS avg_price,
    STDDEV(price) AS price_std,
    MIN(price) AS min_price,
    MAX(price) AS max_price
FROM trade_stream
GROUP BY 
    market_type,
    exchange,
    symbol,
    HOP(timestamp, INTERVAL '1' MINUTE, INTERVAL '5' MINUTE);

-- 价格动量视图
CREATE MATERIALIZED VIEW IF NOT EXISTS mv_price_momentum AS
SELECT
    market_type,
    exchange,
    symbol,
    window_start AS timestamp,
    (last_value(price) OVER w - first_value(price) OVER w) / 
    first_value(price) OVER w AS price_momentum,
    (last_value(volume) OVER w - first_value(volume) OVER w) AS volume_momentum
FROM trade_stream
WINDOW w AS (
    PARTITION BY market_type, exchange, symbol
    ORDER BY timestamp
    RANGE INTERVAL '5' MINUTE PRECEDING
);

-- VWAP计算视图
CREATE MATERIALIZED VIEW IF NOT EXISTS mv_vwap AS
SELECT
    market_type,
    exchange,
    symbol,
    window_start AS timestamp,
    SUM(price * volume) / SUM(volume) AS vwap
FROM trade_stream
GROUP BY 
    market_type,
    exchange,
    symbol,
    HOP(timestamp, INTERVAL '10' SECOND, INTERVAL '1' MINUTE);

-- 订单簿深度分析视图
CREATE MATERIALIZED VIEW IF NOT EXISTS mv_order_book_analysis AS
SELECT
    market_type,
    exchange,
    symbol,
    timestamp,
    (SELECT price FROM UNNEST(asks) LIMIT 1) - 
    (SELECT price FROM UNNEST(bids) LIMIT 1) AS spread,
    (
        (SELECT SUM(volume) FROM UNNEST(bids) LIMIT 5) -
        (SELECT SUM(volume) FROM UNNEST(asks) LIMIT 5)
    ) / NULLIF(
        (SELECT SUM(volume) FROM UNNEST(bids) LIMIT 5) +
        (SELECT SUM(volume) FROM UNNEST(asks) LIMIT 5), 0
    ) AS depth_imbalance,
    (SELECT SUM(price * volume) FROM UNNEST(bids) LIMIT 5) AS bid_value,
    (SELECT SUM(price * volume) FROM UNNEST(asks) LIMIT 5) AS ask_value
FROM order_book_stream;

-- 市场压力指标视图
CREATE MATERIALIZED VIEW IF NOT EXISTS mv_market_pressure AS
SELECT
    t.market_type,
    t.exchange,
    t.symbol,
    t.window_start AS timestamp,
    t.buy_sell_ratio,
    ob.depth_imbalance,
    ob.spread,
    CASE
        WHEN t.buy_sell_ratio > 1.2 AND ob.depth_imbalance > 0.1 THEN 'strong_buy'
        WHEN t.buy_sell_ratio < 0.8 AND ob.depth_imbalance < -0.1 THEN 'strong_sell'
        WHEN t.buy_sell_ratio BETWEEN 0.8 AND 1.2 THEN 'neutral'
        ELSE 'mixed'
    END AS market_pressure
FROM (
    SELECT
        market_type,
        exchange,
        symbol,
        window_start,
        SUM(CASE WHEN side = 'buy' THEN volume ELSE 0 END) /
        NULLIF(SUM(CASE WHEN side = 'sell' THEN volume ELSE 0 END), 0) AS buy_sell_ratio
    FROM trade_stream
    GROUP BY 
        market_type,
        exchange,
        symbol,
        HOP(timestamp, INTERVAL '10' SECOND, INTERVAL '1' MINUTE)
) t
JOIN mv_order_book_analysis ob
ON t.market_type = ob.market_type
AND t.exchange = ob.exchange
AND t.symbol = ob.symbol;

-- 异常检测视图
CREATE MATERIALIZED VIEW IF NOT EXISTS mv_anomaly_detection AS
WITH price_stats AS (
    SELECT
        market_type,
        exchange,
        symbol,
        window_start AS timestamp,
        AVG(price) AS avg_price,
        STDDEV(price) AS price_std,
        COUNT(*) AS trade_count
    FROM trade_stream
    GROUP BY 
        market_type,
        exchange,
        symbol,
        HOP(timestamp, INTERVAL '1' MINUTE, INTERVAL '5' MINUTE)
)
SELECT
    t.market_type,
    t.exchange,
    t.symbol,
    t.timestamp,
    t.price,
    t.volume,
    CASE
        WHEN ABS(t.price - s.avg_price) > 3 * s.price_std THEN 'price_anomaly'
        WHEN t.volume > 10 * (SELECT AVG(volume) FROM trade_stream) THEN 'volume_anomaly'
        ELSE 'normal'
    END AS anomaly_type
FROM trade_stream t
JOIN price_stats s
ON t.market_type = s.market_type
AND t.exchange = s.exchange
AND t.symbol = s.symbol;

-- 数据质量监控视图
CREATE MATERIALIZED VIEW IF NOT EXISTS mv_data_quality AS
SELECT
    market_type,
    exchange,
    symbol,
    window_start AS timestamp,
    COUNT(*) AS record_count,
    MAX(timestamp) - MIN(timestamp) AS time_span,
    (MAX(timestamp) - MIN(timestamp)) / COUNT(*) AS avg_update_interval,
    COUNT(DISTINCT trade_id) AS unique_trades,
    COUNT(*) - COUNT(DISTINCT trade_id) AS duplicate_count
FROM trade_stream
GROUP BY 
    market_type,
    exchange,
    symbol,
    HOP(timestamp, INTERVAL '1' MINUTE, INTERVAL '5' MINUTE);

-- 连续查询：更新市场状态
CREATE SINK IF NOT EXISTS market_state_sink AS
SELECT
    t.market_type,
    t.exchange,
    t.symbol,
    t.timestamp,
    t.vwap,
    ob.spread,
    ob.depth_imbalance,
    p.price_momentum,
    mp.market_pressure,
    dq.avg_update_interval
FROM mv_vwap t
JOIN mv_order_book_analysis ob
ON t.market_type = ob.market_type
AND t.exchange = ob.exchange
AND t.symbol = ob.symbol
JOIN mv_price_momentum p
ON t.market_type = p.market_type
AND t.exchange = p.exchange
AND t.symbol = p.symbol
JOIN mv_market_pressure mp
ON t.market_type = mp.market_type
AND t.exchange = mp.exchange
AND t.symbol = mp.symbol
JOIN mv_data_quality dq
ON t.market_type = dq.market_type
AND t.exchange = dq.exchange
AND t.symbol = dq.symbol
WITH (
    connector = 'kafka',
    topic = 'market.state',
    properties.bootstrap.server = 'redpanda:9092'
) FORMAT PLAIN ENCODE JSON;