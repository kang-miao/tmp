import logging
from typing import Dict, Any, Optional
from contextlib import contextmanager
from time import time
from functools import wraps
import asyncio

class Logger:
    """日志工具类"""
    def __init__(self, name: str):
        self.logger = logging.getLogger(name)
        self.error_logger = logging.getLogger('error_logger')

    def info(self, message: str, extra: Dict[str, Any] = None):
        """记录信息日志"""
        self.logger.info(message, extra={'extra_fields': extra})

    def warning(self, message: str, extra: Dict[str, Any] = None):
        """记录警告日志"""
        self.logger.warning(message, extra={'extra_fields': extra})

    def error(self, message: str, exc_info: bool = True, 
              extra: Dict[str, Any] = None):
        """记录错误日志"""
        self.error_logger.error(
            message,
            exc_info=exc_info,
            extra={'extra_fields': extra}
        )

    def debug(self, message: str, extra: Dict[str, Any] = None):
        """记录调试日志"""
        self.logger.debug(message, extra={'extra_fields': extra})

    @contextmanager
    def timer(self, operation: str):
        """计时器上下文管理器"""
        start = time()
        try:
            yield
        finally:
            duration = time() - start
            self.info(
                f"{operation} completed",
                {'duration': f"{duration:.3f}s"}
            )

    def log_execution(self, operation: str):
        """函数执行日志装饰器"""
        def decorator(func):
            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                with self.timer(operation):
                    return await func(*args, **kwargs)

            @wraps(func)
            def sync_wrapper(*args, **kwargs):
                with self.timer(operation):
                    return func(*args, **kwargs)

            return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper
        return decorator
