from typing import Dict, Any, Optional
import contextvars
from uuid import uuid4

# 创建上下文变量
request_id_var = contextvars.ContextVar('request_id', default=None)
trace_id_var = contextvars.ContextVar('trace_id', default=None)
extra_fields_var = contextvars.ContextVar('extra_fields', default={})

class LogContext:
    """日志上下文管理器"""
    @staticmethod
    def set_request_id(request_id: Optional[str] = None):
        """设置请求ID"""
        request_id_var.set(request_id or str(uuid4()))

    @staticmethod
    def get_request_id() -> Optional[str]:
        """获取请求ID"""
        return request_id_var.get()

    @staticmethod
    def set_trace_id(trace_id: str):
        """设置追踪ID"""
        trace_id_var.set(trace_id)

    @staticmethod
    def get_trace_id() -> Optional[str]:
        """获取追踪ID"""
        return trace_id_var.get()

    @staticmethod
    def set_extra_fields(fields: Dict[str, Any]):
        """设置额外字段"""
        current = extra_fields_var.get()
        extra_fields_var.set({**current, **fields})

    @staticmethod
    def get_extra_fields() -> Dict[str, Any]:
        """获取额外字段"""
        return extra_fields_var.get()

    @staticmethod
    def clear():
        """清除上下文"""
        request_id_var.set(None)
        trace_id_var.set(None)
        extra_fields_var.set({})
