import logging
import logging.handlers
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Any
from logging.config import dictConfig

class LogConfig:
    """日志配置类"""
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.log_path = Path(config.get('output_path', 'logs'))
        self.log_path.mkdir(parents=True, exist_ok=True)
        self._setup_logging()

    def _setup_logging(self):
        """设置日志配置"""
        log_config = {
            'version': 1,
            'disable_existing_loggers': False,
            'formatters': {
                'json': {
                    '()': 'logging.formatters.json_formatter.JsonFormatter',
                },
                'standard': {
                    'format': '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
                }
            },
            'handlers': {
                'console': {
                    'class': 'logging.StreamHandler',
                    'formatter': 'standard',
                    'level': 'INFO',
                },
                'file': {
                    'class': 'logging.handlers.TimedRotatingFileHandler',
                    'formatter': 'json',
                    'filename': self.log_path / 'app.log',
                    'when': 'midnight',
                    'interval': 1,
                    'backupCount': 30,
                    'encoding': 'utf-8'
                },
                'error_file': {
                    'class': 'logging.handlers.RotatingFileHandler',
                    'formatter': 'json',
                    'filename': self.log_path / 'error.log',
                    'maxBytes': 10485760,  # 10MB
                    'backupCount': 20,
                    'encoding': 'utf-8'
                }
            },
            'root': {
                'level': self.config.get('level', 'INFO'),
                'handlers': ['console', 'file']
            },
            'loggers': {
                'error_logger': {
                    'level': 'ERROR',
                    'handlers': ['error_file'],
                    'propagate': False
                }
            }
        }
        dictConfig(log_config)
