import logging
import json
from datetime import datetime
from typing import Dict, Any

class JsonFormatter(logging.Formatter):
    """JSON格式日志格式化器"""
    def __init__(self):
        super().__init__()
        self.default_fields = [
            'name', 'levelname', 'pathname', 
            'lineno', 'funcName', 'thread'
        ]

    def format(self, record: logging.LogRecord) -> str:
        """格式化日志记录"""
        message = {
            'timestamp': datetime.fromtimestamp(record.created).isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage()
        }

        # 添加默认字段
        for field in self.default_fields:
            value = getattr(record, field, None)
            if value is not None:
                message[field] = value

        # 添加异常信息
        if record.exc_info:
            message['exception'] = self.formatException(record.exc_info)

        # 添加额外字段
        if hasattr(record, 'extra_fields'):
            message.update(record.extra_fields)

        return json.dumps(message)

    def formatException(self, exc_info) -> Dict[str, Any]:
        """格式化异常信息"""
        return {
            'type': exc_info[0].__name__,
            'message': str(exc_info[1]),
            'stack_trace': self.formatStack(exc_info[2])
        }

    def formatStack(self, tb) -> list:
        """格式化堆栈信息"""
        import traceback
        return [str(line) for line in traceback.extract_tb(tb)]
