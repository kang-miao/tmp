import logging
from datetime import datetime
from typing import Dict, Any
import socket
import os

class CustomFormatter(logging.Formatter):
    """自定义日志格式化器"""
    def __init__(self, include_hostname: bool = True):
        super().__init__()
        self.include_hostname = include_hostname
        self.hostname = socket.gethostname() if include_hostname else None
        self.pid = os.getpid()

    def format(self, record: logging.LogRecord) -> str:
        """格式化日志记录"""
        # 基础格式
        formatted = f"[{self.format_time(record)}] "
        
        # 添加主机名和进程ID
        if self.include_hostname:
            formatted += f"[{self.hostname}:{self.pid}] "

        # 添加日志级别
        formatted += f"[{record.levelname}] "

        # 添加logger名称
        formatted += f"[{record.name}] "

        # 添加消息
        formatted += record.getMessage()

        # 添加额外信息
        if hasattr(record, 'extra_fields'):
            formatted += f" | {self.format_extra(record.extra_fields)}"

        # 添加异常信息
        if record.exc_info:
            formatted += f"\n{self.format_exception(record)}"

        return formatted

    def format_time(self, record: logging.LogRecord) -> str:
        """格式化时间"""
        return datetime.fromtimestamp(record.created).strftime(
            '%Y-%m-%d %H:%M:%S.%f'
        )[:-3]

    def format_extra(self, extra: Dict[str, Any]) -> str:
        """格式化额外字段"""
        return " ".join(f"{k}={v}" for k, v in extra.items())

    def format_exception(self, record: logging.LogRecord) -> str:
        """格式化异常信息"""
        if not record.exc_info:
            return ""
        return self.formatException(record.exc_info)
