# tests/test_storage.py

import pytest
import asyncio
from datetime import datetime
import pandas as pd
import json

from storage.connectors.keydb_connector import KeyDBConnector
from storage.connectors.redpanda_connector import RedpandaConnector
from storage.connectors.risingwave_connector import RisingWaveConnector
from storage.connectors.tdengine_connector import TDengineConnector
from storage.connectors.minio_connector import MinIOConnector
from utils.config_loader import ConfigLoader

class TestStorage:
   """存储系统集成测试"""

   @pytest.fixture
   def config(self):
       """加载测试配置"""
       return ConfigLoader('config/settings.py').load_config()

   @pytest.fixture
   async def keydb(self, config):
       """KeyDB测试实例"""
       connector = KeyDBConnector(config['KEYDB_CONFIG'])
       yield connector

   @pytest.fixture
   async def redpanda(self, config):
       """Redpanda测试实例"""
       connector = RedpandaConnector(config['REDPANDA_CONFIG'])
       yield connector

   @pytest.fixture
   async def risingwave(self, config):
       """RisingWave测试实例"""
       connector = RisingWaveConnector(config['RISINGWAVE_CONFIG'])
       await connector.init_pool()
       yield connector
       await connector.close()

   @pytest.fixture
   async def tdengine(self, config):
       """TDengine测试实例"""
       connector = TDengineConnector(config['TDENGINE_CONFIG'])
       await connector.init_database()
       yield connector
       await connector.close()

   @pytest.fixture
   async def minio(self, config):
       """MinIO测试实例"""
       connector = MinIOConnector(config['MINIO_CONFIG'])
       await connector.init_buckets()
       yield connector

   @pytest.mark.asyncio
   async def test_keydb_operations(self, keydb):
       """测试KeyDB基本操作"""
       # 测试连接
       assert await keydb.check_connection()
       
       # 测试写入和读取
       test_data = {
           'bids': [[45000.0, 1.0]],
           'asks': [[45001.0, 1.0]]
       }
       success = await keydb.update_order_book(
           'Binance', 'BTC-USDT',
           test_data['bids'],
           test_data['asks'],
           datetime.now()
       )
       assert success
       
       result = await keydb.get_order_book('Binance', 'BTC-USDT')
       assert result is not None
       assert len(result['bids']) == 1
       assert len(result['asks']) == 1

   @pytest.mark.asyncio
   async def test_redpanda_operations(self, redpanda):
       """测试Redpanda基本操作"""
       # 测试连接
       assert await redpanda.check_connection()
       
       # 测试Topic创建
       test_topic = 'test_topic'
       success = await redpanda.create_topics([test_topic])
       assert success
       
       # 测试消息发布和消费
       test_message = {'test_key': 'test_value'}
       success = await redpanda.publish_message(test_topic, test_message)
       assert success
       
       messages = await redpanda.consume_messages(
           [test_topic],
           'test-group',
           timeout=5.0
       )
       assert len(messages) > 0
       assert messages[0]['test_key'] == 'test_value'

   @pytest.mark.asyncio
   async def test_risingwave_operations(self, risingwave):
       """测试RisingWave基本操作"""
       # 测试连接
       assert await risingwave.check_connection()
       
       # 测试视图创建
       success = await risingwave.create_materialized_view('test_view')
       assert success
       
       # 测试数据查询
       result = await risingwave.query_view(
           'test_view',
           conditions={'symbol': 'BTC-USDT'},
           limit=10
       )
       assert isinstance(result, list)

   @pytest.mark.asyncio
   async def test_tdengine_operations(self, tdengine):
       """测试TDengine基本操作"""
       # 测试连接
       assert await tdengine.check_connection()
       
       # 测试数据写入
       test_trade = {
           'market_type': 'crypto',
           'exchange': 'Binance',
           'symbol': 'BTC-USDT',
           'timestamp': datetime.now(),
           'price': 45000.0,
           'volume': 1.0,
           'amount': 45000.0,
           'side': 'buy',
           'trade_id': 'test123'
       }
       success = await tdengine.insert_trade(test_trade)
       assert success
       
       # 测试数据查询
       trades = await tdengine.query_trades(
           'crypto',
           'Binance',
           'BTC-USDT',
           test_trade['timestamp'],
           limit=1
       )
       assert len(trades) > 0
       assert trades[0]['trade_id'] == 'test123'

   @pytest.mark.asyncio
   async def test_minio_operations(self, minio):
       """测试MinIO基本操作"""
       # 测试连接
       assert await minio.check_connection()
       
       # 测试数据存储
       test_df = pd.DataFrame({
           'timestamp': [datetime.now()],
           'price': [45000.0],
           'volume': [1.0]
       })
       
       success = await minio.save_dataframe(
           test_df,
           'crypto',
           'Binance',
           'BTC-USDT',
           'trade'
       )
       assert success
       
       # 测试数据读取
       result_df = await minio.load_dataframe(
           'crypto',
           'Binance',
           'BTC-USDT',
           'trade',
           datetime.now()
       )
       assert isinstance(result_df, pd.DataFrame)
       assert len(result_df) > 0

   @pytest.mark.asyncio
   async def test_concurrent_operations(self, keydb, redpanda, risingwave, tdengine, minio):
       """测试并发操作"""
       async def write_trade():
           trade = {
               'market_type': 'crypto',
               'exchange': 'Binance',
               'symbol': 'BTC-USDT',
               'timestamp': datetime.now(),
               'price': 45000.0,
               'volume': 1.0,
               'amount': 45000.0,
               'side': 'buy',
               'trade_id': f'test_{asyncio.current_task().get_name()}'
           }
           await tdengine.insert_trade(trade)
           await redpanda.publish_message('trades.raw', trade)
           return trade['trade_id']

       # 并发写入多条交易数据
       tasks = [write_trade() for _ in range(10)]
       trade_ids = await asyncio.gather(*tasks)
       
       # 验证所有数据都已写入
       messages = await redpanda.consume_messages(
           ['trades.raw'],
           'test-group',
           timeout=5.0
       )
       assert len(messages) == 10
       assert all(msg['trade_id'] in trade_ids for msg in messages)

   @pytest.mark.asyncio
   async def test_error_recovery(self, tdengine):
       """测试错误恢复"""
       # 模拟连接断开
       tdengine.conn = None
       
       # 尝试写入数据，应该自动重连
       test_trade = {
           'market_type': 'crypto',
           'exchange': 'Binance',
           'symbol': 'BTC-USDT',
           'timestamp': datetime.now(),
           'price': 45000.0,
           'volume': 1.0,
           'amount': 45000.0,
           'side': 'buy',
           'trade_id': 'recovery_test'
       }
       
       success = await tdengine.insert_trade(test_trade)
       assert success
       
       # 验证数据是否写入成功
       trades = await tdengine.query_trades(
           'crypto',
           'Binance',
           'BTC-USDT',
           test_trade['timestamp'],
           limit=1
       )
       assert len(trades) > 0
       assert trades[0]['trade_id'] == 'recovery_test'

if __name__ == '__main__':
   pytest.main(['-v', 'test_storage.py'])