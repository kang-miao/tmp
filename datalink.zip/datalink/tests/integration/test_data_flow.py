# tests/test_data_flow.py

import asyncio
import pytest
from datetime import datetime
from typing import Dict, Any

from core.data_link import DataLink
from core.market_data import MarketType, DataType
from utils.config_loader import ConfigLoader

class TestDataFlow:
    """数据流集成测试"""

    @pytest.fixture
    async def datalink(self):
        """DataLink测试实例"""
        dl = DataLink('config/settings.py')
        await dl.initialize()
        yield dl
        await dl.stop()

    @pytest.fixture
    def test_trade_data(self) -> Dict[str, Any]:
        """测试用交易数据"""
        return {
            'exchange': 'Binance',
            'symbol': 'BTC-USDT',
            'timestamp': datetime.now(),
            'price': 45000.0,
            'amount': 0.1,
            'side': 'buy',
            'trade_id': '123456'
        }

    @pytest.mark.asyncio
    async def test_trade_data_flow(self, datalink, test_trade_data):
        """测试交易数据流程"""
        # 模拟接收交易数据
        await datalink._handle_trade(test_trade_data)
        
        # 验证数据是否写入Redpanda
        messages = await datalink.storage['redpanda'].consume_messages(
            topics=['trades.raw'],
            group_id='test-group',
            timeout=5.0
        )
        assert len(messages) > 0
        assert messages[0]['trade_id'] == test_trade_data['trade_id']
        
        # 验证数据是否写入TDengine
        trades = await datalink.storage['tdengine'].query_trades(
            market_type='crypto',
            exchange='Binance',
            symbol='BTC-USDT',
            start_time=test_trade_data['timestamp'],
            limit=1
        )
        assert len(trades) > 0
        assert trades[0]['trade_id'] == test_trade_data['trade_id']

    @pytest.mark.asyncio
    async def test_order_book_flow(self, datalink):
        """测试订单簿数据流程"""
        test_order_book = {
            'exchange': 'Binance',
            'symbol': 'BTC-USDT',
            'timestamp': datetime.now(),
            'bids': [[45000.0, 1.0], [44999.0, 2.0]],
            'asks': [[45001.0, 1.0], [45002.0, 2.0]]
        }
        
        # 模拟接收订单簿数据
        await datalink._handle_order_book(test_order_book)
        
        # 验证数据是否写入KeyDB
        cached_book = await datalink.storage['keydb'].get_order_book(
            'Binance', 'BTC-USDT'
        )
        assert cached_book is not None
        assert len(cached_book['bids']) == 2
        assert len(cached_book['asks']) == 2
        
        # 验证数据是否写入Redpanda
        messages = await datalink.storage['redpanda'].consume_messages(
            topics=['orderbooks.raw'],
            group_id='test-group',
            timeout=5.0
        )
        assert len(messages) > 0
        assert messages[0]['symbol'] == test_order_book['symbol']

    @pytest.mark.asyncio
    async def test_kline_data_flow(self, datalink):
        """测试K线数据流程"""
        test_kline = {
            'exchange': 'Binance',
            'symbol': 'BTC-USDT',
            'timestamp': datetime.now(),
            'interval': '1m',
            'open': 45000.0,
            'high': 45100.0,
            'low': 44900.0,
            'close': 45050.0,
            'volume': 10.5
        }
        
        # 模拟接收K线数据
        await datalink._handle_kline(test_kline)
        
        # 验证数据是否写入TDengine
        klines = await datalink.storage['tdengine'].query_klines(
            market_type='crypto',
            exchange='Binance',
            symbol='BTC-USDT',
            start_time=test_kline['timestamp'],
            limit=1
        )
        assert len(klines) > 0
        assert klines[0]['close'] == test_kline['close']
        
        # 验证数据是否在RisingWave中正确聚合
        agg_data = await datalink.storage['risingwave'].query_view(
            'minute_klines',
            conditions={
                'symbol': 'BTC-USDT',
                'exchange': 'Binance'
            },
            limit=1
        )
        assert len(agg_data) > 0
        assert agg_data[0]['volume'] > 0

    @pytest.mark.asyncio
    async def test_data_retention(self, datalink, test_trade_data):
        """测试数据保留策略"""
        # 写入测试数据
        await datalink._handle_trade(test_trade_data)
        
        # 验证数据是否已保存到MinIO
        data = await datalink.storage['minio'].load_dataframe(
            market_type='crypto',
            exchange='Binance',
            symbol='BTC-USDT',
            data_type='trade',
            date=test_trade_data['timestamp']
        )
        assert data is not None
        assert len(data) > 0

    @pytest.mark.asyncio
    async def test_error_handling(self, datalink, test_trade_data):
        """测试错误处理"""
        # 模拟存储错误
        datalink.storage['tdengine'].conn = None
        
        # 发送数据
        await datalink._handle_trade(test_trade_data)
        
        # 验证错误是否被正确记录
        monitor_stats = await datalink.monitor.get_stats()
        assert monitor_stats['trade_Binance_BTC-USDT']['error_count'] > 0

if __name__ == '__main__':
    pytest.main(['-v', 'test_data_flow.py'])