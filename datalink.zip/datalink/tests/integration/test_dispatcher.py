# tests/test_dispatcher.py

import pytest
import asyncio
from datetime import datetime
from typing import Dict, Any

from processors.dispatcher import DataDispatcher
from utils.metrics import MetricsManager

class TestDispatcher:
    """分发器集成测试"""

    @pytest.fixture
    async def metrics(self):
        return MetricsManager()

    @pytest.fixture
    async def storage_connectors(self):
        """模拟存储连接器"""
        return {
            'keydb': MockKeyDB(),
            'redpanda': MockRedpanda(),
            'tdengine': MockTDengine(),
            'minio': MockMinIO()
        }

    @pytest.fixture
    async def dispatcher(self, storage_connectors, metrics):
        """初始化分发器"""
        config = {
            'max_queue_size': 1000,
            'max_retries': 3
        }
        
        dispatcher = DataDispatcher(storage_connectors, metrics, config)
        await dispatcher.start()
        yield dispatcher
        await dispatcher.stop()

    @pytest.fixture
    def test_data(self) -> Dict[str, Any]:
        """测试数据"""
        return {
            'type': 'trade',
            'exchange': 'Binance',
            'symbol': 'BTC-USDT',
            'timestamp': datetime.now(),
            'price': 45000.0,
            'volume': 1.5,
            'side': 'buy',
            'trade_id': '123456'
        }

    @pytest.mark.asyncio
    async def test_multi_target_dispatch(self, dispatcher, test_data):
        """测试多目标分发"""
        success = await dispatcher.dispatch(test_data)
        assert success
        
        # 验证分发统计
        stats = await dispatcher.get_dispatch_stats()
        assert stats['success'] > 0
        assert stats['total'] > 0

    @pytest.mark.asyncio
    async def test_dispatch_retry(self, dispatcher, test_data, storage_connectors):
        """测试分发重试机制"""
        # 模拟存储失败
        storage_connectors['keydb'].fail_next = True
        
        success = await dispatcher.dispatch(test_data)
        assert success  # 应该通过重试成功
        
        # 验证重试统计
        stats = await dispatcher.get_dispatch_stats()
        assert stats['retries'] > 0

    @pytest.mark.asyncio
    async def test_queue_overflow_handling(self, dispatcher):
        """测试队列溢出处理"""
        # 生成大量测试数据
        test_data = []
        for i in range(2000):  # 超过队列大小
            data = {
                'type': 'trade',
                'exchange': 'Binance',
                'symbol': 'BTC-USDT',
                'timestamp': datetime.now(),
                'price': 45000.0,
                'volume': 1.5,
                'side': 'buy',
                'trade_id': f'test_{i}'
            }
            test_data.append(data)
        
        # 并发分发
        results = await asyncio.gather(
            *[dispatcher.dispatch(data) for data in test_data],
            return_exceptions=True
        )
        
        # 验证部分分发可能失败
        assert any(not result for result in results)
        
        # 验证队列大小
        stats = await dispatcher.get_dispatch_stats()
        for queue_size in stats['queue_sizes'].values():
            assert queue_size <= dispatcher.max_queue_size