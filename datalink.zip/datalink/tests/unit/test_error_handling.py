# tests/test_error_handling.py

import pytest
from datetime import datetime
from unittest.mock import patch, Mock
from utils.error_handler import ErrorHandler, RetryStrategy, enhanced_error_handler

class TestErrorHandling:
    @pytest.fixture
    def error_handler(self):
        return ErrorHandler()

    @pytest.fixture
    def retry_strategy(self):
        return RetryStrategy(max_retries=3, backoff_factor=0.1)

    @pytest.mark.asyncio
    async def test_retry_strategy(self, retry_strategy):
        """测试重试策略"""
        # 模拟一个会失败两次然后成功的函数
        attempt_count = 0
        async def test_func():
            nonlocal attempt_count
            attempt_count += 1
            if attempt_count < 3:
                raise Exception("Temporary failure")
            return "success"

        result = await retry_strategy.execute(test_func)
        assert result == "success"
        assert attempt_count == 3

    @pytest.mark.asyncio
    async def test_error_handler_decorator(self, error_handler):
        """测试错误处理装饰器"""
        @enhanced_error_handler('TestComponent')
        async def test_func():
            raise ValueError("Test error")

        with pytest.raises(Exception) as exc_info:
            await test_func()

        assert "Test error" in str(exc_info.value)
        stats = error_handler.get_error_stats('TestComponent')
        assert stats['total_errors'] > 0
        assert 'ValueError' in stats['error_types']

    @pytest.mark.asyncio
    async def test_error_context_tracking(self, error_handler):
        """测试错误上下文跟踪"""
        test_error = ValueError("Test error")
        context = {'test_key': 'test_value'}
        
        error_context = error_handler.handle_error(
            test_error,
            'TestComponent',
            context
        )
        
        assert error_context.error == test_error
        assert error_context.component == 'TestComponent'
        assert error_context.context == context
        assert error_context.trace_id is not None
        assert isinstance(error_context.timestamp, datetime)

    def test_error_stats(self, error_handler):
        """测试错误统计"""
        # 生成一些测试错误
        for _ in range(5):
            error_handler.handle_error(
                ValueError("Test error"),
                'Component1',
                {}
            )
        
        for _ in range(3):
            error_handler.handle_error(
                KeyError("Test error"),
                'Component2',
                {}
            )
        
        stats = error_handler.get_error_stats()
        
        assert 'Component1' in stats
        assert 'Component2' in stats
        assert stats['Component1']['total_errors'] == 5
        assert stats['Component2']['total_errors'] == 3
        assert stats['Component1']['error_types']['ValueError'] == 5
        assert stats['Component2']['error_types']['KeyError'] == 3

if __name__ == '__main__':
   pytest.main(['-v', 'test_error_handling.py'])