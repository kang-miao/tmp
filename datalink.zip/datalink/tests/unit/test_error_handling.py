# tests/test_error_handling.py

import pytest
import asyncio
from datetime import datetime
from unittest.mock import Mock, patch
from core.data_link import DataLink
from core.market_data import MarketType, DataType

class TestErrorHandling:
   """错误处理集成测试"""

   @pytest.fixture
   async def datalink(self):
       dl = DataLink('config/settings.py')
       await dl.initialize()
       yield dl
       await dl.stop()

   @pytest.mark.asyncio
   async def test_adapter_connection_failure(self, datalink):
       """测试适配器连接失败处理"""
       with patch('adapters.crypto.binance_adapter.BinanceAdapter.connect') as mock_connect:
           mock_connect.side_effect = Exception("Connection failed")
           
           # 尝试启动适配器
           adapter = datalink.adapters['binance']
           await adapter.start()
           
           # 验证重试机制
           assert adapter.status.retry_count > 0
           assert adapter.status.is_connected == False
           assert "Connection failed" in adapter.status.last_error

   @pytest.mark.asyncio
   async def test_storage_connection_failure(self, datalink):
       """测试存储连接失败处理"""
       with patch('storage.redpanda_connector.RedpandaConnector.check_connection') as mock_check:
           mock_check.return_value = False
           
           # 检查存储状态
           status = await datalink._check_storage_connections()
           assert not status['redpanda']
           
           # 验证系统是否记录了错误
           system_status = await datalink.get_system_status()
           assert not system_status['storage']['redpanda']

   @pytest.mark.asyncio
   async def test_data_validation_error(self, datalink):
       """测试数据验证错误处理"""
       invalid_trade = {
           'exchange': 'Binance',
           'symbol': 'BTC-USDT',
           'timestamp': datetime.now(),
           'price': -45000.0,  # 无效价格
           'amount': 0.1,
           'side': 'buy',
           'trade_id': '123456'
       }
       
       # 发送无效数据
       await datalink._handle_trade(invalid_trade)
       
       # 验证错误计数
       monitor_stats = await datalink.monitor.get_stats()
       assert monitor_stats['trade_Binance_BTC-USDT']['error_count'] > 0

   @pytest.mark.asyncio
   async def test_message_queue_overflow(self, datalink):
       """测试消息队列溢出处理"""
       # 模拟大量消息
       trades = []
       for i in range(1000):
           trades.append({
               'exchange': 'Binance',
               'symbol': 'BTC-USDT',
               'timestamp': datetime.now(),
               'price': 45000.0,
               'amount': 0.1,
               'side': 'buy',
               'trade_id': f'test_{i}'
           })
       
       # 并发发送消息
       tasks = [datalink._handle_trade(trade) for trade in trades]
       await asyncio.gather(*tasks)
       
       # 验证系统是否正常处理了所有消息
       monitor_stats = await datalink.monitor.get_stats()
       assert monitor_stats['trade_Binance_BTC-USDT']['messages_per_second'] > 0

   @pytest.mark.asyncio
   async def test_network_latency_handling(self, datalink):
       """测试网络延迟处理"""
       async def delayed_response():
           await asyncio.sleep(2)  # 模拟网络延迟
           return True

       with patch('storage.tdengine_connector.TDengineConnector.insert_trade', 
                 side_effect=delayed_response):
           
           start_time = datetime.now()
           trade = {
               'exchange': 'Binance',
               'symbol': 'BTC-USDT',
               'timestamp': datetime.now(),
               'price': 45000.0,
               'amount': 0.1,
               'side': 'buy',
               'trade_id': 'latency_test'
           }
           
           await datalink._handle_trade(trade)
           duration = (datetime.now() - start_time).total_seconds()
           
           # 验证系统是否记录了延迟
           monitor_stats = await datalink.monitor.get_stats()
           assert duration >= 2

   @pytest.mark.asyncio
   async def test_system_shutdown_handling(self, datalink):
       """测试系统关闭处理"""
       # 启动数据处理
       trade = {
           'exchange': 'Binance',
           'symbol': 'BTC-USDT',
           'timestamp': datetime.now(),
           'price': 45000.0,
           'amount': 0.1,
           'side': 'buy',
           'trade_id': 'shutdown_test'
       }
       process_task = asyncio.create_task(datalink._handle_trade(trade))
       
       # 立即触发关闭
       shutdown_task = asyncio.create_task(datalink.stop())
       
       # 验证是否正常完成所有任务
       await asyncio.gather(process_task, shutdown_task)
       assert not datalink.is_running
       
       # 检查所有连接是否正确关闭
       status = await datalink.get_system_status()
       assert not status['is_running']

   @pytest.mark.asyncio
   async def test_data_consistency_error(self, datalink):
       """测试数据一致性错误处理"""
       # 模拟不一致的订单簿数据
       inconsistent_book = {
           'exchange': 'Binance',
           'symbol': 'BTC-USDT',
           'timestamp': datetime.now(),
           'bids': [[45000.0, 1.0]],
           'asks': [[44999.0, 1.0]]  # 买价高于卖价
       }
       
       # 发送不一致数据
       await datalink._handle_order_book(inconsistent_book)
       
       # 验证错误处理
       monitor_stats = await datalink.monitor.get_stats()
       assert monitor_stats['orderbook_Binance_BTC-USDT']['error_count'] > 0

   @pytest.mark.asyncio
   async def test_recovery_after_error(self, datalink):
       """测试错误后的恢复机制"""
       # 首先触发错误
       with patch('storage.tdengine_connector.TDengineConnector.insert_trade',
                 side_effect=Exception("Database error")):
           trade1 = {
               'exchange': 'Binance',
               'symbol': 'BTC-USDT',
               'timestamp': datetime.now(),
               'price': 45000.0,
               'amount': 0.1,
               'side': 'buy',
               'trade_id': 'error_recovery_1'
           }
           await datalink._handle_trade(trade1)
       
       # 然后尝试正常处理
       trade2 = {
           'exchange': 'Binance',
           'symbol': 'BTC-USDT',
           'timestamp': datetime.now(),
           'price': 45000.0,
           'amount': 0.1,
           'side': 'buy',
           'trade_id': 'error_recovery_2'
       }
       await datalink._handle_trade(trade2)
       
       # 验证系统是否恢复正常
       monitor_stats = await datalink.monitor.get_stats()
       assert monitor_stats['trade_Binance_BTC-USDT']['messages_per_second'] > 0

if __name__ == '__main__':
   pytest.main(['-v', 'test_error_handling.py'])