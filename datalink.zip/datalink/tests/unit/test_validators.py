import pytest
from datetime import datetime
from validators.market_validator import MarketDataValidator

class TestMarketDataValidator:
    @pytest.fixture
    def validator(self):
        return MarketDataValidator()

    @pytest.mark.asyncio
    async def test_trade_validation(self, validator):
        """测试交易数据验证"""
        # 有效数据
        valid_trade = {
            'type': 'trade',
            'exchange': 'Binance',
            'symbol': 'BTC-USDT',
            'timestamp': datetime.now(),
            'price': 45000.0,
            'volume': 1.0,
            'side': 'buy'
        }
        result = await validator.validate(valid_trade)
        assert result.is_valid
        assert not result.errors
        assert 'amount' in result.metadata

        # 无效数据 - 负价格
        invalid_trade = valid_trade.copy()
        invalid_trade['price'] = -100
        result = await validator.validate(invalid_trade)
        assert not result.is_valid
        assert any('price' in error for error in result.errors)

    @pytest.mark.asyncio
    async def test_orderbook_validation(self, validator):
        """测试订单簿数据验证"""
        # 有效数据
        valid_orderbook = {
            'type': 'orderbook',
            'exchange': 'Binance',
            'symbol': 'BTC-USDT',
            'timestamp': datetime.now(),
            'bids': [[45000.0, 1.0], [44999.0, 2.0]],
            'asks': [[45001.0, 1.0], [45002.0, 2.0]]
        }
        result = await validator.validate(valid_orderbook)
        assert result.is_valid
        assert not result.errors
        assert 'spread' in result.metadata
        assert 'mid_price' in result.metadata

        # 无效数据 - 交叉订单簿
        invalid_orderbook = valid_orderbook.copy()
        invalid_orderbook['bids'] = [[45002.0, 1.0]]
        result = await validator.validate(invalid_orderbook)
        assert not result.is_valid
        assert any('Crossed orderbook' in error for error in result.errors)

    @pytest.mark.asyncio
    async def test_kline_validation(self, validator):
        """测试K线数据验证"""
        # 有效数据
        valid_kline = {
            'type': 'kline',
            'exchange': 'Binance',
            'symbol': 'BTC-USDT',
            'timestamp': datetime.now(),
            'interval': '1m',
            'open': 45000.0,
            'high': 45100.0,
            'low': 44900.0,
            'close': 45050.0,
            'volume': 10.5
        }
        result = await validator.validate(valid_kline)
        assert result.is_valid
        assert not result.errors
        assert 'price_change' in result.metadata
        assert 'price_change_percent' in result.metadata

        # 无效数据 - OHLC关系错误
        invalid_kline = valid_kline.copy()
        invalid_kline['high'] = 44800.0  # 高价低于低价
        result = await validator.validate(invalid_kline)
        assert not result.is_valid
        assert any('OHLC' in error for error in result.errors)
