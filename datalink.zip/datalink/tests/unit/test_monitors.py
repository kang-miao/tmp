import pytest
import asyncio
from datetime import datetime, timedelta
from monitor.performance_monitor import PerformanceMonitor
from monitor.latency_monitor import LatencyMonitor

class TestMonitors:
    @pytest.fixture
    async def performance_monitor(self):
        monitor = PerformanceMonitor()
        await monitor.start()
        yield monitor
        await monitor.stop()

    @pytest.fixture
    def latency_monitor(self):
        return LatencyMonitor()

    @pytest.mark.asyncio
    async def test_performance_monitoring(self, performance_monitor):
        """测试性能监控"""
        # 等待收集一些指标
        await asyncio.sleep(2)
        
        # 获取性能报告
        report = await performance_monitor.get_performance_report()
        
        # 验证报告内容
        assert 'cpu' in report
        assert 'memory' in report
        assert 'io' in report
        assert 'threads' in report
        
        # 验证指标值
        assert report['cpu'].get('latest') is not None
        assert report['memory']['rss'].get('latest') > 0

    @pytest.mark.asyncio
    async def test_latency_monitoring(self, latency_monitor):
        """测试延迟监控"""
        # 模拟操作
        operation_id = 'test_operation'
        latency_monitor.start_operation(operation_id)
        await asyncio.sleep(0.1)  # 模拟操作耗时
        latency_monitor.end_operation(
            operation_id,
            {'type': 'test', 'component': 'test_component'}
        )
        
        # 获取延迟统计
        stats = latency_monitor.get_latency_stats('test')
        
        # 验证统计信息
        assert stats.get('count') == 1
        assert stats.get('avg') >= 100  # 至少100ms
        assert 'p95' in stats
        assert 'p99' in stats

    @pytest.mark.asyncio
    async def test_metric_retention(self, performance_monitor):
        """测试指标保留"""
        # 添加一些测试指标
        performance_monitor.add_metric_point('test_metric', 1.0)
        performance_monitor.add_metric_point('test_metric', 2.0)
        
        # 验证指标存在
        stats = performance_monitor.get_metric_stats('test_metric')
        assert stats.get('count') == 2
        assert stats.get('avg') == 1.5

        # 模拟清理
        await performance_monitor._cleanup_metrics()
        
        # 验证指标仍然存在（因为未超过保留期）
        stats = performance_monitor.get_metric_stats('test_metric')
        assert stats.get('count') == 2
