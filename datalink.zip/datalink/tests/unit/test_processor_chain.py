# tests/test_processor_chain.py

import pytest
import asyncio
from datetime import datetime
from typing import Dict, Any

from processors.data_processor import DataProcessor
from processors.validator import DataValidator
from processors.cleaner import DataCleaner
from processors.transformer import DataTransformer
from processors.dispatcher import DataDispatcher
from utils.metrics import MetricsManager

class TestProcessorChain:
    """处理器链路集成测试"""

    @pytest.fixture
    async def metrics(self):
        return MetricsManager()

    @pytest.fixture
    async def processor_chain(self, metrics):
        """初始化处理器链"""
        config = {
            'validation': {},
            'cleaning': {},
            'transformation': {},
            'dispatch': {
                'max_queue_size': 1000,
                'max_retries': 3
            }
        }
        
        processor = DataProcessor(metrics, config)
        await processor.start()
        yield processor
        await processor.stop()

    @pytest.fixture
    def test_data(self) -> Dict[str, Any]:
        """测试数据"""
        return {
            'type': 'trade',
            'exchange': 'Binance',
            'symbol': 'BTC-USDT',
            'timestamp': datetime.now(),
            'price': 45000.0,
            'volume': 1.5,
            'side': 'buy',
            'trade_id': '123456'
        }

    @pytest.mark.asyncio
    async def test_full_processing_chain(self, processor_chain, test_data):
        """测试完整处理链路"""
        # 处理数据
        processed_data = await processor_chain.process(test_data)
        
        assert processed_data is not None
        assert processed_data['exchange'] == test_data['exchange']
        assert processed_data['symbol'] == test_data['symbol']
        assert 'vwap' in processed_data  # 验证转换器添加的字段
        
        # 验证处理统计
        stats = await processor_chain.get_processing_stats()
        assert stats['processed'] > 0
        assert stats['transformed'] > 0

    @pytest.mark.asyncio
    async def test_validation_rejection(self, processor_chain):
        """测试验证失败处理"""
        invalid_data = {
            'type': 'trade',
            'exchange': 'Binance',
            'symbol': 'BTC-USDT',
            'timestamp': datetime.now(),
            'price': -100.0,  # 无效价格
            'volume': 1.5,
            'side': 'buy',
            'trade_id': '123456'
        }
        
        processed_data = await processor_chain.process(invalid_data)
        assert processed_data is None

        # 验证验证统计
        stats = await processor_chain.validator.get_validation_stats()
        assert stats['failed'] > 0

    @pytest.mark.asyncio
    async def test_data_cleaning(self, processor_chain):
        """测试数据清洗"""
        noisy_data = {
            'type': 'trade',
            'exchange': 'Binance',
            'symbol': 'BTC-USDT',
            'timestamp': datetime.now(),
            'price': 45000.0,
            'volume': 999999.0,  # 异常值
            'side': 'buy',
            'trade_id': '123456'
        }
        
        processed_data = await processor_chain.process(noisy_data)
        assert processed_data is not None
        assert processed_data['volume'] < 999999.0  # 验证异常值被处理

        # 验证清洗统计
        stats = await processor_chain.cleaner.get_cleaning_stats()
        assert stats['cleaned'] > 0

    @pytest.mark.asyncio
    async def test_feature_transformation(self, processor_chain, test_data):
        """测试特征转换"""
        processed_data = await processor_chain.process(test_data)
        
        # 验证计算的特征
        assert 'vwap' in processed_data
        assert 'trade_size' in processed_data
        assert 'side_indicator' in processed_data
        
        # 验证转换统计
        stats = await processor_chain.transformer.get_transform_stats()
        assert stats['transformed'] > 0