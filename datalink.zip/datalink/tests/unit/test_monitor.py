# tests/test_monitor.py

import pytest
import asyncio
from datetime import datetime
from typing import Dict, Any

from monitor.system_monitor import SystemMonitor
from monitor.performance_monitor import PerformanceMonitor
from monitor.data_monitor import DataMonitor
from monitor.alert import AlertManager
from utils.metrics import MetricsManager

class TestMonitor:
    """监控系统集成测试"""

    @pytest.fixture
    async def metrics(self):
        return MetricsManager()

    @pytest.fixture
    async def monitor_system(self, metrics):
        """初始化监控系统"""
        config = {
            'check_interval': 1,
            'alert_thresholds': {
                'cpu_percent': 80,
                'memory_percent': 80,
                'error_rate': 0.01
            }
        }
        
        system_monitor = SystemMonitor(None, metrics, config)
        performance_monitor = PerformanceMonitor(metrics, config)
        data_monitor = DataMonitor()
        alert_manager = AlertManager(config)
        
        await system_monitor.start()
        await performance_monitor.start()
        data_monitor.start_monitoring()
        await alert_manager.start()
        
        yield (system_monitor, performance_monitor, data_monitor, alert_manager)
        
        await system_monitor.stop()
        await performance_monitor.stop()
        data_monitor.stop_monitoring()
        await alert_manager.stop()

    @pytest.mark.asyncio
    async def test_system_monitoring(self, monitor_system):
        """测试系统监控"""
        system_monitor = monitor_system[0]
        
        # 等待收集监控数据
        await asyncio.sleep(2)
        
        # 验证系统状态
        status = await system_monitor.get_system_status()
        assert 'system_resources' in status
        assert 'components' in status
        assert 'active_alerts' in status

    @pytest.mark.asyncio
    async def test_performance_monitoring(self, monitor_system):
        """测试性能监控"""
        performance_monitor = monitor_system[1]
        
        # 记录一些性能数据
        await performance_monitor.record_latency('test_op', 0.1)
        await performance_monitor.record_throughput('test_op', 100)
        
        # 验证性能报告
        report = await performance_monitor.get_performance_report()
        assert 'latency' in report
        assert 'throughput' in report

    @pytest.mark.asyncio
    async def test_data_monitoring(self, monitor_system):
        """测试数据监控"""
        data_monitor = monitor_system[2]
        
        # 更新数据统计
        data_monitor.update_stats('test_category', 100)
        
        # 验证监控统计
        stats = await data_monitor.get_stats()
        assert 'test_category' in stats
        assert stats['test_category']['messages_per_second'] > 0

    @pytest.mark.asyncio
    async def test_alert_system(self, monitor_system):
        """测试告警系统"""
        alert_manager = monitor_system[3]
        
        # 触发告警
        alert_id = await alert_manager.raise_alert(
            category='test',
            title='Test Alert',
            message='This is a test alert',
            severity='warning'
        )
        
        # 验证告警
        assert alert_id in alert_manager.active_alerts
        
        # 确认告警
        await alert_manager.acknowledge_alert(alert_id)
        assert alert_manager.active_alerts[alert_id].acknowledged
        
        # 解决告警
        await alert_manager.resolve_alert(alert_id)
        assert alert_id not in alert_manager.active_alerts