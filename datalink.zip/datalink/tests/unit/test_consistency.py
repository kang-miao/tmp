import pytest
from datetime import datetime, timedelta
from unittest.mock import Mock, patch
from consistency.data_checker import DataConsistencyChecker

class TestDataConsistencyChecker:
    @pytest.fixture
    def mock_storage(self):
        return {
            'tdengine': Mock(),
            'keydb': Mock(),
            'redpanda': Mock(),
            'risingwave': Mock()
        }
    
    @pytest.fixture
    def checker(self, mock_storage):
        return DataConsistencyChecker(mock_storage)
    
    @pytest.mark.asyncio
    async def test_trade_consistency(self, checker, mock_storage):
        """测试交易数据一致性检查"""
        # 模拟存储系统返回数据
        mock_storage['tdengine'].query_trades.return_value = [
            {
                'trade_id': '1',
                'price': 50000.0,
                'volume': 1.0
            }
        ]
        
        mock_storage['redpanda'].consume_messages.return_value = [
            {
                'trade_id': '1',
                'price': 50000.0,
                'volume': 1.0
            }
        ]
        
        result = await checker.check_consistency(
            market_type='crypto',
            exchange='Binance',
            symbol='BTC-USDT',
            start_time=datetime.now() - timedelta(minutes=5),
            end_time=datetime.now()
        )
        
        assert result.is_consistent
        assert not result.inconsistencies
        assert 'trade' in result.details
        
    @pytest.mark.asyncio
    async def test_orderbook_consistency(self, checker, mock_storage):
        """测试订单簿数据一致性检查"""
        # 模拟存储系统返回数据
        mock_storage['keydb'].get_order_book.return_value = {
            'bids': [[50000.0, 1.0]],
            'asks': [[50001.0, 1.0]]
        }
        
        mock_storage['risingwave'].get_order_book.return_value = {
            'bids': [[50000.0, 1.0]],
            'asks': [[50001.0, 1.0]]
        }
        
        result = await checker.check_consistency(
            market_type='crypto',
            exchange='Binance',
            symbol='BTC-USDT',
            start_time=datetime.now() - timedelta(minutes=5),
            end_time=datetime.now()
        )
        
        assert result.is_consistent
        assert not result.inconsistencies
        assert 'orderbook' in result.details
    
    @pytest.mark.asyncio
    async def test_kline_consistency(self, checker, mock_storage):
        """测试K线数据一致性检查"""
        timestamp = datetime.now()
        # 模拟存储系统返回数据
        mock_storage['tdengine'].query_klines.return_value = [
            {
                'timestamp': timestamp,
                'open': 50000.0,
                'high': 50100.0,
                'low': 49900.0,
                'close': 50050.0,
                'volume': 10.0
            }
        ]
        
        mock_storage['risingwave'].query_view.return_value = [
            {
                'timestamp': timestamp,
                'open': 50000.0,
                'high': 50100.0,
                'low': 49900.0,
                'close': 50050.0,
                'volume': 10.0
            }
        ]
        
        result = await checker.check_consistency(
            market_type='crypto',
            exchange='Binance',
            symbol='BTC-USDT',
            start_time=datetime.now() - timedelta(minutes=5),
            end_time=datetime.now()
        )
        
        assert result.is_consistent
        assert not result.inconsistencies
        assert 'kline' in result.details
    
    @pytest.mark.asyncio
    async def test_inconsistent_data(self, checker, mock_storage):
        """测试数据不一致的情况"""
        # 模拟不一致的数据
        mock_storage['tdengine'].query_trades.return_value = [
            {
                'trade_id': '1',
                'price': 50000.0,
                'volume': 1.0
            }
        ]
        
        mock_storage['redpanda'].consume_messages.return_value = [
            {
                'trade_id': '1',
                'price': 50001.0,  # 价格不一致
                'volume': 1.0
            }
        ]
        
        result = await checker.check_consistency(
            market_type='crypto',
            exchange='Binance',
            symbol='BTC-USDT',
            start_time=datetime.now() - timedelta(minutes=5),
            end_time=datetime.now()
        )
        
        assert not result.is_consistent
        assert result.inconsistencies
        assert any('Price mismatch' in msg for msg in result.inconsistencies) 