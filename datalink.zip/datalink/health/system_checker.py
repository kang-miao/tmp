import psutil
from typing import Dict, Any
from health.base_checker import BaseHealthChecker, HealthStatus

class SystemHealthChecker(BaseHealthChecker):
    """系统健康检查器"""
    def __init__(self, logger, thresholds: Dict[str, float]):
        super().__init__(logger, "system")
        self.thresholds = thresholds

    async def check_health(self) -> HealthCheckResult:
        """检查系统健康状态"""
        try:
            # 收集系统指标
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            metrics = {
                'cpu_usage': cpu_percent,
                'memory_usage': memory.percent,
                'disk_usage': disk.percent
            }
            
            # 评估健康状态
            status = HealthStatus.HEALTHY
            details = {}
            
            # CPU 检查
            if cpu_percent >= self.thresholds.get('cpu_critical', 90):
                status = HealthStatus.UNHEALTHY
                details['cpu'] = 'Critical CPU usage'
            elif cpu_percent >= self.thresholds.get('cpu_warning', 80):
                status = HealthStatus.DEGRADED
                details['cpu'] = 'High CPU usage'
                
            # 内存检查
            if memory.percent >= self.thresholds.get('memory_critical', 90):
                status = HealthStatus.UNHEALTHY
                details['memory'] = 'Critical memory usage'
            elif memory.percent >= self.thresholds.get('memory_warning', 80):
                status = max(status, HealthStatus.DEGRADED)
                details['memory'] = 'High memory usage'
                
            # 磁盘检查
            if disk.percent >= self.thresholds.get('disk_critical', 90):
                status = HealthStatus.UNHEALTHY
                details['disk'] = 'Critical disk usage'
            elif disk.percent >= self.thresholds.get('disk_warning', 80):
                status = max(status, HealthStatus.DEGRADED)
                details['disk'] = 'High disk usage'
                
            return self._create_result(
                status=status,
                details=details,
                metrics=metrics
            )
            
        except Exception as e:
            self.logger.error(
                f"System health check failed: {str(e)}",
                exc_info=True
            )
            return self._create_result(
                status=HealthStatus.UNKNOWN,
                details={},
                error=str(e)
            )
