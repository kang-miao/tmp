from typing import Dict, Any
import asyncio
import aioredis
import asyncpg
from health.base_checker import BaseHealthChecker, HealthStatus

class StorageHealthChecker(BaseHealthChecker):
    """存储健康检查器"""
    def __init__(self, logger, db_config: Dict[str, Any],
                 redis_config: Dict[str, Any]):
        super().__init__(logger, "storage")
        self.db_config = db_config
        self.redis_config = redis_config

    async def check_health(self) -> HealthCheckResult:
        """检查存储系统健康状态"""
        try:
            metrics = {}
            details = {}
            status = HealthStatus.HEALTHY
            
            # 检查数据库连接
            db_status = await self._check_database()
            details['database'] = db_status['details']
            metrics.update(db_status['metrics'])
            if db_status['status'] != HealthStatus.HEALTHY:
                status = max(status, db_status['status'])
                
            # 检查Redis连接
            redis_status = await self._check_redis()
            details['redis'] = redis_status['details']
            metrics.update(redis_status['metrics'])
            if redis_status['status'] != HealthStatus.HEALTHY:
                status = max(status, redis_status['status'])
                
            return self._create_result(
                status=status,
                details=details,
                metrics=metrics
            )
            
        except Exception as e:
            self.logger.error(
                f"Storage health check failed: {str(e)}",
                exc_info=True
            )
            return self._create_result(
                status=HealthStatus.UNKNOWN,
                details={},
                error=str(e)
            )

    async def _check_database(self) -> Dict[str, Any]:
        """检查数据库健康状态"""
        try:
            start_time = asyncio.get_event_loop().time()
            conn = await asyncpg.connect(**self.db_config)
            
            # 执行简单查询
            await conn.execute('SELECT 1')
            
            # 获取连接池统计
            pool_stats = await conn.fetch("""
                SELECT count(*) as connections
                FROM pg_stat_activity
            """)
            
            latency = asyncio.get_event_loop().time() - start_time
            await conn.close()
            
            return {
                'status': HealthStatus.HEALTHY,
                'details': 'Database connection successful',
                'metrics': {
                    'db_latency': latency,
                    'db_connections': pool_stats[0]['connections']
                }
            }
            
        except Exception as e:
            return {
                'status': HealthStatus.UNHEALTHY,
                'details': f'Database connection failed: {str(e)}',
                'metrics': {}
            }

    async def _check_redis(self) -> Dict[str, Any]:
        """检查Redis健康状态"""
        try:
            start_time = asyncio.get_event_loop().time()
            redis = await aioredis.create_redis_pool(**self.redis_config)
            
            # 执行简单操作
            await redis.ping()
            
            # 获取Redis信息
            info = await redis.info()
            
            latency = asyncio.get_event_loop().time() - start_time
            redis.close()
            await redis.wait_closed()
            
            return {
                'status': HealthStatus.HEALTHY,
                'details': 'Redis connection successful',
                'metrics': {
                    'redis_latency': latency,
                    'redis_connected_clients': info['connected_clients'],
                    'redis_used_memory': info['used_memory']
                }
            }
            
        except Exception as e:
            return {
                'status': HealthStatus.UNHEALTHY,
                'details': f'Redis connection failed: {str(e)}',
                'metrics': {}
            }
