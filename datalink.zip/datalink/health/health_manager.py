from typing import Dict, List, Any, Optional
import asyncio
from datetime import datetime, timedelta
from logging import Logger
from health.base_checker import (
    BaseHealthChecker, HealthStatus, HealthCheckResult
)

class HealthManager:
    """健康检查管理器"""
    def __init__(self, logger: Logger, check_interval: int = 60):
        self.logger = logger
        self.check_interval = check_interval
        self.checkers: Dict[str, BaseHealthChecker] = {}
        self.check_history: Dict[str, List[HealthCheckResult]] = {}
        self._running = False
        self._check_task: Optional[asyncio.Task] = None

    def add_checker(self, checker: BaseHealthChecker):
        """添加检查器"""
        self.checkers[checker.component_name] = checker
        self.check_history[checker.component_name] = []

    def remove_checker(self, component_name: str):
        """移除检查器"""
        if component_name in self.checkers:
            del self.checkers[component_name]
            del self.check_history[component_name]

    async def start(self):
        """启动健康检查"""
        self._running = True
        self._check_task = asyncio.create_task(self._check_loop())
        self.logger.info("Health manager started")

    async def stop(self):
        """停止健康检查"""
        self._running = False
        if self._check_task:
            self._check_task.cancel()
            try:
                await self._check_task
            except asyncio.CancelledError:
                pass
        self.logger.info("Health manager stopped")

    async def _check_loop(self):
        """检查循环"""
        while self._running:
            try:
                await self._check_all_components()
                await asyncio.sleep(self.check_interval)
            except Exception as e:
                self.logger.error(
                    f"Health check loop error: {str(e)}",
                    exc_info=True
                )
                await asyncio.sleep(5)

    async def _check_all_components(self):
        """检查所有组件"""
        for checker in self.checkers.values():
            try:
                result = await checker.check_health()
                self.check_history[checker.component_name].append(result)
                
                # 记录不健康状态
                if result.status != HealthStatus.HEALTHY:
                    self.logger.warning(
                        f"Unhealthy component detected: {checker.component_name}",
                        extra={
                            'component': checker.component_name,
                            'status': result.status.value,
                            'details': result.details
                        }
                    )
                    
                # 清理历史记录
                self._cleanup_history(checker.component_name)
                
            except Exception as e:
                self.logger.error(
                    f"Health check failed for {checker.component_name}: {str(e)}",
                    exc_info=True
                )

    def _cleanup_history(self, component_name: str,
                        max_age: timedelta = timedelta(days=1)):
        """清理历史记录"""
        if component_name in self.check_history:
            cutoff_time = datetime.now() - max_age
            self.check_history[component_name] = [
                result for result in self.check_history[component_name]
                if result.timestamp > cutoff_time
            ]

    def get_health_status(self) -> Dict[str, Any]:
        """获取健康状态报告"""
        status_report = {
            'overall_status': HealthStatus.HEALTHY,
            'timestamp': datetime.now().isoformat(),
            'components': {}
        }
        
        for component_name, checker in self.checkers.items():
            last_result = checker.get_last_result()
            if last_result:
                status_report['components'][component_name] = {
                    'status': last_result.status.value,
                    'details': last_result.details,
                    'metrics': last_result.metrics,
                    'last_check': last_result.timestamp.isoformat()
                }
                
                # 更新整体状态
                if last_result.status != HealthStatus.HEALTHY:
                    status_report['overall_status'] = max(
                        status_report['overall_status'],
                        last_result.status
                    )
                    
        return status_report

    def get_component_history(self,
                            component_name: str,
                            limit: int = 100
                            ) -> List[HealthCheckResult]:
        """获取组件检查历史"""
        if component_name in self.check_history:
            return sorted(
                self.check_history[component_name],
                key=lambda x: x.timestamp,
                reverse=True
            )[:limit]
        return []
