from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from logging import Logger

class HealthStatus(Enum):
    """健康状态"""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"

@dataclass
class HealthCheckResult:
    """健康检查结果"""
    component: str
    status: HealthStatus
    details: Dict[str, Any]
    timestamp: datetime
    error: Optional[str] = None
    metrics: Optional[Dict[str, float]] = None

class BaseHealthChecker(ABC):
    """健康检查基类"""
    def __init__(self, logger: Logger, component_name: str):
        self.logger = logger
        self.component_name = component_name
        self.last_result: Optional[HealthCheckResult] = None

    @abstractmethod
    async def check_health(self) -> HealthCheckResult:
        """执行健康检查"""
        pass

    def _create_result(self, 
                      status: HealthStatus,
                      details: Dict[str, Any],
                      error: Optional[str] = None,
                      metrics: Optional[Dict[str, float]] = None
                      ) -> HealthCheckResult:
        """创建检查结果"""
        result = HealthCheckResult(
            component=self.component_name,
            status=status,
            details=details,
            timestamp=datetime.now(),
            error=error,
            metrics=metrics
        )
        self.last_result = result
        return result

    def get_last_result(self) -> Optional[HealthCheckResult]:
        """获取最后一次检查结果"""
        return self.last_result
