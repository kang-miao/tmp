from typing import Dict, Any, Type, Optional, TypeVar
from pathlib import Path
import asyncio
from logging import Logger
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from config.base_config import BaseConfig

T = TypeVar('T', bound=BaseConfig)

class ConfigFileHandler(FileSystemEventHandler):
    """配置文件变更处理器"""
    def __init__(self, config_manager: 'ConfigManager', logger: Logger):
        self.config_manager = config_manager
        self.logger = logger

    def on_modified(self, event):
        if not event.is_directory:
            try:
                file_path = Path(event.src_path)
                if file_path in self.config_manager.watched_files:
                    asyncio.create_task(
                        self.config_manager.reload_config(file_path)
                    )
            except Exception as e:
                self.logger.error(
                    f"Error handling config file change: {str(e)}",
                    exc_info=True
                )

class ConfigManager:
    """配置管理器"""
    def __init__(self, logger: Logger, config_dir: Path):
        self.logger = logger
        self.config_dir = config_dir
        self.configs: Dict[str, BaseConfig] = {}
        self.watched_files: Dict[Path, Type[BaseConfig]] = {}
        self.observer = Observer()
        self.handler = ConfigFileHandler(self, logger)
        self._callbacks: Dict[str, list] = {}

    async def start(self):
        """启动配置管理器"""
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.observer.schedule(self.handler, str(self.config_dir), recursive=True)
        self.observer.start()
        self.logger.info("Config manager started")

    async def stop(self):
        """停止配置管理器"""
        self.observer.stop()
        self.observer.join()
        self.logger.info("Config manager stopped")

    def register_config(self, name: str, config_class: Type[BaseConfig],
                       file_name: str, watch: bool = True):
        """注册配置"""
        file_path = self.config_dir / file_name
        
        if not file_path.exists():
            # 创建默认配置
            config = config_class()
            config.save_to_file(file_path, self.logger)
        else:
            # 加载现有配置
            config = config_class.load_from_file(file_path, self.logger)
            
        self.configs[name] = config
        
        if watch:
            self.watched_files[file_path] = config_class
            
        self.logger.info(f"Registered config: {name}")

    def get_config(self, name: str) -> Optional[BaseConfig]:
        """获取配置"""
        return self.configs.get(name)

    async def reload_config(self, file_path: Path):
        """重新加载配置"""
        try:
            config_class = self.watched_files.get(file_path)
            if not config_class:
                return
                
            # 加载新配置
            new_config = config_class.load_from_file(file_path, self.logger)
            
            # 验证新配置
            if not new_config.validate():
                raise ValueError("Invalid configuration")
                
            # 查找配置名称
            config_name = None
            for name, config in self.configs.items():
                if isinstance(config, config_class):
                    config_name = name
                    break
                    
            if config_name:
                # 更新配置
                self.configs[config_name] = new_config
                # 触发回调
                await self._notify_callbacks(config_name, new_config)
                
                self.logger.info(f"Reloaded config: {config_name}")
                
        except Exception as e:
            self.logger.error(
                f"Failed to reload config from {file_path}: {str(e)}",
                exc_info=True
            )

    def add_callback(self, config_name: str, callback):
        """添加配置变更回调"""
        if config_name not in self._callbacks:
            self._callbacks[config_name] = []
        self._callbacks[config_name].append(callback)

    def remove_callback(self, config_name: str, callback):
        """移除配置变更回调"""
        if config_name in self._callbacks:
            self._callbacks[config_name].remove(callback)

    async def _notify_callbacks(self, config_name: str, config: BaseConfig):
        """通知配置变更"""
        if config_name in self._callbacks:
            for callback in self._callbacks[config_name]:
                try:
                    if asyncio.iscoroutinefunction(callback):
                        await callback(config)
                    else:
                        callback(config)
                except Exception as e:
                    self.logger.error(
                        f"Error in config callback: {str(e)}",
                        exc_info=True
                    )
