from dataclasses import dataclass, field
from typing import Dict, Any, List
from config.base_config import BaseConfig

@dataclass
class DatabaseConfig(BaseConfig):
    """数据库配置"""
    host: str = "localhost"
    port: int = 5432
    database: str = "myapp"
    user: str = "postgres"
    password: str = ""
    min_connections: int = 5
    max_connections: int = 20
    connection_timeout: int = 30

@dataclass
class RedisConfig(BaseConfig):
    """Redis配置"""
    host: str = "localhost"
    port: int = 6379
    db: int = 0
    password: str = ""
    max_connections: int = 10
    connection_timeout: int = 5

@dataclass
class LogConfig(BaseConfig):
    """日志配置"""
    level: str = "INFO"
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    file_path: str = "logs/app.log"
    max_size: int = 10485760  # 10MB
    backup_count: int = 5
    console_output: bool = True

@dataclass
class MonitorConfig(BaseConfig):
    """监控配置"""
    enabled: bool = True
    collection_interval: int = 60
    retention_days: int = 7
    alert_thresholds: Dict[str, float] = field(default_factory=lambda: {
        "cpu_warning": 80.0,
        "cpu_critical": 90.0,
        "memory_warning": 80.0,
        "memory_critical": 90.0,
        "disk_warning": 80.0,
        "disk_critical": 90.0
    })

@dataclass
class SecurityConfig(BaseConfig):
    """安全配置"""
    secret_key: str = ""
    token_expiration: int = 3600
    allowed_origins: List[str] = field(default_factory=list)
    rate_limit: Dict[str, Any] = field(default_factory=lambda: {
        "enabled": True,
        "requests_per_minute": 60,
        "burst_size": 100
    })
    ssl_config: Dict[str, Any] = field(default_factory=lambda: {
        "enabled": False,
        "cert_file": "",
        "key_file": ""
    })

@dataclass
class AppConfig(BaseConfig):
    """应用配置"""
    app_name: str = "MyApp"
    version: str = "1.0.0"
    environment: str = "development"
    debug: bool = False
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 4
    database: DatabaseConfig = field(default_factory=DatabaseConfig)
    redis: RedisConfig = field(default_factory=RedisConfig)
    logging: LogConfig = field(default_factory=LogConfig)
    monitor: MonitorConfig = field(default_factory=MonitorConfig)
    security: SecurityConfig = field(default_factory=SecurityConfig)

    def validate(self) -> bool:
        """验证配置"""
        if not super().validate():
            return False
            
        # 验证子配置
        if not all([
            self.database.validate(),
            self.redis.validate(),
            self.logging.validate(),
            self.monitor.validate(),
            self.security.validate()
        ]):
            return False
            
        # 验证环境设置
        if self.environment not in ["development", "testing", "production"]:
            return False
            
        # 验证端口范围
        if not (1024 <= self.port <= 65535):
            return False
            
        # 验证工作进程数
        if self.workers < 1:
            return False
            
        return True
