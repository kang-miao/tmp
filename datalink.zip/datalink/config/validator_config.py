from typing import Dict, Any, List
from dataclasses import dataclass
from config.base_config import BaseConfig

@dataclass
class ValidationRules:
    """验证规则配置"""
    max_price: float = 1000000.0
    min_price: float = 0.0
    max_volume: float = 10000.0
    min_volume: float = 0.0
    timestamp_tolerance: int = 60  # 秒

@dataclass
class ValidationConfig:
    """验证配置"""
    enabled: bool = True
    strict_mode: bool = False
    ignore_warnings: bool = False
    rules: ValidationRules = None

class ValidatorConfig(BaseConfig):
    """验证器配置类"""
    def __init__(self, config_path: str = None):
        super().__init__(config_path)
        self.validation = self._init_validation_config()
        
    def _init_validation_config(self) -> ValidationConfig:
        """初始化验证配置"""
        validation_config = self.config_data.get('validation', {})
        rules_config = validation_config.get('rules', {})
        
        rules = ValidationRules(
            max_price=rules_config.get('max_price', 1000000.0),
            min_price=rules_config.get('min_price', 0.0),
            max_volume=rules_config.get('max_volume', 10000.0),
            min_volume=rules_config.get('min_volume', 0.0),
            timestamp_tolerance=rules_config.get('timestamp_tolerance', 60)
        )
        
        return ValidationConfig(
            enabled=validation_config.get('enabled', True),
            strict_mode=validation_config.get('strict_mode', False),
            ignore_warnings=validation_config.get('ignore_warnings', False),
            rules=rules
        )
