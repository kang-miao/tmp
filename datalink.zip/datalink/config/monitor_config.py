from typing import Dict, Any, List
from dataclasses import dataclass
from config.base_config import BaseConfig

@dataclass
class MetricsConfig:
    """指标配置"""
    enabled: bool = True
    collection_interval: int = 60  # 秒
    retention_days: int = 7
    export_path: str = "/metrics"

@dataclass
class AlertingConfig:
    """告警配置"""
    enabled: bool = True
    check_interval: int = 300  # 秒
    notification_channels: List[str] = None

@dataclass
class LoggingConfig:
    """日志配置"""
    level: str = "INFO"
    format: str = "json"
    output_path: str = "logs/"
    rotation: str = "1 day"
    retention: str = "30 days"

class MonitorConfig(BaseConfig):
    """监控配置类"""
    def __init__(self, config_path: str = None):
        super().__init__(config_path)
        self.metrics = self._init_metrics_config()
        self.alerting = self._init_alerting_config()
        self.logging = self._init_logging_config()
        
    def _init_metrics_config(self) -> MetricsConfig:
        """初始化指标配置"""
        metrics_config = self.config_data.get('metrics', {})
        return MetricsConfig(
            enabled=metrics_config.get('enabled', True),
            collection_interval=metrics_config.get('collection_interval', 60),
            retention_days=metrics_config.get('retention_days', 7),
            export_path=metrics_config.get('export_path', "/metrics")
        )
        
    def _init_alerting_config(self) -> AlertingConfig:
        """初始化告警配置"""
        alerting_config = self.config_data.get('alerting', {})
        return AlertingConfig(
            enabled=alerting_config.get('enabled', True),
            check_interval=alerting_config.get('check_interval', 300),
            notification_channels=alerting_config.get(
                'notification_channels',
                ['email']
            )
        )
        
    def _init_logging_config(self) -> LoggingConfig:
        """初始化日志配置"""
        logging_config = self.config_data.get('logging', {})
        return LoggingConfig(
            level=logging_config.get('level', "INFO"),
            format=logging_config.get('format', "json"),
            output_path=logging_config.get('output_path', "logs/"),
            rotation=logging_config.get('rotation', "1 day"),
            retention=logging_config.get('retention', "30 days")
        )
