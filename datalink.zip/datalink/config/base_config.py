from typing import Dict, Any, Optional, Type, TypeVar
from pathlib import Path
import yaml
import json
from dataclasses import dataclass, asdict, fields
from abc import ABC
from logging import Logger

T = TypeVar('T', bound='BaseConfig')

@dataclass
class BaseConfig(ABC):
    """配置基类"""
    
    @classmethod
    def load_from_file(cls: Type[T], file_path: Path, logger: Logger) -> T:
        """从文件加载配置"""
        try:
            if file_path.suffix == '.yaml' or file_path.suffix == '.yml':
                with file_path.open('r', encoding='utf-8') as f:
                    data = yaml.safe_load(f)
            elif file_path.suffix == '.json':
                with file_path.open('r', encoding='utf-8') as f:
                    data = json.load(f)
            else:
                raise ValueError(f"Unsupported file format: {file_path.suffix}")
                
            return cls(**data)
            
        except Exception as e:
            logger.error(
                f"Failed to load config from {file_path}: {str(e)}",
                exc_info=True
            )
            raise

    def save_to_file(self, file_path: Path, logger: Logger):
        """保存配置到文件"""
        try:
            data = asdict(self)
            
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            if file_path.suffix == '.yaml' or file_path.suffix == '.yml':
                with file_path.open('w', encoding='utf-8') as f:
                    yaml.safe_dump(data, f, default_flow_style=False)
            elif file_path.suffix == '.json':
                with file_path.open('w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2)
            else:
                raise ValueError(f"Unsupported file format: {file_path.suffix}")
                
        except Exception as e:
            logger.error(
                f"Failed to save config to {file_path}: {str(e)}",
                exc_info=True
            )
            raise

    def validate(self) -> bool:
        """验证配置"""
        for field in fields(self):
            value = getattr(self, field.name)
            if field.default is not None and value is None:
                return False
        return True

    def update(self, updates: Dict[str, Any]):
        """更新配置"""
        for key, value in updates.items():
            if hasattr(self, key):
                setattr(self, key, value)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return asdict(self)
