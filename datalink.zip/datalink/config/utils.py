from typing import Dict, Any, Optional
from pathlib import Path
import os
import json
import yaml
from cryptography.fernet import Fernet
from logging import Logger

class ConfigUtils:
    """配置工具类"""
    
    @staticmethod
    def load_env_vars(prefix: str, config: Dict[str, Any]):
        """从环境变量加载配置"""
        for key, value in os.environ.items():
            if key.startswith(prefix):
                config_key = key[len(prefix):].lower()
                try:
                    # 尝试解析JSON值
                    config[config_key] = json.loads(value)
                except json.JSONDecodeError:
                    # 如果不是JSON，直接使用字符串值
                    config[config_key] = value

    @staticmethod
    def encrypt_sensitive_data(data: str, key: bytes) -> str:
        """加密敏感数据"""
        f = Fernet(key)
        return f.encrypt(data.encode()).decode()

    @staticmethod
    def decrypt_sensitive_data(encrypted_data: str, key: bytes) -> str:
        """解密敏感数据"""
        f = Fernet(key)
        return f.decrypt(encrypted_data.encode()).decode()

    @staticmethod
    def merge_configs(base: Dict[str, Any],
                     override: Dict[str, Any]) -> Dict[str, Any]:
        """合并配置"""
        result = base.copy()
        
        for key, value in override.items():
            if (
                key in result and 
                isinstance(result[key], dict) and 
                isinstance(value, dict)
            ):
                result[key] = ConfigUtils.merge_configs(result[key], value)
            else:
                result[key] = value
                
        return result

    @staticmethod
    def validate_file_paths(config: Dict[str, Any],
                          base_dir: Optional[Path] = None) -> bool:
        """验证文件路径"""
        for key, value in config.items():
            if isinstance(value, str) and (
                key.endswith('_path') or 
                key.endswith('_file') or 
                key.endswith('_dir')
            ):
                path = Path(value)
                if base_dir:
                    path = base_dir / path
                if not path.exists():
                    return False
            elif isinstance(value, dict):
                if not ConfigUtils.validate_file_paths(value, base_dir):
                    return False
        return True

    @staticmethod
    def format_config(config: Dict[str, Any],
                     indent: int = 0,
                     hide_secrets: bool = True) -> str:
        """格式化配置输出"""
        lines = []
        for key, value in config.items():
            prefix = ' ' * indent
            if hide_secrets and ('password' in key.lower() or 
                               'secret' in key.lower() or 
                               'key' in key.lower()):
                lines.append(f"{prefix}{key}: ****")
            elif isinstance(value, dict):
                lines.append(f"{prefix}{key}:")
                lines.append(ConfigUtils.format_config(
                    value, indent + 2, hide_secrets
                ))
            else:
                lines.append(f"{prefix}{key}: {value}")
        return '\n'.join(lines)
