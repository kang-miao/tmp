# config/settings.py

"""
DataLink系统配置文件
包含所有组件的配置参数
"""

import os
from datetime import timedelta

# 基础配置
DEBUG = True
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 日志配置
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'standard': {
            'format': '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
        },
        'json': {
            'class': 'utils.logger.JsonFormatter'
        }
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'standard',
            'level': 'INFO'
        },
        'file': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': 'logs/datalink.log',
            'formatter': 'standard',
            'maxBytes': 10485760,  # 10MB
            'backupCount': 5,
            'level': 'INFO'
        },
        'monitor': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': 'logs/monitor.log',
            'formatter': 'json',
            'maxBytes': 10485760,  # 10MB
            'backupCount': 5,
            'level': 'INFO'
        }
    },
    'loggers': {
        '': {
            'handlers': ['console', 'file'],
            'level': 'INFO'
        },
        'monitor': {
            'handlers': ['monitor'],
            'level': 'INFO',
            'propagate': False
        }
    }
}

# KeyDB配置
KEYDB_CONFIG = {
    'host': os.getenv('KEYDB_HOST', 'localhost'),
    'port': int(os.getenv('KEYDB_PORT', 6379)),
    'db': int(os.getenv('KEYDB_DB', 0)),
    'password': os.getenv('KEYDB_PASSWORD', None),
    'socket_timeout': 5,
    'retry_on_timeout': True,
    'decode_responses': True
}

# Redpanda配置
REDPANDA_CONFIG = {
    'bootstrap_servers': os.getenv('REDPANDA_SERVERS', 'localhost:9092'),
    'client_id': 'datalink',
    'acks': 'all',
    'compression_type': 'lz4',
    'batch_size': 16384,
    'linger_ms': 5,
    'max_in_flight_requests_per_connection': 1,
    'retry_backoff_ms': 100,
    'max_retries': 3
}

# RisingWave配置
RISINGWAVE_CONFIG = {
    'host': os.getenv('RISINGWAVE_HOST', 'localhost'),
    'port': int(os.getenv('RISINGWAVE_PORT', 4566)),
    'user': os.getenv('RISINGWAVE_USER', 'root'),
    'password': os.getenv('RISINGWAVE_PASSWORD', ''),
    'database': os.getenv('RISINGWAVE_DATABASE', 'risingwave'),
    'min_size': 5,
    'max_size': 20
}

# TDengine配置
TDENGINE_CONFIG = {
    'host': os.getenv('TDENGINE_HOST', 'localhost'),
    'port': int(os.getenv('TDENGINE_PORT', 6041)),
    'user': os.getenv('TDENGINE_USER', 'root'),
    'password': os.getenv('TDENGINE_PASSWORD', 'taosdata'),
    'database': os.getenv('TDENGINE_DATABASE', 'market_data')
}

# MinIO配置
MINIO_CONFIG = {
    'endpoint': os.getenv('MINIO_ENDPOINT', 'localhost:9000'),
    'access_key': os.getenv('MINIO_ACCESS_KEY', 'minioadmin'),
    'secret_key': os.getenv('MINIO_SECRET_KEY', 'minioadmin'),
    'secure': os.getenv('MINIO_SECURE', 'false').lower() == 'true',
    'region': os.getenv('MINIO_REGION', 'us-east-1'),
    'market_data_bucket': 'market-data',
    'backup_bucket': 'backup'
}

# 市场数据源配置
DATA_SOURCES = {
    'crypto': {
        'exchanges': ['Binance'],
        'symbols': [
            'BTC-USDT',
            'ETH-USDT',
            'BNB-USDT'
        ],
        'channels': [
            'trades',
            'order_book',
            'kline'
        ],
        'Binance': {
            'api_key': os.getenv('BINANCE_API_KEY', ''),
            'api_secret': os.getenv('BINANCE_API_SECRET', ''),
            'testnet': False,
            'rate_limit': {
                'requests_per_minute': 1200,
                'orders_per_second': 10
            }
        }
    }
}

# 监控配置
MONITOR_CONFIG = {
    'update_interval': 5,  # 秒
    'metrics_retention': timedelta(days=7),
    'alert_thresholds': {
        'error_rate': 0.01,  # 1%
        'latency_ms': 1000,  # 1秒
        'message_rate_min': 10  # 每秒至少10条消息
    }
}

# 系统健康检查配置
HEALTH_CHECK_CONFIG = {
    'check_interval': 60,  # 秒
    'timeout': 5,  # 秒
    'retry_count': 3,
    'components': [
        'keydb',
        'redpanda',
        'risingwave',
        'tdengine',
        'minio'
    ]
}