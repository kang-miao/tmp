from typing import Dict, Any, List
from dataclasses import dataclass
from config.base_config import BaseConfig

@dataclass
class CheckInterval:
    """检查间隔配置"""
    trade: int = 300  # 秒
    orderbook: int = 60
    kline: int = 300

@dataclass
class ConsistencyRules:
    """一致性规则配置"""
    price_tolerance: float = 1e-8
    volume_tolerance: float = 1e-8
    timestamp_tolerance: int = 1  # 秒

@dataclass
class CheckerConfig:
    """检查器配置"""
    enabled: bool = True
    auto_repair: bool = False
    check_interval: CheckInterval = None
    rules: ConsistencyRules = None

class DataCheckerConfig(BaseConfig):
    """数据检查器配置类"""
    def __init__(self, config_path: str = None):
        super().__init__(config_path)
        self.checker = self._init_checker_config()
        
    def _init_checker_config(self) -> CheckerConfig:
        """初始化检查器配置"""
        checker_config = self.config_data.get('checker', {})
        interval_config = checker_config.get('interval', {})
        rules_config = checker_config.get('rules', {})
        
        interval = CheckInterval(
            trade=interval_config.get('trade', 300),
            orderbook=interval_config.get('orderbook', 60),
            kline=interval_config.get('kline', 300)
        )
        
        rules = ConsistencyRules(
            price_tolerance=rules_config.get('price_tolerance', 1e-8),
            volume_tolerance=rules_config.get('volume_tolerance', 1e-8),
            timestamp_tolerance=rules_config.get('timestamp_tolerance', 1)
        )
        
        return CheckerConfig(
            enabled=checker_config.get('enabled', True),
            auto_repair=checker_config.get('auto_repair', False),
            check_interval=interval,
            rules=rules
        )
