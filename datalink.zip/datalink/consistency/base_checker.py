from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
import logging
from dataclasses import dataclass

@dataclass
class ConsistencyCheckResult:
    """一致性检查结果"""
    is_consistent: bool
    inconsistencies: List[str]
    details: Dict[str, Any]
    timestamp: datetime
    check_duration: float

class BaseConsistencyChecker(ABC):
    """一致性检查器基类"""
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        self.check_results: List[ConsistencyCheckResult] = []
        
    @abstractmethod
    async def check_consistency(self, **kwargs) -> ConsistencyCheckResult:
        """执行一致性检查"""
        pass
    
    def add_check_result(self, result: ConsistencyCheckResult):
        """添加检查结果"""
        self.check_results.append(result)
        if not result.is_consistent:
            self.logger.warning(
                f"Consistency check failed: {result.inconsistencies}"
            )
    
    def get_recent_results(self, 
                          time_window: timedelta = timedelta(hours=1)
                          ) -> List[ConsistencyCheckResult]:
        """获取最近的检查结果"""
        cutoff_time = datetime.now() - time_window
        return [
            result for result in self.check_results
            if result.timestamp > cutoff_time
        ]
    
    def get_consistency_stats(self) -> Dict[str, Any]:
        """获取一致性统计信息"""
        recent_results = self.get_recent_results()
        if not recent_results:
            return {}
            
        total_checks = len(recent_results)
        failed_checks = len([r for r in recent_results if not r.is_consistent])
        
        return {
            'total_checks': total_checks,
            'failed_checks': failed_checks,
            'success_rate': (total_checks - failed_checks) / total_checks,
            'avg_check_duration': sum(
                r.check_duration for r in recent_results
            ) / total_checks,
            'latest_check': recent_results[-1].timestamp.isoformat()
        }
