import time
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
from consistency.base_checker import BaseConsistencyChecker, ConsistencyCheckResult

class DataConsistencyChecker(BaseConsistencyChecker):
    """数据一致性检查器"""
    def __init__(self, storage_clients: Dict[str, Any]):
        super().__init__()
        self.storage = storage_clients
        
    async def check_consistency(self, 
                              market_type: str,
                              exchange: str,
                              symbol: str,
                              start_time: datetime,
                              end_time: datetime) -> ConsistencyCheckResult:
        """检查数据一致性"""
        start_check = time.time()
        inconsistencies = []
        details = {}
        
        try:
            # 检查交易数据一致性
            trade_consistency = await self._check_trade_consistency(
                market_type, exchange, symbol, start_time, end_time
            )
            details['trade'] = trade_consistency
            if not trade_consistency['is_consistent']:
                inconsistencies.extend(trade_consistency['inconsistencies'])
            
            # 检查订单簿数据一致性
            orderbook_consistency = await self._check_orderbook_consistency(
                market_type, exchange, symbol, start_time, end_time
            )
            details['orderbook'] = orderbook_consistency
            if not orderbook_consistency['is_consistent']:
                inconsistencies.extend(orderbook_consistency['inconsistencies'])
            
            # 检查K线数据一致性
            kline_consistency = await self._check_kline_consistency(
                market_type, exchange, symbol, start_time, end_time
            )
            details['kline'] = kline_consistency
            if not kline_consistency['is_consistent']:
                inconsistencies.extend(kline_consistency['inconsistencies'])
            
        except Exception as e:
            inconsistencies.append(f"Error during consistency check: {str(e)}")
        
        check_duration = time.time() - start_check
        result = ConsistencyCheckResult(
            is_consistent=len(inconsistencies) == 0,
            inconsistencies=inconsistencies,
            details=details,
            timestamp=datetime.now(),
            check_duration=check_duration
        )
        
        self.add_check_result(result)
        return result
    
    async def _check_trade_consistency(self,
                                     market_type: str,
                                     exchange: str,
                                     symbol: str,
                                     start_time: datetime,
                                     end_time: datetime) -> Dict[str, Any]:
        """检查交易数据一致性"""
        inconsistencies = []
        
        # 从TDengine获取交易数据
        tdengine_trades = await self.storage['tdengine'].query_trades(
            market_type, exchange, symbol, start_time, end_time
        )
        
        # 从Redpanda获取交易数据
        redpanda_trades = await self.storage['redpanda'].consume_messages(
            topics=['trades.raw'],
            start_time=start_time,
            end_time=end_time,
            filters={
                'exchange': exchange,
                'symbol': symbol
            }
        )
        
        # 比较数据一致性
        if len(tdengine_trades) != len(redpanda_trades):
            inconsistencies.append(
                f"Trade count mismatch: TDengine={len(tdengine_trades)}, "
                f"Redpanda={len(redpanda_trades)}"
            )
        
        # 检查每笔交易的详细信息
        tdengine_trade_map = {
            trade['trade_id']: trade for trade in tdengine_trades
        }
        redpanda_trade_map = {
            trade['trade_id']: trade for trade in redpanda_trades
        }
        
        for trade_id in set(tdengine_trade_map) | set(redpanda_trade_map):
            if trade_id not in tdengine_trade_map:
                inconsistencies.append(f"Trade {trade_id} missing in TDengine")
            elif trade_id not in redpanda_trade_map:
                inconsistencies.append(f"Trade {trade_id} missing in Redpanda")
            else:
                td_trade = tdengine_trade_map[trade_id]
                rp_trade = redpanda_trade_map[trade_id]
                if td_trade['price'] != rp_trade['price']:
                    inconsistencies.append(
                        f"Price mismatch for trade {trade_id}"
                    )
                if td_trade['volume'] != rp_trade['volume']:
                    inconsistencies.append(
                        f"Volume mismatch for trade {trade_id}"
                    )
        
        return {
            'is_consistent': len(inconsistencies) == 0,
            'inconsistencies': inconsistencies,
            'tdengine_count': len(tdengine_trades),
            'redpanda_count': len(redpanda_trades)
        }
    
    async def _check_orderbook_consistency(self,
                                         market_type: str,
                                         exchange: str,
                                         symbol: str,
                                         start_time: datetime,
                                         end_time: datetime) -> Dict[str, Any]:
        """检查订单簿数据一致性"""
        inconsistencies = []
        
        # 从KeyDB获取最新订单簿
        keydb_book = await self.storage['keydb'].get_order_book(
            exchange, symbol
        )
        
        # 从RisingWave获取聚合订单簿
        risingwave_book = await self.storage['risingwave'].get_order_book(
            exchange, symbol
        )
        
        if not keydb_book or not risingwave_book:
            inconsistencies.append("Missing orderbook data")
            return {
                'is_consistent': False,
                'inconsistencies': inconsistencies
            }
        
        # 比较买卖盘深度
        if len(keydb_book['bids']) != len(risingwave_book['bids']):
            inconsistencies.append(
                f"Bid levels mismatch: KeyDB={len(keydb_book['bids'])}, "
                f"RisingWave={len(risingwave_book['bids'])}"
            )
        
        if len(keydb_book['asks']) != len(risingwave_book['asks']):
            inconsistencies.append(
                f"Ask levels mismatch: KeyDB={len(keydb_book['asks'])}, "
                f"RisingWave={len(risingwave_book['asks'])}"
            )
        
        # 比较价格和数量
        for i, (keydb_bid, rw_bid) in enumerate(
            zip(keydb_book['bids'], risingwave_book['bids'])
        ):
            if abs(keydb_bid[0] - rw_bid[0]) > 1e-8:
                inconsistencies.append(
                    f"Bid price mismatch at level {i}"
                )
            if abs(keydb_bid[1] - rw_bid[1]) > 1e-8:
                inconsistencies.append(
                    f"Bid quantity mismatch at level {i}"
                )
        
        for i, (keydb_ask, rw_ask) in enumerate(
            zip(keydb_book['asks'], risingwave_book['asks'])
        ):
            if abs(keydb_ask[0] - rw_ask[0]) > 1e-8:
                inconsistencies.append(
                    f"Ask price mismatch at level {i}"
                )
            if abs(keydb_ask[1] - rw_ask[1]) > 1e-8:
                inconsistencies.append(
                    f"Ask quantity mismatch at level {i}"
                )
        
        return {
            'is_consistent': len(inconsistencies) == 0,
            'inconsistencies': inconsistencies,
            'keydb_levels': {
                'bids': len(keydb_book['bids']),
                'asks': len(keydb_book['asks'])
            },
            'risingwave_levels': {
                'bids': len(risingwave_book['bids']),
                'asks': len(risingwave_book['asks'])
            }
        }
    
    async def _check_kline_consistency(self,
                                     market_type: str,
                                     exchange: str,
                                     symbol: str,
                                     start_time: datetime,
                                     end_time: datetime) -> Dict[str, Any]:
        """检查K线数据一致性"""
        inconsistencies = []
        
        # 从TDengine获取K线数据
        tdengine_klines = await self.storage['tdengine'].query_klines(
            market_type, exchange, symbol, start_time, end_time
        )
        
        # 从RisingWave获取聚合K线数据
        risingwave_klines = await self.storage['risingwave'].query_view(
            'minute_klines',
            conditions={
                'market_type': market_type,
                'exchange': exchange,
                'symbol': symbol,
                'timestamp': {
                    'start': start_time,
                    'end': end_time
                }
            }
        )
        
        if len(tdengine_klines) != len(risingwave_klines):
            inconsistencies.append(
                f"Kline count mismatch: TDengine={len(tdengine_klines)}, "
                f"RisingWave={len(risingwave_klines)}"
            )
        
        # 创建时间戳映射以比较相同时间的K线
        tdengine_kline_map = {
            k['timestamp'].isoformat(): k for k in tdengine_klines
        }
        risingwave_kline_map = {
            k['timestamp'].isoformat(): k for k in risingwave_klines
        }
        
        # 比较每个时间点的K线数据
        for timestamp in set(tdengine_kline_map) | set(risingwave_kline_map):
            if timestamp not in tdengine_kline_map:
                inconsistencies.append(
                    f"Kline at {timestamp} missing in TDengine"
                )
            elif timestamp not in risingwave_kline_map:
                inconsistencies.append(
                    f"Kline at {timestamp} missing in RisingWave"
                )
            else:
                td_kline = tdengine_kline_map[timestamp]
                rw_kline = risingwave_kline_map[timestamp]
                
                # 比较OHLCV值
                for field in ['open', 'high', 'low', 'close', 'volume']:
                    if abs(td_kline[field] - rw_kline[field]) > 1e-8:
                        inconsistencies.append(
                            f"{field.capitalize()} mismatch at {timestamp}"
                        )
        
        return {
            'is_consistent': len(inconsistencies) == 0,
            'inconsistencies': inconsistencies,
            'tdengine_count': len(tdengine_klines),
            'risingwave_count': len(risingwave_klines)
        }
