# adapters/futures/futures_adapter.py

import asyncio
import logging
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, timedelta
import pandas as pd
import tushare as ts
import akshare as ak

from core.market_data import MarketType, DataType
from adapters.base.base_adapter import BaseAdapter

class FuturesAdapter(BaseAdapter):
    """期货市场数据适配器
    
    用于获取中国商品期货市场的实时和历史数据，
    同时使用Tushare和AKShare作为数据源，确保数据可靠性。
    """

    def __init__(self, config: Dict[str, Any], callbacks: Optional[Dict] = None):
        """初始化期货适配器
        
        Args:
            config: 适配器配置
            callbacks: 数据回调函数字典
        """
        super().__init__(config, MarketType.FUTURES, callbacks)
        
        # Tushare配置
        self.tushare_token = config.get('tushare_token')
        if self.tushare_token:
            self.ts_api = ts.pro_api(self.tushare_token)
        else:
            self.ts_api = None
            self.logger.warning("Tushare API token not provided")
            
        # 数据缓存
        self.contract_cache: Dict[str, Dict] = {}  # 合约信息缓存
        self.dominant_cache: Dict[str, str] = {}   # 主力合约缓存
        
        # 重试配置
        self.max_retries = config.get('max_retries', 3)
        self.retry_delay = config.get('retry_delay', 1)
        
        # 更新间隔（秒）
        self.update_interval = config.get('update_interval', 3)
        
        # 运行标志
        self.is_running = False
        self._update_tasks = set()
        
        # 交易所映射
        self.exchange_map = {
            'SHFE': '上期所',
            'DCE': '大商所',
            'CZCE': '郑商所',
            'INE': '上能所',
            'CFFEX': '中金所'
        }

    async def connect(self) -> bool:
        """建立连接并初始化数据"""
        try:
            # 初始化合约信息
            await self._init_contract_cache()
            # 获取主力合约
            await self._update_dominant_contracts()
            
            self.logger.info("Connected to futures market data")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to connect to futures market: {e}")
            return False

    async def disconnect(self) -> None:
        """断开连接"""
        self.is_running = False
        for task in self._update_tasks:
            task.cancel()
        self._update_tasks.clear()
        self.logger.info("Disconnected from futures market")

    async def _init_contract_cache(self) -> None:
        """初始化期货合约信息缓存"""
        try:
            # 使用Tushare获取合约基本信息
            if self.ts_api:
                df = await self._retry_api_call(
                    self.ts_api.fut_basic,
                    exchange='',
                    fields='ts_code,symbol,name,exchange'
                )
                
                if df is not None and not df.empty:
                    for _, row in df.iterrows():
                        self.contract_cache[row['ts_code']] = row.to_dict()
            
            # 使用AKShare补充信息
            for exchange in self.exchange_map.keys():
                df = await self._retry_api_call(
                    ak.futures_contract_info,
                    symbol=exchange
                )
                
                if df is not None and not df.empty:
                    for _, row in df.iterrows():
                        symbol = f"{row['symbol']}.{exchange}"
                        if symbol not in self.contract_cache:
                            self.contract_cache[symbol] = {
                                'ts_code': symbol,
                                'symbol': row['symbol'],
                                'name': row['name'],
                                'exchange': exchange
                            }
            
            self.logger.info(f"Initialized {len(self.contract_cache)} contracts")
            
        except Exception as e:
            self.logger.error(f"Error initializing contract cache: {e}")
            raise

    async def _update_dominant_contracts(self) -> None:
        """更新主力合约信息"""
        try:
            # 从Tushare获取主力合约
            if self.ts_api:
                df = await self._retry_api_call(
                    self.ts_api.fut_mapping,
                    fields='ts_code,mapping_ts_code'
                )
                
                if df is not None and not df.empty:
                    for _, row in df.iterrows():
                        self.dominant_cache[row['ts_code']] = row['mapping_ts_code']
            
            # 使用AKShare补充信息
            for exchange in self.exchange_map.keys():
                df = await self._retry_api_call(
                    ak.futures_contract_detail,
                    symbol=exchange
                )
                
                if df is not None and not df.empty:
                    for _, row in df.iterrows():
                        if row.get('is_dominant', False):
                            symbol = f"{row['symbol']}.{exchange}"
                            self.dominant_cache[symbol] = symbol
            
            self.logger.info(f"Updated {len(self.dominant_cache)} dominant contracts")
            
        except Exception as e:
            self.logger.error(f"Error updating dominant contracts: {e}")
            raise

    async def _do_subscribe(self, symbols: List[str], channels: List[str]) -> bool:
        """实现期货订阅逻辑"""
        try:
            for symbol in symbols:
                task = asyncio.create_task(
                    self._update_loop(symbol, channels)
                )
                self._update_tasks.add(task)
                task.add_done_callback(self._update_tasks.discard)
                
            return True
            
        except Exception as e:
            self.logger.error(f"Subscribe error: {e}")
            return False

    async def _update_loop(self, symbol: str, channels: List[str]) -> None:
        """数据更新循环"""
        while self.is_running:
            try:
                for channel in channels:
                    if channel == 'trades':
                        data = await self._fetch_trades_with_fallback(symbol)
                        if data:
                            await self.handle_trade(data)
                    elif channel == 'kline':
                        data = await self._fetch_kline_with_fallback(symbol)
                        if data:
                            await self.handle_kline(data)
                            
                await asyncio.sleep(self.update_interval)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Update loop error for {symbol}: {e}")
                await asyncio.sleep(self.retry_delay)

    async def _fetch_trades_with_fallback(self, symbol: str) -> Optional[Dict[str, Any]]:
        """获取交易数据（带备份源）"""
        try:
            # 首先尝试使用Tushare
            if self.ts_api:
                data = await self._fetch_trades_tushare(symbol)
                if data:
                    return data
            
            # 如果Tushare失败，使用AKShare
            return await self._fetch_trades_akshare(symbol)
            
        except Exception as e:
            self.logger.error(f"Error fetching trades for {symbol}: {e}")
            return None

    async def _fetch_trades_tushare(self, symbol: str) -> Optional[Dict[str, Any]]:
        """从Tushare获取交易数据"""
        try:
            df = await self._retry_api_call(
                self.ts_api.fut_tick,
                ts_code=symbol,
                trade_date=datetime.now().strftime('%Y%m%d')
            )
            
            if df is not None and not df.empty:
                row = df.iloc[-1]
                return {
                    'exchange': row['exchange'],
                    'symbol': symbol,
                    'timestamp': pd.to_datetime(
                        f"{row['trade_date']} {row['trade_time']}"
                    ),
                    'price': float(row['price']),
                    'volume': float(row['vol']),
                    'amount': float(row['amount']),
                    'side': 'buy' if row['side'] == 'B' else 'sell',
                    'trade_id': str(row['seq'])
                }
            return None
            
        except Exception as e:
            self.logger.error(f"Error fetching Tushare trades for {symbol}: {e}")
            return None

    async def _fetch_trades_akshare(self, symbol: str) -> Optional[Dict[str, Any]]:
        """从AKShare获取交易数据"""
        try:
            exchange = symbol.split('.')[-1]
            df = await self._retry_api_call(
                ak.futures_zh_realtime,
                symbol=exchange
            )
            
            if df is not None and not df.empty:
                row = df[df['symbol'] == symbol].iloc[-1]
                return {
                    'exchange': self.exchange_map.get(exchange, exchange),
                    'symbol': symbol,
                    'timestamp': datetime.now(),
                    'price': float(row['last_price']),
                    'volume': float(row['volume']),
                    'amount': float(row['amount']),
                    'side': 'buy',  # AKShare不提供交易方向
                    'trade_id': None
                }
            return None
            
        except Exception as e:
            self.logger.error(f"Error fetching AKShare trades for {symbol}: {e}")
            return None

    async def _fetch_kline_with_fallback(self, symbol: str) -> Optional[Dict[str, Any]]:
        """获取K线数据（带备份源）"""
        try:
            # 首先尝试使用Tushare
            if self.ts_api:
                data = await self._fetch_kline_tushare(symbol)
                if data:
                    return data
            
            # 如果Tushare失败，使用AKShare
            return await self._fetch_kline_akshare(symbol)
            
        except Exception as e:
            self.logger.error(f"Error fetching kline for {symbol}: {e}")
            return None

    async def _fetch_kline_tushare(self, symbol: str) -> Optional[Dict[str, Any]]:
        """从Tushare获取K线数据"""
        try:
            end_time = datetime.now()
            start_time = end_time - timedelta(minutes=1)
            
            df = await self._retry_api_call(
                self.ts_api.fut_1min,
                ts_code=symbol,
                start_date=start_time.strftime('%Y%m%d %H:%M:%S'),
                end_date=end_time.strftime('%Y%m%d %H:%M:%S')
            )
            
            if df is not None and not df.empty:
                row = df.iloc[-1]
                return {
                    'exchange': row['exchange'],
                    'symbol': symbol,
                    'timestamp': pd.to_datetime(row['trade_time']),
                    'interval': '1m',
                    'open': float(row['open']),
                    'high': float(row['high']),
                    'low': float(row['low']),
                    'close': float(row['close']),
                    'volume': float(row['vol']),
                    'amount': float(row['amount'])
                }
            return None
            
        except Exception as e:
            self.logger.error(f"Error fetching Tushare kline for {symbol}: {e}")
            return None

    async def _fetch_kline_akshare(self, symbol: str) -> Optional[Dict[str, Any]]:
        """从AKShare获取K线数据"""
        try:
            df = await self._retry_api_call(
                ak.futures_zh_minute_sina,
                symbol=symbol.split('.')[0]
            )
            
            if df is not None and not df.empty:
                row = df.iloc[-1]
                return {
                    'exchange': symbol.split('.')[-1],
                    'symbol': symbol,
                    'timestamp': pd.to_datetime(row.name),
                    'interval': '1m',
                    'open': float(row['open']),
                    'high': float(row['high']),
                    'low': float(row['low']),
                    'close': float(row['close']),
                    'volume': float(row['volume']),
                    'amount': float(row['amount'])
                }
            return None
            
        except Exception as e:
            self.logger.error(f"Error fetching AKShare kline for {symbol}: {e}")
            return None

    async def _retry_api_call(self, func, *args, **kwargs) -> Optional[pd.DataFrame]:
        """重试API调用"""
        for i in range(self.max_retries):
            try:
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None, func, *args, **kwargs
                )
                return result
                
            except Exception as e:
                if i == self.max_retries - 1:
                    raise
                self.logger.warning(f"API call failed (attempt {i+1}): {e}")
                await asyncio.sleep(self.retry_delay * (i + 1))
                
        return None

    async def get_contract_info(self, symbol: str) -> Optional[Dict[str, Any]]:
        """获取合约信息"""
        return self.contract_cache.get(symbol)

    async def get_dominant_contract(self, symbol: str) -> Optional[str]:
        """获取主力合约代码"""
        return self.dominant_cache.get(symbol)

    async def get_futures_info(self, symbols: List[str]) -> pd.DataFrame:
        """获取期货合约的基本信息"""
        result = []
        for symbol in symbols:
            info = await self.get_contract_info(symbol)
            if info:
                result.append(info)
        return pd.DataFrame(result)

    async def get_exchange_status(self, exchange: str) -> Optional[Dict[str, Any]]:
        """获取交易所状态"""
        try:
            if self.ts_api:
                df = await self._retry_api_call(
                    self.ts_api.fut_exchange,
                    exchange=exchange
                )
                if df is not None and not df.empty:
                    return df.iloc[0].to_dict()
            return None
            
        except Exception as e:
            self.logger.error(f"Error getting exchange status: {e}")
            return None