# adapters/stock/akshare_adapter.py

import asyncio
import logging
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, timedelta
import pandas as pd
import akshare as ak

from core.market_data import MarketType, DataType
from adapters.base.base_adapter import BaseAdapter

class AKShareAdapter(BaseAdapter):
    """AKShare股票数据适配器
    
    作为Tushare的备份数据源，提供中国股票市场的实时和历史数据。
    支持数据对比和互补功能。
    """

    def __init__(self, config: Dict[str, Any], callbacks: Optional[Dict] = None):
        """初始化AKShare适配器
        
        Args:
            config: 适配器配置
            callbacks: 数据回调函数字典
        """
        super().__init__(config, MarketType.STOCK_CN, callbacks)
        
        # 数据缓存
        self.symbol_cache: Dict[str, Dict] = {}
        self.quote_cache: Dict[str, pd.DataFrame] = {}
        
        # 重试配置
        self.max_retries = config.get('max_retries', 3)
        self.retry_delay = config.get('retry_delay', 1)
        
        # 更新间隔（秒）
        self.update_interval = config.get('update_interval', 3)
        
        # 运行标志
        self.is_running = False
        self._update_tasks = set()
        
        # 市场代码映射
        self.market_map = {
            'sh': 'SSE',  # 上交所
            'sz': 'SZSE'  # 深交所
        }

    async def connect(self) -> bool:
        """建立连接并初始化数据"""
        try:
            # 初始化股票列表
            await self._init_symbol_cache()
            
            self.logger.info("Connected to AKShare API")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to connect to AKShare: {e}")
            return False

    async def disconnect(self) -> None:
        """断开连接"""
        self.is_running = False
        for task in self._update_tasks:
            task.cancel()
        self._update_tasks.clear()
        self.logger.info("Disconnected from AKShare")

    async def _init_symbol_cache(self) -> None:
        """初始化股票基本信息缓存"""
        try:
            # 获取沪深两市股票列表
            sh_df = await self._retry_api_call(ak.stock_info_sh_name_code)
            sz_df = await self._retry_api_call(ak.stock_info_sz_name_code)
            
            # 处理上交所股票
            for _, row in sh_df.iterrows():
                symbol = f"{row['code']}.SH"
                self.symbol_cache[symbol] = {
                    'code': row['code'],
                    'name': row['name'],
                    'market': 'SSE'
                }
            
            # 处理深交所股票
            for _, row in sz_df.iterrows():
                symbol = f"{row['code']}.SZ"
                self.symbol_cache[symbol] = {
                    'code': row['code'],
                    'name': row['name'],
                    'market': 'SZSE'
                }
                
            self.logger.info(f"Initialized {len(self.symbol_cache)} symbols")
            
        except Exception as e:
            self.logger.error(f"Error initializing symbol cache: {e}")
            raise

    async def _do_subscribe(self, symbols: List[str], channels: List[str]) -> bool:
        """实现AKShare的订阅逻辑"""
        try:
            for symbol in symbols:
                task = asyncio.create_task(
                    self._update_loop(symbol, channels)
                )
                self._update_tasks.add(task)
                task.add_done_callback(self._update_tasks.discard)
                
            return True
            
        except Exception as e:
            self.logger.error(f"Subscribe error: {e}")
            return False

    async def _update_loop(self, symbol: str, channels: List[str]) -> None:
        """数据更新循环"""
        while self.is_running:
            try:
                if 'trades' in channels:
                    await self._fetch_trades(symbol)
                if 'kline' in channels:
                    await self._fetch_kline(symbol)
                    
                await asyncio.sleep(self.update_interval)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Update loop error for {symbol}: {e}")
                await asyncio.sleep(self.retry_delay)

    async def _fetch_trades(self, symbol: str) -> None:
        """获取交易数据"""
        try:
            # 获取实时交易数据
            df = await self._retry_api_call(
                ak.stock_zh_a_tick_tx,
                symbol=symbol.split('.')[0]
            )
            
            if df is not None and not df.empty:
                for _, row in df.iterrows():
                    trade_data = {
                        'exchange': 'A股',
                        'symbol': symbol,
                        'timestamp': pd.to_datetime(row['成交时间']),
                        'price': float(row['成交价格']),
                        'amount': float(row['成交量']),
                        'trade_id': str(row['成交编号']) if '成交编号' in row else None,
                        'side': 'buy' if row.get('性质') == '买盘' else 'sell'
                    }
                    await self.handle_trade(trade_data)
                    
        except Exception as e:
            self.logger.error(f"Error fetching trades for {symbol}: {e}")
            raise

    async def _fetch_kline(self, symbol: str) -> None:
        """获取K线数据"""
        try:
            # 获取1分钟K线数据
            df = await self._retry_api_call(
                ak.stock_zh_a_minute,
                symbol=symbol.split('.')[0],
                period='1',
                adjust='qfq'  # 前复权
            )
            
            if df is not None and not df.empty:
                for _, row in df.iterrows():
                    kline_data = {
                        'exchange': 'A股',
                        'symbol': symbol,
                        'timestamp': pd.to_datetime(row['时间']),
                        'interval': '1m',
                        'open': float(row['开盘']),
                        'high': float(row['最高']),
                        'low': float(row['最低']),
                        'close': float(row['收盘']),
                        'volume': float(row['成交量']),
                        'amount': float(row['成交额'])
                    }
                    await self.handle_kline(kline_data)
                    
        except Exception as e:
            self.logger.error(f"Error fetching kline for {symbol}: {e}")
            raise

    async def _retry_api_call(self, func, *args, **kwargs) -> Optional[pd.DataFrame]:
        """重试API调用"""
        for i in range(self.max_retries):
            try:
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None, func, *args, **kwargs
                )
                return result
                
            except Exception as e:
                if i == self.max_retries - 1:
                    raise
                self.logger.warning(f"API call failed (attempt {i+1}): {e}")
                await asyncio.sleep(self.retry_delay * (i + 1))
                
        return None

    async def _do_unsubscribe(self, symbols: List[str], channels: List[str]) -> bool:
        """实现取消订阅逻辑"""
        try:
            for task in self._update_tasks:
                task.cancel()
            self._update_tasks.clear()
            return True
            
        except Exception as e:
            self.logger.error(f"Unsubscribe error: {e}")
            return False

    async def get_stock_info(self, symbol: str) -> Optional[Dict[str, Any]]:
        """获取股票基本信息"""
        return self.symbol_cache.get(symbol)

    async def get_realtime_quotes(self, symbols: List[str]) -> Optional[pd.DataFrame]:
        """获取实时行情"""
        try:
            df = await self._retry_api_call(
                ak.stock_zh_a_spot_em,
                symbol=','.join([s.split('.')[0] for s in symbols])
            )
            return df
            
        except Exception as e:
            self.logger.error(f"Error getting realtime quotes: {e}")
            return None

    async def get_index_data(self, index_code: str) -> Optional[pd.DataFrame]:
        """获取指数数据"""
        try:
            df = await self._retry_api_call(
                ak.stock_zh_index_spot,
                symbol=index_code
            )
            return df
            
        except Exception as e:
            self.logger.error(f"Error getting index data: {e}")
            return None

    async def compare_with_tushare(self, symbol: str, 
                                 tushare_data: Dict[str, Any]) -> Tuple[bool, str]:
        """与Tushare数据对比
        
        Args:
            symbol: 股票代码
            tushare_data: Tushare的数据
            
        Returns:
            Tuple[bool, str]: (数据是否一致, 差异说明)
        """
        try:
            # 获取AKShare的数据
            akshare_data = await self.get_realtime_quotes([symbol])
            
            if akshare_data is None or akshare_data.empty:
                return False, "AKShare data not available"
            
            # 比较关键字段
            fields_to_compare = ['price', 'volume', 'amount']
            differences = []
            
            for field in fields_to_compare:
                tushare_value = tushare_data.get(field)
                akshare_value = akshare_data.iloc[0].get(field)
                
                if abs(float(tushare_value) - float(akshare_value)) > 0.000001:
                    differences.append(
                        f"{field}: Tushare={tushare_value}, AKShare={akshare_value}"
                    )
            
            return len(differences) == 0, "\n".join(differences)
            
        except Exception as e:
            self.logger.error(f"Error comparing data: {e}")
            return False, str(e)