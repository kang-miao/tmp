# adapters/stock/tushare_adapter.py

import asyncio
import logging
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, timedelta
import pandas as pd
import tushare as ts

from core.market_data import MarketType, DataType
from adapters.base.base_adapter import BaseAdapter

class TushareAdapter(BaseAdapter):
    """Tushare股票数据适配器
    
    用于获取中国股票市场的实时和历史数据，
    支持与Akshare数据源的冗余备份。
    """

    def __init__(self, config: Dict[str, Any], callbacks: Optional[Dict] = None):
        """初始化Tushare适配器
        
        Args:
            config: 适配器配置
            callbacks: 数据回调函数字典
        """
        super().__init__(config, MarketType.STOCK_CN, callbacks)
        
        # Tushare配置
        self.api_token = config.get('tushare_token')
        if not self.api_token:
            raise ValueError("Tushare API token is required")
            
        # 初始化Tushare
        self.api = ts.pro_api(self.api_token)
        
        # 数据缓存
        self.symbol_cache: Dict[str, Dict] = {}  # 股票基本信息缓存
        self.quote_cache: Dict[str, pd.DataFrame] = {}  # 行情数据缓存
        
        # 重试配置
        self.max_retries = config.get('max_retries', 3)
        self.retry_delay = config.get('retry_delay', 1)
        
        # 数据更新间隔（秒）
        self.update_interval = config.get('update_interval', 3)
        
        # 运行标志
        self.is_running = False
        self._update_tasks = set()

    async def connect(self) -> bool:
        """建立与Tushare的连接"""
        try:
            # 测试API连接
            self.api.query('stock_basic', exchange='SSE', limit=1)
            
            # 初始化股票基本信息缓存
            await self._init_symbol_cache()
            
            self.logger.info("Connected to Tushare API")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to connect to Tushare: {e}")
            return False

    async def disconnect(self) -> None:
        """断开与Tushare的连接"""
        self.is_running = False
        for task in self._update_tasks:
            task.cancel()
        self._update_tasks.clear()
        self.logger.info("Disconnected from Tushare")

    async def _init_symbol_cache(self) -> None:
        """初始化股票基本信息缓存"""
        try:
            # 获取所有上市公司基本信息
            df = self.api.stock_basic(
                exchange='',
                list_status='L',
                fields='ts_code,symbol,name,area,industry,list_date'
            )
            
            # 更新缓存
            for _, row in df.iterrows():
                self.symbol_cache[row['ts_code']] = row.to_dict()
                
            self.logger.info(f"Initialized {len(self.symbol_cache)} symbols")
            
        except Exception as e:
            self.logger.error(f"Error initializing symbol cache: {e}")
            raise

    async def _do_subscribe(self, symbols: List[str], channels: List[str]) -> bool:
        """实现Tushare的订阅逻辑"""
        try:
            for symbol in symbols:
                # 为每个股票创建更新任务
                task = asyncio.create_task(
                    self._update_loop(symbol, channels)
                )
                self._update_tasks.add(task)
                task.add_done_callback(self._update_tasks.discard)
                
            return True
            
        except Exception as e:
            self.logger.error(f"Subscribe error: {e}")
            return False

    async def _update_loop(self, symbol: str, channels: List[str]) -> None:
        """数据更新循环"""
        while self.is_running:
            try:
                # 获取最新数据
                if 'trades' in channels:
                    await self._fetch_trades(symbol)
                if 'kline' in channels:
                    await self._fetch_kline(symbol)
                    
                await asyncio.sleep(self.update_interval)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Update loop error for {symbol}: {e}")
                await asyncio.sleep(self.retry_delay)

    async def _fetch_trades(self, symbol: str) -> None:
        """获取交易数据"""
        try:
            df = await self._retry_api_call(
                self.api.tick_data,
                ts_code=symbol,
                trade_date=datetime.now().strftime('%Y%m%d')
            )
            
            if df is not None and not df.empty:
                # 转换并处理每条交易记录
                for _, row in df.iterrows():
                    trade_data = {
                        'exchange': 'A股',
                        'symbol': symbol,
                        'timestamp': pd.to_datetime(
                            f"{row['trade_date']} {row['trade_time']}"
                        ),
                        'price': float(row['price']),
                        'amount': float(row['vol']),
                        'trade_id': str(row['seq']),
                        'side': 'buy' if row['side'] == 'B' else 'sell'
                    }
                    await self.handle_trade(trade_data)
                    
        except Exception as e:
            self.logger.error(f"Error fetching trades for {symbol}: {e}")
            raise

    async def _fetch_kline(self, symbol: str) -> None:
        """获取K线数据"""
        try:
            end_time = datetime.now()
            start_time = end_time - timedelta(minutes=1)
            
            df = await self._retry_api_call(
                self.api.query,
                'min_data',
                ts_code=symbol,
                start_date=start_time.strftime('%Y%m%d %H:%M:%S'),
                end_date=end_time.strftime('%Y%m%d %H:%M:%S'),
                freq='1min'
            )
            
            if df is not None and not df.empty:
                for _, row in df.iterrows():
                    kline_data = {
                        'exchange': 'A股',
                        'symbol': symbol,
                        'timestamp': pd.to_datetime(row['trade_time']),
                        'interval': '1m',
                        'open': float(row['open']),
                        'high': float(row['high']),
                        'low': float(row['low']),
                        'close': float(row['close']),
                        'volume': float(row['vol']),
                        'amount': float(row['amount'])
                    }
                    await self.handle_kline(kline_data)
                    
        except Exception as e:
            self.logger.error(f"Error fetching kline for {symbol}: {e}")
            raise

    async def _retry_api_call(self, func, *args, **kwargs) -> Optional[pd.DataFrame]:
        """重试API调用"""
        for i in range(self.max_retries):
            try:
                # 使用同步API调用
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None, func, *args, **kwargs
                )
                return result
                
            except Exception as e:
                if i == self.max_retries - 1:
                    raise
                self.logger.warning(f"API call failed (attempt {i+1}): {e}")
                await asyncio.sleep(self.retry_delay * (i + 1))
                
        return None

    async def _do_unsubscribe(self, symbols: List[str], channels: List[str]) -> bool:
        """实现取消订阅逻辑"""
        try:
            # 停止相关的更新任务
            for task in self._update_tasks:
                task.cancel()
            self._update_tasks.clear()
            return True
            
        except Exception as e:
            self.logger.error(f"Unsubscribe error: {e}")
            return False

    def _validate_symbol(self, symbol: str) -> bool:
        """验证股票代码是否有效"""
        return symbol in self.symbol_cache

    async def get_stock_info(self, symbol: str) -> Optional[Dict[str, Any]]:
        """获取股票基本信息"""
        try:
            if not self._validate_symbol(symbol):
                raise ValueError(f"Invalid symbol: {symbol}")
            
            return self.symbol_cache.get(symbol)
            
        except Exception as e:
            self.logger.error(f"Error getting stock info for {symbol}: {e}")
            return None

    async def get_trading_status(self, symbol: str) -> Optional[Dict[str, Any]]:
        """获取股票交易状态"""
        try:
            if not self._validate_symbol(symbol):
                raise ValueError(f"Invalid symbol: {symbol}")
                
            df = await self._retry_api_call(
                self.api.query,
                'trading_status',
                ts_code=symbol
            )
            
            if df is not None and not df.empty:
                return df.iloc[0].to_dict()
            return None
            
        except Exception as e:
            self.logger.error(f"Error getting trading status for {symbol}: {e}")
            return None

    async def get_suspended_stocks(self) -> List[str]:
        """获取停牌股票列表"""
        try:
            df = await self._retry_api_call(
                self.api.query,
                'suspended_d'
            )
            
            if df is not None and not df.empty:
                return df['ts_code'].tolist()
            return []
            
        except Exception as e:
            self.logger.error(f"Error getting suspended stocks: {e}")
            return []