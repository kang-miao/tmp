# adapters/crypto/binance_adapter.py

import aiohttp
import json
import hmac
import hashlib
import time
from typing import Dict, List, Any, Optional
from datetime import datetime
import asyncio
import logging
from urllib.parse import urlencode

from core.market_data import (
    MarketType, DataType, OrderBookLevel,
    MarketDataFactory
)
from adapters.base.base_adapter import BaseAdapter

class BinanceAdapter(BaseAdapter):
    """币安交易所数据适配器
    
    支持现货、永续合约和期权市场的实时数据订阅
    """

    def __init__(self, config: Dict[str, Any], callbacks: Optional[Dict] = None):
        """初始化币安适配器
        
        Args:
            config: 适配器配置
            callbacks: 数据回调函数字典
        """
        super().__init__(config, MarketType.CRYPTO, callbacks)
        
        # API配置
        self.api_key = config.get('api_key')
        self.api_secret = config.get('api_secret')
        self.base_url = config.get('base_url', 'https://api.binance.com')
        self.ws_url = config.get('ws_url', 'wss://stream.binance.com:9443/ws')
        
        # WebSocket连接
        self.ws: Optional[aiohttp.ClientWebSocketResponse] = None
        self.session: Optional[aiohttp.ClientSession] = None
        
        # 订单簿缓存
        self.order_book_cache: Dict[str, Dict] = {}
        
        # 市场类型映射
        self.market_mapping = {
            'spot': 'SPOT',
            'futures': 'UM',  # U-Margin Futures
            'options': 'OPTION'
        }

    async def connect(self) -> bool:
        """建立与币安的WebSocket连接"""
        try:
            self.session = aiohttp.ClientSession()
            self.ws = await self.session.ws_connect(self.ws_url)
            self.logger.info("Connected to Binance WebSocket")
            asyncio.create_task(self._heartbeat())
            asyncio.create_task(self._message_handler())
            return True
        except Exception as e:
            self.logger.error(f"Failed to connect to Binance: {e}")
            return False

    async def disconnect(self) -> None:
        """断开与币安的连接"""
        try:
            if self.ws:
                await self.ws.close()
            if self.session:
                await self.session.close()
            self.ws = None
            self.session = None
            self.logger.info("Disconnected from Binance")
        except Exception as e:
            self.logger.error(f"Error disconnecting from Binance: {e}")

    async def _do_subscribe(self, symbols: List[str], channels: List[str]) -> bool:
        """实现币安的订阅逻辑
        
        Args:
            symbols: 交易对列表
            channels: 数据类型列表
            
        Returns:
            bool: 订阅是否成功
        """
        try:
            # 构建订阅消息
            streams = []
            for symbol in symbols:
                for channel in channels:
                    stream_name = self._get_stream_name(symbol, channel)
                    if stream_name:
                        streams.append(stream_name)

            if streams:
                subscribe_message = {
                    "method": "SUBSCRIBE",
                    "params": streams,
                    "id": int(time.time() * 1000)
                }
                await self.ws.send_json(subscribe_message)
                return True
        except Exception as e:
            self.logger.error(f"Subscribe error: {e}")
            return False

    async def _do_unsubscribe(self, symbols: List[str], channels: List[str]) -> bool:
        """实现币安的取消订阅逻辑"""
        try:
            streams = []
            for symbol in symbols:
                for channel in channels:
                    stream_name = self._get_stream_name(symbol, channel)
                    if stream_name:
                        streams.append(stream_name)

            if streams:
                unsubscribe_message = {
                    "method": "UNSUBSCRIBE",
                    "params": streams,
                    "id": int(time.time() * 1000)
                }
                await self.ws.send_json(unsubscribe_message)
                return True
        except Exception as e:
            self.logger.error(f"Unsubscribe error: {e}")
            return False

    def _get_stream_name(self, symbol: str, channel: str) -> Optional[str]:
        """获取币安的流名称"""
        channel_mapping = {
            'trade': '@trade',
            'order_book': '@depth20@100ms',
            'kline': '@kline_1m',
            'ticker': '@ticker'
        }
        
        if channel in channel_mapping:
            return f"{symbol.lower()}{channel_mapping[channel]}"
        return None

    async def _convert_message(self, message: Dict[str, Any]) -> Optional[Any]:
        """转换币安消息格式为标准格式
        
        Args:
            message: 币安原始消息
            
        Returns:
            Optional[Any]: 转换后的标准格式数据
        """
        try:
            event_type = message.get('e')
            if not event_type:
                return None

            if event_type == 'trade':
                return self._convert_trade(message)
            elif event_type == 'depth':
                return self._convert_order_book(message)
            elif event_type == 'kline':
                return self._convert_kline(message)
            
            return None
        except Exception as e:
            self.logger.error(f"Error converting message: {e}")
            return None

    def _convert_trade(self, message: Dict[str, Any]) -> Optional[Any]:
        """转换交易数据"""
        try:
            return self.factory.create_trade(
                market_type=self.market_type,
                exchange='Binance',
                symbol=message['s'],
                timestamp=datetime.fromtimestamp(message['T'] / 1000),
                price=float(message['p']),
                volume=float(message['q']),
                amount=float(message['p']) * float(message['q']),
                trade_id=str(message['t']),
                side='buy' if message['m'] else 'sell',
                is_maker=message['m'],
                source='Binance',
                raw_data=message
            )
        except Exception as e:
            self.logger.error(f"Error converting trade: {e}")
            return None

    def _convert_order_book(self, message: Dict[str, Any]) -> Optional[Any]:
        """转换订单簿数据"""
        try:
            bids = [OrderBookLevel(float(price), float(volume)) 
                   for price, volume in message['b']]
            asks = [OrderBookLevel(float(price), float(volume))
                   for price, volume in message['a']]
            
            return self.factory.create_order_book(
                market_type=self.market_type,
                exchange='Binance',
                symbol=message['s'],
                timestamp=datetime.fromtimestamp(message['T'] / 1000),
                bids=bids,
                asks=asks,
                snapshot=True,
                source='Binance',
                update_id=message['u'],
                raw_data=message
            )
        except Exception as e:
            self.logger.error(f"Error converting order book: {e}")
            return None

    def _convert_kline(self, message: Dict[str, Any]) -> Optional[Any]:
        """转换K线数据"""
        try:
            k = message['k']
            return self.factory.create_kline(
                market_type=self.market_type,
                exchange='Binance',
                symbol=message['s'],
                timestamp=datetime.fromtimestamp(k['t'] / 1000),
                interval='1m',
                open=float(k['o']),
                high=float(k['h']),
                low=float(k['l']),
                close=float(k['c']),
                volume=float(k['v']),
                amount=float(k['q']),
                source='Binance',
                trade_count=k['n'],
                raw_data=message
            )
        except Exception as e:
            self.logger.error(f"Error converting kline: {e}")
            return None

    async def _heartbeat(self) -> None:
        """维持WebSocket心跳"""
        while True:
            if self.ws and not self.ws.closed:
                try:
                    await self.ws.ping()
                    await asyncio.sleep(30)
                except Exception as e:
                    self.logger.error(f"Heartbeat error: {e}")
                    await self.handle_error(e)
                    break
            else:
                break

    async def _message_handler(self) -> None:
        """处理WebSocket消息"""
        while True:
            if self.ws and not self.ws.closed:
                try:
                    msg = await self.ws.receive()
                    if msg.type == aiohttp.WSMsgType.TEXT:
                        message = json.loads(msg.data)
                        await self._process_message(message)
                    elif msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR):
                        break
                except Exception as e:
                    self.logger.error(f"Message handler error: {e}")
                    await self.handle_error(e)
                    break
            else:
                break

    def _generate_signature(self, query_string: str) -> str:
        """生成API签名"""
        return hmac.new(
            self.api_secret.encode('utf-8'),
            query_string.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()

    async def _make_request(self, method: str, endpoint: str,
                          signed: bool = False, **kwargs) -> Any:
        """发送HTTP请求到币安API"""
        if not self.session:
            raise ConnectionError("No active session")

        url = f"{self.base_url}{endpoint}"
        headers = {"X-MBX-APIKEY": self.api_key} if self.api_key else {}

        if signed and self.api_secret:
            kwargs['timestamp'] = int(time.time() * 1000)
            query_string = urlencode(kwargs)
            kwargs['signature'] = self._generate_signature(query_string)

        try:
            async with self.session.request(method, url,
                                          params=kwargs, headers=headers) as response:
                response.raise_for_status()
                return await response.json()
        except Exception as e:
            self.logger.error(f"API request error: {e}")
            raise