# adapters/crypto/kraken_adapter.py

import asyncio
import hmac
import base64
import json
import time
from datetime import datetime
from typing import Dict, Any, List, Optional
import aiohttp
import websockets

from core.market_data import MarketType, DataType
from adapters.base.base_adapter import BaseAdapter

class KrakenAdapter(BaseAdapter):
   """Kraken交易所适配器"""

   def __init__(self, config: Dict[str, Any], callbacks: Optional[Dict] = None):
       """初始化Kraken适配器"""
       super().__init__(config, MarketType.CRYPTO, callbacks)
       
       self.api_key = config.get('api_key')
       self.api_secret = config.get('api_secret')
       
       self.rest_url = config.get('rest_url', 'https://api.kraken.com/0')
       self.ws_url = config.get('ws_url', 'wss://ws.kraken.com')
       
       self.ws: Optional[websockets.WebSocketClientProtocol] = None
       self.session: Optional[aiohttp.ClientSession] = None
       
       self.order_book_cache: Dict[str, Dict] = {}
       
       self.pair_mapping = {}  # Kraken的交易对映射
       self._init_pair_mapping()

   def _init_pair_mapping(self) -> None:
       """初始化交易对映射"""
       # Kraken使用特殊的资产对命名
       self.pair_mapping = {
           'BTC/USD': 'XBT/USD',
           'ETH/USD': 'ETH/USD',
           'XRP/USD': 'XRP/USD'
       }

   def _get_kraken_pair(self, pair: str) -> str:
       """获取Kraken格式的交易对"""
       return self.pair_mapping.get(pair, pair)

   async def connect(self) -> bool:
       """建立与Kraken的连接"""
       try:
           self.session = aiohttp.ClientSession()
           self.ws = await websockets.connect(self.ws_url)
           
           asyncio.create_task(self._message_handler())
           
           self.logger.info("Connected to Kraken WebSocket")
           return True
           
       except Exception as e:
           self.logger.error(f"Failed to connect to Kraken: {e}")
           return False

   async def disconnect(self) -> None:
       """断开与Kraken的连接"""
       try:
           if self.ws:
               await self.ws.close()
           if self.session:
               await self.session.close()
           self.ws = None
           self.session = None
           self.logger.info("Disconnected from Kraken")
       except Exception as e:
           self.logger.error(f"Error disconnecting from Kraken: {e}")

   async def _message_handler(self) -> None:
       """处理WebSocket消息"""
       while True:
           try:
               if not self.ws:
                   break
                   
               message = await self.ws.recv()
               if message:
                   data = json.loads(message)
                   await self._process_message(data)
                   
           except websockets.ConnectionClosed:
               self.logger.error("WebSocket connection closed")
               await self.handle_error(Exception("Connection closed"))
               break
           except Exception as e:
               self.logger.error(f"Message handler error: {e}")
               await self.handle_error(e)
               continue

   async def _do_subscribe(self, symbols: List[str], channels: List[str]) -> bool:
       """实现Kraken的订阅逻辑"""
       try:
           subscription = {
               "event": "subscribe",
               "pair": [self._get_kraken_pair(s) for s in symbols],
               "subscription": {
                   "name": self._get_channel_name(channels[0])
               }
           }
           
           await self.ws.send(json.dumps(subscription))
           return True
           
       except Exception as e:
           self.logger.error(f"Subscribe error: {e}")
           return False

   def _get_channel_name(self, channel: str) -> str:
       """获取Kraken的频道名称"""
       channel_map = {
           'trades': 'trade',
           'order_book': 'book',
           'kline': 'ohlc'
       }
       return channel_map.get(channel, channel)

   async def _do_unsubscribe(self, symbols: List[str], channels: List[str]) -> bool:
       """实现Kraken的取消订阅逻辑"""
       try:
           unsubscription = {
               "event": "unsubscribe",
               "pair": [self._get_kraken_pair(s) for s in symbols],
               "subscription": {
                   "name": self._get_channel_name(channels[0])
               }
           }
           
           await self.ws.send(json.dumps(unsubscription))
           return True
           
       except Exception as e:
           self.logger.error(f"Unsubscribe error: {e}")
           return False

   async def _convert_trade(self, data: List) -> Optional[Dict[str, Any]]:
       """转换Kraken交易数据格式"""
       try:
           trade_data = data[1][0]
           return {
               'exchange': 'Kraken',
               'symbol': data[3],
               'timestamp': datetime.fromtimestamp(float(trade_data[2])),
               'price': float(trade_data[0]),
               'amount': float(trade_data[1]),
               'side': 'sell' if trade_data[3] == 's' else 'buy',
               'trade_id': str(int(time.time() * 1000))  # Kraken不提供trade_id
           }
       except Exception as e:
           self.logger.error(f"Error converting trade data: {e}")
           return None

   async def _convert_order_book(self, data: List) -> Optional[Dict[str, Any]]:
       """转换Kraken订单簿数据格式"""
       try:
           book_data = data[1]
           return {
               'exchange': 'Kraken',
               'symbol': data[3],
               'timestamp': datetime.now(),  # Kraken不提供时间戳
               'bids': [[float(price), float(amount)] for price, amount, _ in book_data['bs']],
               'asks': [[float(price), float(amount)] for price, amount, _ in book_data['as']]
           }
       except Exception as e:
           self.logger.error(f"Error converting order book data: {e}")
           return None

   async def _convert_kline(self, data: List) -> Optional[Dict[str, Any]]:
       """转换Kraken K线数据格式"""
       try:
           ohlc_data = data[1]
           return {
               'exchange': 'Kraken',
               'symbol': data[3],
               'timestamp': datetime.fromtimestamp(float(ohlc_data[0])),
               'interval': '1m',
               'open': float(ohlc_data[1]),
               'high': float(ohlc_data[2]),
               'low': float(ohlc_data[3]),
               'close': float(ohlc_data[4]),
               'volume': float(ohlc_data[6])
           }
       except Exception as e:
           self.logger.error(f"Error converting kline data: {e}")
           return None

   async def _process_message(self, message: List) -> None:
       """处理Kraken WebSocket消息"""
       try:
           if isinstance(message, dict):
               if message.get('event') == 'heartbeat':
                   return
               elif message.get('event') == 'systemStatus':
                   self.logger.info(f"Kraken system status: {message}")
                   return
               elif message.get('event') == 'subscriptionStatus':
                   self.logger.info(f"Subscription status: {message}")
                   return
                   
           channel_name = message[2]
           
           if channel_name == 'trade':
               trade_data = await self._convert_trade(message)
               if trade_data:
                   await self.handle_trade(trade_data)
                   
           elif channel_name == 'book':
               order_book_data = await self._convert_order_book(message)
               if order_book_data:
                   await self.handle_order_book(order_book_data)
                   
           elif channel_name == 'ohlc-1':
               kline_data = await self._convert_kline(message)
               if kline_data:
                   await self.handle_kline(kline_data)
                   
       except Exception as e:
           self.logger.error(f"Error processing message: {e}")
           await self.handle_error(e)

   async def _sign_request(self, endpoint: str, data: Dict[str, Any]) -> Dict[str, str]:
       """生成API签名"""
       if not self.api_key or not self.api_secret:
           return {}
           
       nonce = str(int(time.time() * 1000))
       
       # 构建签名
       data['nonce'] = nonce
       postdata = urllib.parse.urlencode(data)
       encoded = (str(data['nonce']) + postdata).encode()
       message = endpoint.encode() + hashlib.sha256(encoded).digest()
       
       signature = hmac.new(
           base64.b64decode(self.api_secret),
           message,
           hashlib.sha512
       )
       
       return {
           'API-Key': self.api_key,
           'API-Sign': base64.b64encode(signature.digest()).decode()
       }