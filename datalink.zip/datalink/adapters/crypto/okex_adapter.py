# adapters/crypto/okex_adapter.py

import asyncio
import hmac
import base64
import json
import time
from datetime import datetime
from typing import Dict, Any, List, Optional
import aiohttp

from core.market_data import MarketType, DataType
from adapters.base.base_adapter import BaseAdapter

class OKExAdapter(BaseAdapter):
    """OKEx交易所适配器
    
    支持现货、永续合约和期权市场的实时数据订阅，
    包括交易数据、订单簿和K线数据。
    """

    def __init__(self, config: Dict[str, Any], callbacks: Optional[Dict] = None):
        """初始化OKEx适配器
        
        Args:
            config: 适配器配置
            callbacks: 数据回调函数字典
        """
        super().__init__(config, MarketType.CRYPTO, callbacks)
        
        # API配置
        self.api_key = config.get('api_key')
        self.api_secret = config.get('api_secret')
        self.api_passphrase = config.get('api_passphrase')
        
        # API URL
        self.rest_url = config.get('rest_url', 'https://www.okex.com')
        self.ws_url = config.get('ws_url', 'wss://ws.okex.com:8443/ws/v5/public')
        
        # WebSocket连接
        self.ws: Optional[aiohttp.ClientWebSocketResponse] = None
        self.session: Optional[aiohttp.ClientSession] = None
        
        # 订单簿缓存
        self.order_book_cache: Dict[str, Dict] = {}
        
        # 市场类型映射
        self.market_type_map = {
            'SPOT': 'spot',
            'SWAP': 'swap',
            'FUTURES': 'futures',
            'OPTION': 'option'
        }

    def _generate_signature(self, timestamp: str, method: str, 
                          request_path: str, body: str = '') -> str:
        """生成API签名
        
        Args:
            timestamp: 时间戳
            method: HTTP方法
            request_path: 请求路径
            body: 请求体
            
        Returns:
            str: 签名字符串
        """
        message = timestamp + method + request_path + body
        mac = hmac.new(
            bytes(self.api_secret, encoding='utf8'),
            bytes(message, encoding='utf-8'),
            digestmod='sha256'
        )
        return base64.b64encode(mac.digest()).decode()

    async def connect(self) -> bool:
        """建立与OKEx的连接"""
        try:
            self.session = aiohttp.ClientSession()
            self.ws = await self.session.ws_connect(self.ws_url)
            
            # 启动心跳任务
            asyncio.create_task(self._heartbeat())
            
            # 启动消息处理任务
            asyncio.create_task(self._message_handler())
            
            self.logger.info("Connected to OKEx WebSocket")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to connect to OKEx: {e}")
            return False

    async def disconnect(self) -> None:
        """断开与OKEx的连接"""
        try:
            if self.ws:
                await self.ws.close()
            if self.session:
                await self.session.close()
            self.ws = None
            self.session = None
            self.logger.info("Disconnected from OKEx")
        except Exception as e:
            self.logger.error(f"Error disconnecting from OKEx: {e}")

    async def _heartbeat(self) -> None:
        """维持WebSocket心跳"""
        while True:
            if self.ws and not self.ws.closed:
                try:
                    await self.ws.ping()
                    await asyncio.sleep(20)
                except Exception as e:
                    self.logger.error(f"Heartbeat error: {e}")
                    await self.handle_error(e)
                    break
            else:
                break

    async def _message_handler(self) -> None:
        """处理WebSocket消息"""
        while True:
            if self.ws and not self.ws.closed:
                try:
                    msg = await self.ws.receive()
                    if msg.type == aiohttp.WSMsgType.TEXT:
                        data = json.loads(msg.data)
                        await self._process_message(data)
                    elif msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR):
                        break
                except Exception as e:
                    self.logger.error(f"Message handler error: {e}")
                    await self.handle_error(e)
                    break
            else:
                break

    async def _do_subscribe(self, symbols: List[str], channels: List[str]) -> bool:
        """实现OKEx的订阅逻辑"""
        try:
            args = []
            for symbol in symbols:
                for channel in channels:
                    # 构建订阅参数
                    if channel == 'trades':
                        args.append({
                            'channel': 'trades',
                            'instId': symbol
                        })
                    elif channel == 'order_book':
                        args.append({
                            'channel': 'books',
                            'instId': symbol
                        })
                    elif channel == 'kline':
                        args.append({
                            'channel': 'candle1m',
                            'instId': symbol
                        })
            
            # 发送订阅请求
            subscribe_message = {
                'op': 'subscribe',
                'args': args
            }
            await self.ws.send_json(subscribe_message)
            return True
            
        except Exception as e:
            self.logger.error(f"Subscribe error: {e}")
            return False

    async def _do_unsubscribe(self, symbols: List[str], channels: List[str]) -> bool:
        """实现OKEx的取消订阅逻辑"""
        try:
            args = []
            for symbol in symbols:
                for channel in channels:
                    if channel in ['trades', 'order_book', 'kline']:
                        args.append({
                            'channel': channel,
                            'instId': symbol
                        })
            
            unsubscribe_message = {
                'op': 'unsubscribe',
                'args': args
            }
            await self.ws.send_json(unsubscribe_message)
            return True
            
        except Exception as e:
            self.logger.error(f"Unsubscribe error: {e}")
            return False

    async def _convert_trade(self, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """转换OKEx交易数据格式"""
        try:
            return {
                'exchange': 'OKEx',
                'symbol': data['instId'],
                'timestamp': datetime.fromtimestamp(int(data['ts']) / 1000),
                'price': float(data['px']),
                'amount': float(data['sz']),
                'side': data['side'].lower(),
                'trade_id': data['tradeId']
            }
        except Exception as e:
            self.logger.error(f"Error converting trade data: {e}")
            return None

    async def _convert_order_book(self, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """转换OKEx订单簿数据格式"""
        try:
            return {
                'exchange': 'OKEx',
                'symbol': data['instId'],
                'timestamp': datetime.fromtimestamp(int(data['ts']) / 1000),
                'bids': [[float(price), float(size)] for price, size in data['bids']],
                'asks': [[float(price), float(size)] for price, size in data['asks']]
            }
        except Exception as e:
            self.logger.error(f"Error converting order book data: {e}")
            return None

    async def _convert_kline(self, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """转换OKEx K线数据格式"""
        try:
            return {
                'exchange': 'OKEx',
                'symbol': data['instId'],
                'timestamp': datetime.fromtimestamp(int(data['ts']) / 1000),
                'interval': '1m',
                'open': float(data['o']),
                'high': float(data['h']),
                'low': float(data['l']),
                'close': float(data['c']),
                'volume': float(data['vol'])
            }
        except Exception as e:
            self.logger.error(f"Error converting kline data: {e}")
            return None

    async def _process_message(self, message: Dict[str, Any]) -> None:
        """处理OKEx WebSocket消息"""
        try:
            if 'event' in message:
                if message['event'] == 'error':
                    self.logger.error(f"WebSocket error: {message}")
                    return
                elif message['event'] == 'subscribe':
                    self.logger.info(f"Successfully subscribed to {message['arg']}")
                    return
            
            if 'data' not in message:
                return
                
            data = message['data'][0]  # OKEx sends data in an array
            channel = message['arg']['channel']
            
            if channel == 'trades':
                trade_data = await self._convert_trade(data)
                if trade_data:
                    await self.handle_trade(trade_data)
                    
            elif channel == 'books':
                order_book_data = await self._convert_order_book(data)
                if order_book_data:
                    await self.handle_order_book(order_book_data)
                    
            elif channel == 'candle1m':
                kline_data = await self._convert_kline(data)
                if kline_data:
                    await self.handle_kline(kline_data)
                    
        except Exception as e:
            self.logger.error(f"Error processing message: {e}")
            await self.handle_error(e)