# adapters/base/base_adapter.py

from typing import Dict, List, Any, Optional, Callable, Coroutine
from datetime import datetime
import asyncio
import logging
from abc import abstractmethod
import json

from core.data_source import DataSource
from core.market_data import (
    MarketType, DataType, MarketDataFactory,
    TradeData, OrderBookData, KlineData
)

class BaseAdapter(DataSource):
    """基础适配器类
    
    为不同市场的数据适配器提供通用功能实现，包括：
    - 数据转换
    - 消息处理
    - 订阅管理
    - 连接维护
    - 错误处理
    """

    def __init__(self, 
                 config: Dict[str, Any],
                 market_type: MarketType,
                 callbacks: Optional[Dict[DataType, Callable]] = None):
        """初始化适配器
        
        Args:
            config: 适配器配置
            market_type: 市场类型
            callbacks: 数据回调函数字典
        """
        super().__init__(config)
        self.market_type = market_type
        self.callbacks = callbacks or {}
        self.subscriptions: Dict[str, List[DataType]] = {}
        self.logger = logging.getLogger(f"adapter.{self.__class__.__name__}")
        self.data_buffer: asyncio.Queue = asyncio.Queue()
        self.factory = MarketDataFactory()
        self.processing_task: Optional[asyncio.Task] = None

    async def start(self) -> None:
        """启动适配器"""
        await super().start()
        self.processing_task = asyncio.create_task(self._process_buffer())
        self.logger.info(f"Started {self.__class__.__name__} adapter")

    async def stop(self) -> None:
        """停止适配器"""
        if self.processing_task:
            self.processing_task.cancel()
            try:
                await self.processing_task
            except asyncio.CancelledError:
                pass
        await super().stop()
        self.logger.info(f"Stopped {self.__class__.__name__} adapter")

    async def subscribe(self, symbols: List[str], channels: List[str]) -> bool:
        """订阅数据
        
        Args:
            symbols: 交易对列表
            channels: 数据类型列表
        
        Returns:
            bool: 订阅是否成功
        """
        try:
            for symbol in symbols:
                self.subscriptions[symbol] = [DataType(c) for c in channels]
            result = await self._do_subscribe(symbols, channels)
            if result:
                self.logger.info(f"Subscribed to {symbols} - {channels}")
            return result
        except Exception as e:
            self.logger.error(f"Subscribe error: {e}")
            return False

    async def unsubscribe(self, symbols: List[str], channels: List[str]) -> bool:
        """取消订阅
        
        Args:
            symbols: 交易对列表
            channels: 数据类型列表
        
        Returns:
            bool: 取消订阅是否成功
        """
        try:
            for symbol in symbols:
                if symbol in self.subscriptions:
                    for channel in channels:
                        if DataType(channel) in self.subscriptions[symbol]:
                            self.subscriptions[symbol].remove(DataType(channel))
                    if not self.subscriptions[symbol]:
                        del self.subscriptions[symbol]
            result = await self._do_unsubscribe(symbols, channels)
            if result:
                self.logger.info(f"Unsubscribed from {symbols} - {channels}")
            return result
        except Exception as e:
            self.logger.error(f"Unsubscribe error: {e}")
            return False

    @abstractmethod
    async def _do_subscribe(self, symbols: List[str], channels: List[str]) -> bool:
        """实际的订阅实现"""
        pass

    @abstractmethod
    async def _do_unsubscribe(self, symbols: List[str], channels: List[str]) -> bool:
        """实际的取消订阅实现"""
        pass

    async def _process_message(self, message: Dict[str, Any]) -> None:
        """处理接收到的消息
        
        将原始消息转换为标准格式并放入处理队列
        """
        try:
            await self.data_buffer.put(message)
        except Exception as e:
            self.logger.error(f"Error processing message: {e}")
            await self.handle_error(e)

    async def _process_buffer(self) -> None:
        """处理数据缓冲队列"""
        while True:
            try:
                message = await self.data_buffer.get()
                data = await self._convert_message(message)
                if data and self._validate_data(data):
                    await self._dispatch_data(data)
                self.data_buffer.task_done()
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Error processing buffer: {e}")
                await self.handle_error(e)

    @abstractmethod
    async def _convert_message(self, message: Dict[str, Any]) -> Optional[Any]:
        """将原始消息转换为标准数据格式
        
        Args:
            message: 原始消息
            
        Returns:
            Optional[Any]: 转换后的标准格式数据
        """
        pass

    def _validate_data(self, data: Any) -> bool:
        """验证数据有效性
        
        Args:
            data: 待验证的数据
            
        Returns:
            bool: 数据是否有效
        """
        if isinstance(data, (TradeData, OrderBookData, KlineData)):
            return data.validate()
        return False

    async def _dispatch_data(self, data: Any) -> None:
        """分发数据到回调函数
        
        Args:
            data: 待分发的数据
        """
        try:
            if data.data_type in self.callbacks:
                await self.callbacks[data.data_type](data)
        except Exception as e:
            self.logger.error(f"Error dispatching data: {e}")

    def _get_timestamp(self) -> datetime:
        """获取当前时间戳"""
        return datetime.utcnow()

    async def health_check(self) -> Dict[str, Any]:
        """健康检查
        
        Returns:
            Dict[str, Any]: 健康状态信息
        """
        status = await super().health_check()
        status.update({
            "subscriptions": self.subscriptions,
            "buffer_size": self.data_buffer.qsize(),
            "market_type": self.market_type.value
        })
        return status

    def __str__(self) -> str:
        """返回适配器的字符串表示"""
        return (
            f"{self.__class__.__name__}("
            f"market_type={self.market_type.value}, "
            f"connected={self.status.is_connected}, "
            f"subscriptions={len(self.subscriptions)})"
        )