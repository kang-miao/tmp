# analysis/market_validator.py

from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from dataclasses import dataclass
import logging
import asyncio

@dataclass
class MarketStats:
    """市场统计数据"""
    symbol: str
    timestamp: datetime
    trade_count: int
    volume: float
    amount: float
    price_mean: float
    price_std: float
    price_min: float
    price_max: float
    bid_ask_spread: float
    depth_imbalance: float
    update_frequency: float  # 每秒更新次数

@dataclass
class DataQualityMetrics:
    """数据质量指标"""
    missing_data_rate: float
    duplicate_rate: float
    price_continuity: float
    timestamp_continuity: float
    data_delay: float
    error_rate: float

class MarketValidator:
    """市场数据验证器
    
    用于验证市场数据质量和计算基本统计指标，功能包括：
    - 数据完整性检查
    - 数据一致性验证
    - 市场统计计算
    - 异常检测
    """

    def __init__(self, config: Dict[str, Any]):
        self.logger = logging.getLogger("analysis.validator")
        self.config = config

        # 数据缓存
        self.data_cache: Dict[str, List[Dict[str, Any]]] = {}
        self.stats_cache: Dict[str, MarketStats] = {}
        self.quality_cache: Dict[str, DataQualityMetrics] = {}

        # 缓存配置
        self.cache_size = config.get('cache_size', 1000)
        self.update_interval = config.get('update_interval', 1)  # 秒

        # 质量检查阈值
        self.thresholds = config.get('thresholds', {
            'price_deviation': 3.0,  # 标准差倍数
            'spread_threshold': 0.01,  # 1%
            'delay_threshold': 1.0,   # 秒
            'missing_data_threshold': 0.05,  # 5%
            'error_rate_threshold': 0.01  # 1%
        })

        # 运行标志
        self.is_running = False
        self._validate_task: Optional[asyncio.Task] = None

    async def start(self):
        """启动验证器"""
        self.is_running = True
        self._validate_task = asyncio.create_task(self._validation_loop())
        self.logger.info("Market validator started")

    async def stop(self):
        """停止验证器"""
        self.is_running = False
        if self._validate_task:
            self._validate_task.cancel()
            try:
                await self._validate_task
            except asyncio.CancelledError:
                pass
        self.logger.info("Market validator stopped")

    async def process_trade(self, trade_data: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
        """处理交易数据
        
        Args:
            trade_data: 交易数据

        Returns:
            Tuple[bool, Optional[str]]: (是否有效, 错误信息)
        """
        try:
            symbol = trade_data['symbol']
            
            # 更新数据缓存
            if symbol not in self.data_cache:
                self.data_cache[symbol] = []
            
            self.data_cache[symbol].append(trade_data)
            if len(self.data_cache[symbol]) > self.cache_size:
                self.data_cache[symbol].pop(0)

            # 验证数据
            is_valid, error = await self._validate_trade(trade_data)
            if not is_valid:
                return False, error

            return True, None

        except Exception as e:
            self.logger.error(f"Error processing trade: {e}")
            return False, str(e)

    async def process_order_book(self, book_data: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
        """处理订单簿数据"""
        try:
            symbol = book_data['symbol']
            
            # 基本验证
            if not book_data.get('bids') or not book_data.get('asks'):
                return False, "Missing bids or asks"

            # 价格排序验证
            if not self._validate_price_levels(book_data['bids'], book_data['asks']):
                return False, "Invalid price levels"

            # 计算订单簿指标
            spread = self._calculate_spread(book_data)
            imbalance = self._calculate_imbalance(book_data)

            # 更新统计信息
            if symbol not in self.stats_cache:
                self.stats_cache[symbol] = MarketStats(
                    symbol=symbol,
                    timestamp=datetime.now(),
                    trade_count=0,
                    volume=0,
                    amount=0,
                    price_mean=0,
                    price_std=0,
                    price_min=0,
                    price_max=0,
                    bid_ask_spread=spread,
                    depth_imbalance=imbalance,
                    update_frequency=0
                )
            else:
                self.stats_cache[symbol].bid_ask_spread = spread
                self.stats_cache[symbol].depth_imbalance = imbalance
                self.stats_cache[symbol].timestamp = datetime.now()

            return True, None

        except Exception as e:
            self.logger.error(f"Error processing order book: {e}")
            return False, str(e)

    async def _validate_trade(self, trade: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
        """验证交易数据"""
        symbol = trade['symbol']
        price = trade['price']
        volume = trade['volume']

        # 获取历史数据
        history = self.data_cache.get(symbol, [])
        if not history:
            return True, None

        # 计算价格统计
        prices = [t['price'] for t in history[-100:]]  # 使用最近100个价格
        mean_price = np.mean(prices)
        std_price = np.std(prices)

        # 价格异常检测
        if std_price > 0:
            z_score = abs(price - mean_price) / std_price
            if z_score > self.thresholds['price_deviation']:
                return False, f"Price deviation too large: {z_score:.2f} std"

        # 成交量异常检测
        volumes = [t['volume'] for t in history[-100:]]
        mean_volume = np.mean(volumes)
        std_volume = np.std(volumes)
        if std_volume > 0:
            z_score = abs(volume - mean_volume) / std_volume
            if z_score > self.thresholds['price_deviation']:
                return False, f"Volume deviation too large: {z_score:.2f} std"

        return True, None

    def _validate_price_levels(self, bids: List[List[float]], 
                             asks: List[List[float]]) -> bool:
        """验证价格档位"""
        if not bids or not asks:
            return False

        # 检查买卖价格正确性
        highest_bid = bids[0][0]
        lowest_ask = asks[0][0]
        if highest_bid >= lowest_ask:
            return False

        # 检查价格排序
        for i in range(1, len(bids)):
            if bids[i][0] >= bids[i-1][0]:
                return False

        for i in range(1, len(asks)):
            if asks[i][0] <= asks[i-1][0]:
                return False

        return True

    def _calculate_spread(self, book_data: Dict[str, Any]) -> float:
        """计算买卖价差"""
        try:
            highest_bid = book_data['bids'][0][0]
            lowest_ask = book_data['asks'][0][0]
            return (lowest_ask - highest_bid) / lowest_ask
        except Exception:
            return float('inf')

    def _calculate_imbalance(self, book_data: Dict[str, Any]) -> float:
        """计算深度不平衡"""
        try:
            bid_volume = sum(level[1] for level in book_data['bids'][:5])
            ask_volume = sum(level[1] for level in book_data['asks'][:5])
            total_volume = bid_volume + ask_volume
            return (bid_volume - ask_volume) / total_volume if total_volume > 0 else 0
        except Exception:
            return 0

    async def _validation_loop(self):
        """验证循环"""
        while self.is_running:
            try:
                await self._update_quality_metrics()
                await asyncio.sleep(self.update_interval)
            except Exception as e:
                self.logger.error(f"Error in validation loop: {e}")
                await asyncio.sleep(1)

    async def _update_quality_metrics(self):
        """更新数据质量指标"""
        for symbol, data in self.data_cache.items():
            if not data:
                continue

            try:
                # 计算数据质量指标
                df = pd.DataFrame(data)
                
                # 计算缺失率
                missing_rate = df.isnull().mean().mean()

                # 计算重复率
                duplicate_rate = 1 - len(df.drop_duplicates()) / len(df)

                # 计算价格连续性
                price_diff = df['price'].diff().abs()
                price_continuity = 1 - (price_diff > df['price'].std() * 3).mean()

                # 计算时间戳连续性
                timestamp_diff = pd.Series(
                    [t['timestamp'] for t in data]
                ).diff().dt.total_seconds()
                timestamp_continuity = 1 - (
                    timestamp_diff > self.update_interval * 2
                ).mean()

                # 计算数据延迟
                current_time = datetime.now()
                data_delay = (
                    current_time - pd.to_datetime(df['timestamp'].max())
                ).total_seconds()

                # 更新质量指标缓存
                self.quality_cache[symbol] = DataQualityMetrics(
                    missing_data_rate=missing_rate,
                    duplicate_rate=duplicate_rate,
                    price_continuity=price_continuity,
                    timestamp_continuity=timestamp_continuity,
                    data_delay=data_delay,
                    error_rate=0  # 从错误统计中获取
                )

            except Exception as e:
                self.logger.error(f"Error updating quality metrics for {symbol}: {e}")

    async def get_market_stats(self, symbol: str) -> Optional[Dict[str, Any]]:
        """获取市场统计数据"""
        try:
            stats = self.stats_cache.get(symbol)
            quality = self.quality_cache.get(symbol)
            
            if not stats or not quality:
                return None

            return {
                'market_stats': {
                    'symbol': stats.symbol,
                    'timestamp': stats.timestamp.isoformat(),
                    'trade_count': stats.trade_count,
                    'volume': stats.volume,
                    'amount': stats.amount,
                    'price_mean': stats.price_mean,
                    'price_std': stats.price_std,
                    'price_min': stats.price_min,
                    'price_max': stats.price_max,
                    'bid_ask_spread': stats.bid_ask_spread,
                    'depth_imbalance': stats.depth_imbalance,
                    'update_frequency': stats.update_frequency
                },
                'quality_metrics': {
                    'missing_data_rate': quality.missing_data_rate,
                    'duplicate_rate': quality.duplicate_rate,
                    'price_continuity': quality.price_continuity,
                    'timestamp_continuity': quality.timestamp_continuity,
                    'data_delay': quality.data_delay,
                    'error_rate': quality.error_rate
                }
            }

        except Exception as e:
            self.logger.error(f"Error getting market stats: {e}")
            return None