# interfaces/data_service.py
class DataServiceInterface:
    """数据服务接口定义"""
    async def get_real_time_data(self, market_type: str, symbol: str, data_type: str):
        """获取实时数据"""
        pass

    async def get_historical_data(self, market_type: str, symbol: str, 
                                start_time: datetime, end_time: datetime):
        """获取历史数据"""
        pass

    async def subscribe_market_data(self, callback: Callable, 
                                  market_type: str, symbol: str):
        """订阅市场数据"""
        pass