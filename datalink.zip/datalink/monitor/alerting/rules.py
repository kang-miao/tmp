from typing import Dict, Any, List, Optional, Callable
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum

class AlertSeverity(Enum):
    """告警严重程度"""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"

class AlertStatus(Enum):
    """告警状态"""
    PENDING = "pending"
    FIRING = "firing"
    RESOLVED = "resolved"

@dataclass
class AlertRule:
    """告警规则"""
    name: str
    description: str
    severity: AlertSeverity
    metric_name: str
    condition: Callable[[float], bool]
    labels: Dict[str, str]
    for_duration: timedelta
    cooldown: timedelta
    annotations: Dict[str, str] = None

    def evaluate(self, value: float) -> bool:
        """评估告警条件"""
        return self.condition(value)

class AlertRuleManager:
    """告警规则管理器"""
    def __init__(self):
        self.rules: Dict[str, AlertRule] = {}

    def add_rule(self, rule: AlertRule):
        """添加规则"""
        self.rules[rule.name] = rule

    def remove_rule(self, rule_name: str):
        """删除规则"""
        if rule_name in self.rules:
            del self.rules[rule_name]

    def get_rule(self, rule_name: str) -> Optional[AlertRule]:
        """获取规则"""
        return self.rules.get(rule_name)

    def get_rules_by_metric(self, metric_name: str) -> List[AlertRule]:
        """获取指定指标的所有规则"""
        return [
            rule for rule in self.rules.values()
            if rule.metric_name == metric_name
        ]

    @classmethod
    def create_default_rules(cls) -> 'AlertRuleManager':
        """创建默认规则"""
        manager = cls()
        
        # CPU 使用率规则
        manager.add_rule(AlertRule(
            name="high_cpu_usage",
            description="CPU usage is too high",
            severity=AlertSeverity.WARNING,
            metric_name="system_cpu_usage",
            condition=lambda x: x > 80,
            labels={"type": "system", "resource": "cpu"},
            for_duration=timedelta(minutes=5),
            cooldown=timedelta(minutes=30),
            annotations={
                "summary": "High CPU usage detected",
                "description": "CPU usage has been above 80% for 5 minutes"
            }
        ))
        
        # 内存使用率规则
        manager.add_rule(AlertRule(
            name="high_memory_usage",
            description="Memory usage is too high",
            severity=AlertSeverity.WARNING,
            metric_name="system_memory_usage",
            condition=lambda x: x > 85,
            labels={"type": "system", "resource": "memory"},
            for_duration=timedelta(minutes=5),
            cooldown=timedelta(minutes=30),
            annotations={
                "summary": "High memory usage detected",
                "description": "Memory usage has been above 85% for 5 minutes"
            }
        ))
        
        # 磁盘使用率规则
        manager.add_rule(AlertRule(
            name="high_disk_usage",
            description="Disk usage is too high",
            severity=AlertSeverity.ERROR,
            metric_name="system_disk_usage",
            condition=lambda x: x > 90,
            labels={"type": "system", "resource": "disk"},
            for_duration=timedelta(minutes=5),
            cooldown=timedelta(hours=1),
            annotations={
                "summary": "High disk usage detected",
                "description": "Disk usage has been above 90% for 5 minutes"
            }
        ))
        
        return manager
