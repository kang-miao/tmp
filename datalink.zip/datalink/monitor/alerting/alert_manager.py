from typing import Dict, Any, List, Optional
from datetime import datetime
import asyncio
from dataclasses import dataclass
from logging import Logger
from monitor.alerting.rules import (
    AlertRule, AlertStatus, AlertSeverity,
    AlertRuleManager
)
from monitor.metrics.collector import MetricsCollector

@dataclass
class Alert:
    """告警实例"""
    rule_name: str
    status: AlertStatus
    severity: AlertSeverity
    labels: Dict[str, str]
    annotations: Dict[str, str]
    value: float
    start_time: datetime
    last_update: datetime
    end_time: Optional[datetime] = None

class AlertManager:
    """告警管理器"""
    def __init__(self, 
                 logger: Logger,
                 metrics_collector: MetricsCollector,
                 rule_manager: AlertRuleManager):
        self.logger = logger
        self.metrics_collector = metrics_collector
        self.rule_manager = rule_manager
        self.active_alerts: Dict[str, Alert] = {}
        self.resolved_alerts: List[Alert] = []
        self._running = False
        self._check_task: Optional[asyncio.Task] = None

    async def start(self):
        """启动告警管理器"""
        self._running = True
        self._check_task = asyncio.create_task(self._check_loop())
        self.logger.info("Alert manager started")

    async def stop(self):
        """停止告警管理器"""
        self._running = False
        if self._check_task:
            self._check_task.cancel()
            try:
                await self._check_task
            except asyncio.CancelledError:
                pass
        self.logger.info("Alert manager stopped")

    async def _check_loop(self):
        """检查循环"""
        while self._running:
            try:
                await self._evaluate_all_rules()
                await asyncio.sleep(60)  # 每分钟检查一次
            except Exception as e:
                self.logger.error(
                    f"Error evaluating alert rules: {str(e)}",
                    exc_info=True
                )
                await asyncio.sleep(5)

    async def _evaluate_all_rules(self):
        """评估所有规则"""
        now = datetime.now()
        
        # 获取所有指标
        for rule in self.rule_manager.rules.values():
            metrics = self.metrics_collector.get_metrics(
                metric_name=rule.metric_name,
                labels=rule.labels
            )
            
            if not metrics:
                continue
                
            latest_metric = max(metrics, key=lambda m: m.timestamp)
            alert_key = f"{rule.name}_{hash(frozenset(rule.labels.items()))}"
            
            # 评估规则
            if rule.evaluate(latest_metric.value):
                # 触发或更新告警
                if alert_key not in self.active_alerts:
                    # 新告警
                    alert = Alert(
                        rule_name=rule.name,
                        status=AlertStatus.PENDING,
                        severity=rule.severity,
                        labels=rule.labels,
                        annotations=rule.annotations,
                        value=latest_metric.value,
                        start_time=now,
                        last_update=now
                    )
                    self.active_alerts[alert_key] = alert
                    self.logger.info(
                        f"New alert created: {rule.name}",
                        extra={'alert': alert_key}
                    )
                else:
                    # 更新现有告警
                    alert = self.active_alerts[alert_key]
                    alert.last_update = now
                    alert.value = latest_metric.value
                    
                    # 检查是否应该从PENDING转为FIRING
                    if (alert.status == AlertStatus.PENDING and
                            now - alert.start_time >= rule.for_duration):
                        alert.status = AlertStatus.FIRING
                        self.logger.warning(
                            f"Alert firing: {rule.name}",
                            extra={'alert': alert_key}
                        )
            else:
                # 解决告警
                if alert_key in self.active_alerts:
                    alert = self.active_alerts[alert_key]
                    alert.status = AlertStatus.RESOLVED
                    alert.end_time = now
                    self.resolved_alerts.append(alert)
                    del self.active_alerts[alert_key]
                    self.logger.info(
                        f"Alert resolved: {rule.name}",
                        extra={'alert': alert_key}
                    )

    def get_active_alerts(self, 
                         severity: Optional[AlertSeverity] = None
                         ) -> List[Alert]:
        """获取活动告警"""
        alerts = list(self.active_alerts.values())
        if severity:
            alerts = [a for a in alerts if a.severity == severity]
        return alerts

    def get_resolved_alerts(self,
                          since: Optional[datetime] = None
                          ) -> List[Alert]:
        """获取已解决的告警"""
        alerts = self.resolved_alerts
        if since:
            alerts = [a for a in alerts if a.end_time >= since]
        return alerts

    def get_alert_history(self, 
                         rule_name: Optional[str] = None
                         ) -> List[Alert]:
        """获取告警历史"""
        alerts = self.resolved_alerts + list(self.active_alerts.values())
        if rule_name:
            alerts = [a for a in alerts if a.rule_name == rule_name]
        return sorted(alerts, key=lambda x: x.start_time, reverse=True)
