from abc import ABC, abstractmethod
from typing import Dict, Any
from monitor.alerting.rules import Alert
from logging import Logger

class BaseNotifier(ABC):
    """通知器基类"""
    def __init__(self, logger: Logger, config: Dict[str, Any]):
        self.logger = logger
        self.config = config

    @abstractmethod
    async def notify(self, alert: Alert):
        """发送通知"""
        pass

    @abstractmethod
    async def close(self):
        """关闭通知器"""
        pass
