from typing import Dict, Any
import aiosmtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from monitor.alerting.notifiers.base_notifier import BaseNotifier
from monitor.alerting.rules import Alert, AlertStatus

class EmailNotifier(BaseNotifier):
    """邮件通知器"""
    def __init__(self, logger, config: Dict[str, Any]):
        super().__init__(logger, config)
        self.smtp_host = config['smtp_host']
        self.smtp_port = config['smtp_port']
        self.username = config['username']
        self.password = config['password']
        self.from_addr = config['from_addr']
        self.to_addrs = config['to_addrs']
        self.use_tls = config.get('use_tls', True)

    async def notify(self, alert: Alert):
        """发送告警邮件"""
        try:
            message = self._create_message(alert)
            
            async with aiosmtplib.SMTP(
                hostname=self.smtp_host,
                port=self.smtp_port,
                use_tls=self.use_tls
            ) as smtp:
                await smtp.login(self.username, self.password)
                await smtp.send_message(message)
                
            self.logger.info(
                f"Alert email sent: {alert.rule_name}",
                extra={'alert': alert.rule_name}
            )
        except Exception as e:
            self.logger.error(
                f"Failed to send alert email: {str(e)}",
                exc_info=True
            )

    def _create_message(self, alert: Alert) -> MIMEMultipart:
        """创建邮件消息"""
        message = MIMEMultipart()
        message['From'] = self.from_addr
        message['To'] = ', '.join(self.to_addrs)
        
        if alert.status == AlertStatus.FIRING:
            message['Subject'] = f"[{alert.severity.value}] {alert.rule_name}"
        else:
            message['Subject'] = f"[Resolved] {alert.rule_name}"

        body = self._create_message_body(alert)
        message.attach(MIMEText(body, 'html'))
        
        return message

    def _create_message_body(self, alert: Alert) -> str:
        """创建邮件内容"""
        return f"""
        <h2>{alert.annotations.get('summary', alert.rule_name)}</h2>
        <p><strong>Status:</strong> {alert.status.value}</p>
        <p><strong>Severity:</strong> {alert.severity.value}</p>
        <p><strong>Start Time:</strong> {alert.start_time.isoformat()}</p>
        <p><strong>Last Update:</strong> {alert.last_update.isoformat()}</p>
        <p><strong>Value:</strong> {alert.value}</p>
        <h3>Labels:</h3>
        <ul>
            {''.join(f'<li><strong>{k}:</strong> {v}</li>' 
                    for k, v in alert.labels.items())}
        </ul>
        <p><strong>Description:</strong></p>
        <p>{alert.annotations.get('description', '')}</p>
        """

    async def close(self):
        """关闭通知器"""
        pass
