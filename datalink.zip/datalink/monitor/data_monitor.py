# monitor/data_monitor.py

import logging
import asyncio
from typing import Dict, Any, Optional
from datetime import datetime, timedelta
import json
from collections import defaultdict

class DataMonitor:
   """数据监控器，跟踪系统状态和数据流"""

   def __init__(self):
       self.logger = logging.getLogger("monitor.data")
       self.stats = defaultdict(lambda: {
           "total_messages": 0,
           "total_bytes": 0,
           "messages_per_second": 0,
           "bytes_per_second": 0,
           "last_message": None,
           "error_count": 0
       })
       self.running = False
       self._last_update = datetime.now()

   def start_monitoring(self, interval: int = 5) -> None:
       """启动监控
       
       Args:
           interval: 统计更新间隔（秒）
       """
       self.running = True
       asyncio.create_task(self._update_stats(interval))
       self.logger.info("Data monitoring started")

   def stop_monitoring(self) -> None:
       """停止监控"""
       self.running = False
       self.logger.info("Data monitoring stopped")

   async def _update_stats(self, interval: int) -> None:
       """定期更新统计数据"""
       while self.running:
           try:
               now = datetime.now()
               time_diff = (now - self._last_update).total_seconds()
               
               for category, data in self.stats.items():
                   # 计算速率
                   data['messages_per_second'] = (
                       data['total_messages'] / time_diff if time_diff > 0 else 0
                   )
                   data['bytes_per_second'] = (
                       data['total_bytes'] / time_diff if time_diff > 0 else 0
                   )
                   
                   # 重置计数器
                   data['total_messages'] = 0
                   data['total_bytes'] = 0
               
               self._last_update = now
               await asyncio.sleep(interval)
               
           except Exception as e:
               self.logger.error(f"Error updating stats: {e}")
               await asyncio.sleep(1)

   def update_stats(self, category: str, data_size: int) -> None:
       """更新数据统计
       
       Args:
           category: 数据类别
           data_size: 数据大小（字节）
       """
       try:
           stats = self.stats[category]
           stats['total_messages'] += 1
           stats['total_bytes'] += data_size
           stats['last_message'] = datetime.now()
       except Exception as e:
           self.logger.error(f"Error updating stats for {category}: {e}")
           stats['error_count'] += 1

   def record_error(self, category: str, error: Exception) -> None:
       """记录错误
       
       Args:
           category: 数据类别
           error: 错误信息
       """
       stats = self.stats[category]
       stats['error_count'] += 1
       self.logger.error(f"Error in {category}: {error}")

   async def get_stats(self) -> Dict[str, Any]:
       """获取监控统计信息
       
       Returns:
           Dict[str, Any]: 统计信息
       """
       result = {}
       for category, data in self.stats.items():
           result[category] = {
               'messages_per_second': data['messages_per_second'],
               'bytes_per_second': data['bytes_per_second'],
               'error_count': data['error_count'],
               'last_message': data['last_message'].isoformat() 
                   if data['last_message'] else None
           }
       return result

   def get_errors(self, since: Optional[datetime] = None) -> Dict[str, int]:
       """获取错误统计
       
       Args:
           since: 起始时间
           
       Returns:
           Dict[str, int]: 各类别的错误计数
       """
       errors = {}
       for category, data in self.stats.items():
           if since is None or (data['last_message'] and data['last_message'] >= since):
               errors[category] = data['error_count']
       return errors

   def get_throughput(self, category: Optional[str] = None) -> Dict[str, float]:
       """获取吞吐量统计
       
       Args:
           category: 数据类别（可选）
           
       Returns:
           Dict[str, float]: 吞吐量统计
       """
       if category:
           data = self.stats[category]
           return {
               'messages_per_second': data['messages_per_second'],
               'bytes_per_second': data['bytes_per_second']
           }
       
       return {
           cat: {
               'messages_per_second': data['messages_per_second'],
               'bytes_per_second': data['bytes_per_second']
           }
           for cat, data in self.stats.items()
       }