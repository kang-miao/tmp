# monitor/system_monitor.py

import asyncio
import logging
import psutil
import os
from typing import Dict, Any, List, Optional, Set
from datetime import datetime, timedelta
from dataclasses import dataclass
import json

from utils.metrics import MetricsManager
from core.data_link import DataLink

@dataclass
class SystemResources:
    """系统资源使用情况"""
    cpu_percent: float
    memory_used: int
    memory_total: int
    disk_used: int
    disk_total: int
    network_sent: int
    network_recv: int
    process_count: int

@dataclass
class ComponentStatus:
    """组件状态信息"""
    name: str
    status: str  # 'healthy', 'degraded', 'failed'
    last_check: datetime
    error_message: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

class SystemMonitor:
    """系统监控器
    
    负责监控整个系统的健康状态，包括：
    - 系统资源使用情况
    - 各组件健康状态
    - 数据流监控
    - 告警管理
    """

    def __init__(self, datalink: DataLink, metrics_manager: MetricsManager,
                 config: Dict[str, Any]):
        """初始化系统监控器
        
        Args:
            datalink: DataLink实例
            metrics_manager: 指标管理器
            config: 监控配置
        """
        self.logger = logging.getLogger("monitor.system")
        self.datalink = datalink
        self.metrics = metrics_manager
        self.config = config
        
        # 监控配置
        self.check_interval = config.get('check_interval', 60)  # 秒
        self.alert_thresholds = config.get('alert_thresholds', {
            'cpu_percent': 80,
            'memory_percent': 80,
            'disk_percent': 80,
            'error_rate': 0.01
        })
        
        # 组件状态
        self.component_status: Dict[str, ComponentStatus] = {}
        
        # 告警状态
        self.active_alerts: Set[str] = set()
        
        # 运行标志
        self.is_running = False
        self._monitor_task: Optional[asyncio.Task] = None

    async def start(self) -> None:
        """启动监控"""
        self.is_running = True
        self._monitor_task = asyncio.create_task(self._monitor_loop())
        self.logger.info("System monitor started")

    async def stop(self) -> None:
        """停止监控"""
        self.is_running = False
        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass
        self.logger.info("System monitor stopped")

    async def _monitor_loop(self) -> None:
        """主监控循环"""
        while self.is_running:
            try:
                # 系统资源监控
                resources = await self._check_system_resources()
                await self._record_resource_metrics(resources)
                
                # 组件健康检查
                await self._check_components_health()
                
                # 数据流监控
                await self._check_data_flow_health()
                
                # 检查告警条件
                await self._check_alert_conditions()
                
                await asyncio.sleep(self.check_interval)
                
            except Exception as e:
                self.logger.error(f"Error in monitor loop: {e}")
                await asyncio.sleep(5)

    async def _check_system_resources(self) -> SystemResources:
        """检查系统资源使用情况"""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            network = psutil.net_io_counters()
            process_count = len(psutil.pids())
            
            return SystemResources(
                cpu_percent=cpu_percent,
                memory_used=memory.used,
                memory_total=memory.total,
                disk_used=disk.used,
                disk_total=disk.total,
                network_sent=network.bytes_sent,
                network_recv=network.bytes_recv,
                process_count=process_count
            )
            
        except Exception as e:
            self.logger.error(f"Error checking system resources: {e}")
            raise

    async def _record_resource_metrics(self, resources: SystemResources) -> None:
        """记录资源使用指标"""
        try:
            # CPU使用率
            await self.metrics.business.record_market_data(
                'system',
                'cpu_usage',
                resources.cpu_percent,
                {'unit': 'percent'}
            )
            
            # 内存使用率
            memory_percent = (resources.memory_used / resources.memory_total) * 100
            await self.metrics.business.record_market_data(
                'system',
                'memory_usage',
                memory_percent,
                {'unit': 'percent'}
            )
            
            # 磁盘使用率
            disk_percent = (resources.disk_used / resources.disk_total) * 100
            await self.metrics.business.record_market_data(
                'system',
                'disk_usage',
                disk_percent,
                {'unit': 'percent'}
            )
            
            # 网络使用情况
            await self.metrics.business.record_market_data(
                'system',
                'network_sent',
                resources.network_sent,
                {'unit': 'bytes'}
            )
            await self.metrics.business.record_market_data(
                'system',
                'network_recv',
                resources.network_recv,
                {'unit': 'bytes'}
            )
            
        except Exception as e:
            self.logger.error(f"Error recording resource metrics: {e}")

    async def _check_components_health(self) -> None:
        """检查各组件健康状态"""
        try:
            # 检查存储组件状态
            storage_status = await self.datalink.get_storage_status()
            for name, status in storage_status.items():
                self.component_status[name] = ComponentStatus(
                    name=name,
                    status='healthy' if status else 'failed',
                    last_check=datetime.now(),
                    error_message=None if status else 'Connection failed'
                )
            
            # 检查适配器状态
            adapter_status = await self.datalink.get_adapter_status()
            for name, status in adapter_status.items():
                self.component_status[name] = ComponentStatus(
                    name=name,
                    status='healthy' if status['is_connected'] else 'failed',
                    last_check=datetime.now(),
                    error_message=status.get('last_error'),
                    metadata={
                        'message_count': status.get('message_count', 0),
                        'error_count': status.get('error_count', 0)
                    }
                )
            
        except Exception as e:
            self.logger.error(f"Error checking components health: {e}")

    async def _check_data_flow_health(self) -> None:
        """检查数据流健康状态"""
        try:
            # 获取数据流统计
            stats = await self.datalink.monitor.get_stats()
            
            for category, data in stats.items():
                # 检查消息速率
                if data['messages_per_second'] < self.config.get('min_message_rate', 1):
                    await self._raise_alert(
                        f"Low message rate for {category}",
                        f"Current rate: {data['messages_per_second']}/s"
                    )
                
                # 检查错误率
                error_rate = data['error_count'] / (data['message_count'] or 1)
                if error_rate > self.alert_thresholds['error_rate']:
                    await self._raise_alert(
                        f"High error rate for {category}",
                        f"Error rate: {error_rate:.2%}"
                    )
                
                # 记录数据流指标
                await self.metrics.business.record_market_data(
                    'data_flow',
                    f'{category}_rate',
                    data['messages_per_second'],
                    {'unit': 'messages_per_second'}
                )
                
        except Exception as e:
            self.logger.error(f"Error checking data flow health: {e}")

    async def _check_alert_conditions(self) -> None:
        """检查告警条件"""
        try:
            resources = await self._check_system_resources()
            
            # CPU使用率告警
            if resources.cpu_percent > self.alert_thresholds['cpu_percent']:
                await self._raise_alert(
                    "High CPU Usage",
                    f"CPU usage: {resources.cpu_percent}%"
                )
            
            # 内存使用率告警
            memory_percent = (resources.memory_used / resources.memory_total) * 100
            if memory_percent > self.alert_thresholds['memory_percent']:
                await self._raise_alert(
                    "High Memory Usage",
                    f"Memory usage: {memory_percent:.1f}%"
                )
            
            # 磁盘使用率告警
            disk_percent = (resources.disk_used / resources.disk_total) * 100
            if disk_percent > self.alert_thresholds['disk_percent']:
                await self._raise_alert(
                    "High Disk Usage",
                    f"Disk usage: {disk_percent:.1f}%"
                )
            
            # 检查组件状态
            for component in self.component_status.values():
                if component.status == 'failed':
                    await self._raise_alert(
                        f"Component Failure: {component.name}",
                        component.error_message or "Unknown error"
                    )
            
        except Exception as e:
            self.logger.error(f"Error checking alert conditions: {e}")

    async def _raise_alert(self, title: str, message: str) -> None:
        """发送告警"""
        try:
            alert_key = f"{title}:{message}"
            if alert_key not in self.active_alerts:
                self.active_alerts.add(alert_key)
                
                # 记录告警
                self.logger.warning(f"Alert: {title} - {message}")
                
                # 发送告警通知（如果配置了通知方式）
                notification_config = self.config.get('notifications', {})
                if notification_config.get('email'):
                    await self._send_email_alert(title, message)
                if notification_config.get('webhook'):
                    await self._send_webhook_alert(title, message)
                
        except Exception as e:
            self.logger.error(f"Error raising alert: {e}")

    async def _send_email_alert(self, title: str, message: str) -> None:
        """发送邮件告警"""
        # 实现邮件发送逻辑
        pass

    async def _send_webhook_alert(self, title: str, message: str) -> None:
        """发送Webhook告警"""
        # 实现Webhook通知逻辑
        pass

    async def get_system_status(self) -> Dict[str, Any]:
        """获取系统状态报告"""
        try:
            resources = await self._check_system_resources()
            
            return {
                'timestamp': datetime.now().isoformat(),
                'system_resources': {
                    'cpu_percent': resources.cpu_percent,
                    'memory_percent': (resources.memory_used / resources.memory_total) * 100,
                    'disk_percent': (resources.disk_used / resources.disk_total) * 100,
                    'network': {
                        'sent': resources.network_sent,
                        'received': resources.network_recv
                    },
                    'process_count': resources.process_count
                },
                'components': {
                    name: {
                        'status': status.status,
                        'last_check': status.last_check.isoformat(),
                        'error': status.error_message,
                        'metadata': status.metadata
                    }
                    for name, status in self.component_status.items()
                },
                'active_alerts': list(self.active_alerts),
                'metrics': await self.metrics.get_system_metrics()
            }
            
        except Exception as e:
            self.logger.error(f"Error getting system status: {e}")
            return {
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }