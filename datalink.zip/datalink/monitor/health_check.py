# monitor/health_check.py

import asyncio
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
import aiohttp

class HealthCheck:
    """系统健康检查组件"""

    def __init__(self, config: Dict[str, Any]):
        self.logger = logging.getLogger("monitor.health")
        self.config = config
        self.check_interval = config.get('check_interval', 60)
        self.timeout = config.get('timeout', 5)
        self.retry_count = config.get('retry_count', 3)
        self.components = config.get('components', [])
        self.status = {}
        self._running = False

    async def start(self):
        """启动健康检查"""
        self._running = True
        asyncio.create_task(self._check_loop())
        self.logger.info("Health check started")

    async def stop(self):
        """停止健康检查"""
        self._running = False
        self.logger.info("Health check stopped")

    async def _check_loop(self):
        """健康检查循环"""
        while self._running:
            try:
                await self._check_all_components()
                await asyncio.sleep(self.check_interval)
            except Exception as e:
                self.logger.error(f"Error in health check loop: {e}")
                await asyncio.sleep(5)

    async def _check_all_components(self):
        """检查所有组件"""
        for component in self.components:
            check_method = getattr(self, f'_check_{component}', None)
            if check_method:
                try:
                    is_healthy = await check_method()
                    self.status[component] = {
                        'healthy': is_healthy,
                        'last_check': datetime.now(),
                        'error': None if is_healthy else 'Component check failed'
                    }
                except Exception as e:
                    self.status[component] = {
                        'healthy': False,
                        'last_check': datetime.now(),
                        'error': str(e)
                    }
            else:
                self.logger.warning(f"No check method for component: {component}")

    async def _check_keydb(self) -> bool:
        """检查KeyDB连接"""
        try:
            redis = self.config['keydb_client']
            return await redis.ping()
        except Exception as e:
            self.logger.error(f"KeyDB health check failed: {e}")
            return False

    async def _check_redpanda(self) -> bool:
        """检查Redpanda连接"""
        try:
            redpanda = self.config['redpanda_client']
            topics = await redpanda.list_topics(timeout=self.timeout)
            return bool(topics)
        except Exception as e:
            self.logger.error(f"Redpanda health check failed: {e}")
            return False

    async def _check_risingwave(self) -> bool:
        """检查RisingWave连接"""
        try:
            risingwave = self.config['risingwave_client']
            async with risingwave.acquire() as conn:
                await conn.execute('SELECT 1')
            return True
        except Exception as e:
            self.logger.error(f"RisingWave health check failed: {e}")
            return False

    async def _check_tdengine(self) -> bool:
        """检查TDengine连接"""
        try:
            tdengine = self.config['tdengine_client']
            await tdengine.execute('SELECT SERVER_VERSION()')
            return True
        except Exception as e:
            self.logger.error(f"TDengine health check failed: {e}")
            return False

    async def _check_minio(self) -> bool:
        """检查MinIO连接"""
        try:
            minio = self.config['minio_client']
            buckets = minio.list_buckets()
            return True
        except Exception as e:
            self.logger.error(f"MinIO health check failed: {e}")
            return False

    async def get_health_status(self) -> Dict[str, Any]:
        """获取健康状态报告"""
        return {
            'timestamp': datetime.now().isoformat(),
            'components': self.status,
            'overall_health': all(
                status.get('healthy', False) 
                for status in self.status.values()
            )
        }