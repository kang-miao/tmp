from typing import Dict, Any, List, Optional
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from logging import Logger

@dataclass
class DashboardPanel:
    """仪表板面板"""
    id: str
    title: str
    type: str  # 图表类型：line, bar, gauge等
    data_source: str
    query: str
    refresh_interval: int = 60  # 刷新间隔（秒）
    options: Dict[str, Any] = None
    
class DashboardBase(ABC):
    """仪表板基类"""
    def __init__(self, logger: Logger):
        self.logger = logger
        self.panels: Dict[str, DashboardPanel] = {}
        
    @abstractmethod
    async def refresh_panel(self, panel_id: str):
        """刷新面板数据"""
        pass
        
    @abstractmethod
    async def get_panel_data(self, panel_id: str,
                            start_time: datetime,
                            end_time: datetime) -> Dict[str, Any]:
        """获取面板数据"""
        pass
        
    def register_panel(self, panel: DashboardPanel):
        """注册面板"""
        self.panels[panel.id] = panel
        self.logger.info(f"Registered dashboard panel: {panel.id}")
