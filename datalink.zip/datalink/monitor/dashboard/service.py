from typing import Dict, Any, List, Optional
import asyncio
from datetime import datetime, timedelta
from logging import Logger
import aiohttp
from aioredis import Redis
from monitor.dashboard.base import DashboardBase, DashboardPanel
from monitor.metrics.collector import MetricsCollector

class DashboardService(DashboardBase):
    """监控面板服务"""
    def __init__(self, logger: Logger,
                 metrics_collector: MetricsCollector,
                 redis: Redis):
        super().__init__(logger)
        self.metrics_collector = metrics_collector
        self.redis = redis
        self._refresh_tasks: Dict[str, asyncio.Task] = {}
        
    async def start(self):
        """启动服务"""
        for panel_id in self.panels:
            self._refresh_tasks[panel_id] = asyncio.create_task(
                self._panel_refresh_loop(panel_id)
            )
        self.logger.info("Dashboard service started")
        
    async def stop(self):
        """停止服务"""
        for task in self._refresh_tasks.values():
            task.cancel()
        await asyncio.gather(*self._refresh_tasks.values(),
                           return_exceptions=True)
        self.logger.info("Dashboard service stopped")
        
    async def refresh_panel(self, panel_id: str):
        """刷新面板数据"""
        if panel_id not in self.panels:
            raise ValueError(f"Panel not found: {panel_id}")
            
        panel = self.panels[panel_id]
        try:
            data = await self._fetch_panel_data(panel)
            await self._cache_panel_data(panel_id, data)
            self.logger.debug(f"Refreshed panel: {panel_id}")
            return data
        except Exception as e:
            self.logger.error(
                f"Failed to refresh panel {panel_id}: {str(e)}",
                exc_info=True
            )
            raise
            
    async def get_panel_data(self, panel_id: str,
                            start_time: datetime,
                            end_time: datetime) -> Dict[str, Any]:
        """获取面板数据"""
        if panel_id not in self.panels:
            raise ValueError(f"Panel not found: {panel_id}")
            
        cache_key = f"dashboard:panel:{panel_id}"
        try:
            # 尝试从缓存获取
            cached_data = await self.redis.get(cache_key)
            if cached_data:
                return eval(cached_data)
                
            # 缓存未命中，刷新数据
            return await self.refresh_panel(panel_id)
            
        except Exception as e:
            self.logger.error(
                f"Failed to get panel data {panel_id}: {str(e)}",
                exc_info=True
            )
            raise
            
    async def _panel_refresh_loop(self, panel_id: str):
        """面板刷新循环"""
        panel = self.panels[panel_id]
        try:
            while True:
                await self.refresh_panel(panel_id)
                await asyncio.sleep(panel.refresh_interval)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            self.logger.error(
                f"Error in panel refresh loop {panel_id}: {str(e)}",
                exc_info=True
            )
            
    async def _fetch_panel_data(self,
                               panel: DashboardPanel) -> Dict[str, Any]:
        """获取面板数据"""
        if panel.data_source == "metrics":
            return await self._fetch_metrics_data(panel)
        elif panel.data_source == "http":
            return await self._fetch_http_data(panel)
        else:
            raise ValueError(
                f"Unsupported data source: {panel.data_source}"
            )
            
    async def _fetch_metrics_data(self,
                                panel: DashboardPanel) -> Dict[str, Any]:
        """获取指标数据"""
        metrics = await self.metrics_collector.query_metrics(panel.query)
        return self._format_panel_data(panel, metrics)
        
    async def _fetch_http_data(self,
                              panel: DashboardPanel) -> Dict[str, Any]:
        """获取HTTP数据"""
        async with aiohttp.ClientSession() as session:
            async with session.get(panel.query) as response:
                data = await response.json()
                return self._format_panel_data(panel, data)
                
    def _format_panel_data(self, panel: DashboardPanel,
                          data: Any) -> Dict[str, Any]:
        """格式化面板数据"""
        return {
            'panel_id': panel.id,
            'title': panel.title,
            'type': panel.type,
            'data': data,
            'timestamp': datetime.now().isoformat(),
            'options': panel.options
        }
        
    async def _cache_panel_data(self, panel_id: str, data: Dict[str, Any]):
        """缓存面板数据"""
        cache_key = f"dashboard:panel:{panel_id}"
        await self.redis.setex(
            cache_key,
            self.panels[panel_id].refresh_interval,
            str(data)
        )
