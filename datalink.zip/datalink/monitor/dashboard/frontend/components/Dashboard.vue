<template>
  <div class="dashboard">
    <div class="dashboard-header">
      <h1>{{ title }}</h1>
      <div class="dashboard-controls">
        <select v-model="timeRange">
          <option value="1h">Last 1 hour</option>
          <option value="6h">Last 6 hours</option>
          <option value="24h">Last 24 hours</option>
          <option value="7d">Last 7 days</option>
        </select>
        <button @click="refreshAll">Refresh All</button>
      </div>
    </div>
    
    <div class="dashboard-grid">
      <div v-for="panel in panels"
           :key="panel.id"
           class="dashboard-panel"
           :class="panel.type">
        <div class="panel-header">
          <h3>{{ panel.title }}</h3>
          <button @click="refreshPanel(panel.id)">
            Refresh
          </button>
        </div>
        
        <div class="panel-content">
          <component :is="getPanelComponent(panel.type)"
                    :panel-data="panelData[panel.id]"
                    :options="panel.options"
                    @error="handleError" />
        </div>
        
        <div class="panel-footer">
          Last updated: {{ getLastUpdateTime(panel.id) }}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted, onUnmounted } from 'vue'
import LineChart from './charts/LineChart.vue'
import BarChart from './charts/BarChart.vue'
import GaugeChart from './charts/GaugeChart.vue'
import { formatDateTime } from '../utils/datetime'

export default {
  name: 'Dashboard',
  
  components: {
    LineChart,
    BarChart,
    GaugeChart
  },
  
  props: {
    title: {
      type: String,
      default: 'System Monitor'
    }
  },
  
  setup() {
    const panels = ref([])
    const panelData = ref({})
    const timeRange = ref('1h')
    const refreshTimers = ref({})
    
    // 获取面板列表
    const fetchPanels = async () => {
      try {
        const response = await fetch('/api/dashboard/panels')
        const data = await response.json()
        panels.value = data.panels
        
        // 初始化面板数据
        panels.value.forEach(panel => {
          refreshPanel(panel.id)
          setupAutoRefresh(panel)
        })
      } catch (error) {
        console.error('Failed to fetch panels:', error)
      }
    }
    
    // 刷新单个面板
    const refreshPanel = async (panelId) => {
      try {
        const response = await fetch(
          `/api/dashboard/panels/${panelId}?` +
          `timeRange=${timeRange.value}`
        )
        const data = await response.json()
        panelData.value[panelId] = data
      } catch (error) {
        console.error(`Failed to refresh panel ${panelId}:`, error)
      }
    }
    
    // 刷新所有面板
    const refreshAll = () => {
      panels.value.forEach(panel => refreshPanel(panel.id))
    }
    
    // 设置自动刷新
    const setupAutoRefresh = (panel) => {
      if (panel.refresh_interval > 0) {
        refreshTimers.value[panel.id] = setInterval(
          () => refreshPanel(panel.id),
          panel.refresh_interval * 1000
        )
      }
    }
    
    // 获取面板组件
    const getPanelComponent = (type) => {
      switch (type) {
        case 'line':
          return 'LineChart'
        case 'bar':
          return 'BarChart'
        case 'gauge':
          return 'GaugeChart'
        default:
          return null
      }
    }
    
    // 获取最后更新时间
    const getLastUpdateTime = (panelId) => {
      const data = panelData.value[panelId]
      return data ? formatDateTime(data.timestamp) : 'Never'
    }
    
    // 错误处理
    const handleError = (error) => {
      console.error('Panel error:', error)
      // 这里可以添加错误通知逻辑
    }
    
    // 生命周期钩子
    onMounted(() => {
      fetchPanels()
    })
    
    onUnmounted(() => {
      // 清理定时器
      Object.values(refreshTimers.value).forEach(timer => {
        clearInterval(timer)
      })
    })
    
    return {
      panels,
      panelData,
      timeRange,
      refreshPanel,
      refreshAll,
      getPanelComponent,
      getLastUpdateTime,
      handleError
    }
  }
}
</script>

<style scoped>
.dashboard {
  padding: 20px;
}

.dashboard-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.dashboard-controls {
  display: flex;
  gap: 10px;
}

.dashboard-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
  gap: 20px;
}

.dashboard-panel {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  padding: 15px;
}

.panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
}

.panel-content {
  min-height: 300px;
}

.panel-footer {
  margin-top: 10px;
  font-size: 0.8em;
  color: #666;
}
</style>
