from typing import Dict, Any, List
from datetime import datetime
from fastapi import APIRouter, HTTPException, Depends
from monitor.dashboard.service import DashboardService

router = APIRouter()

async def get_dashboard_service() -> DashboardService:
    """获取仪表板服务"""
    # 这里应该从依赖注入容器获取服务实例
    pass

@router.get("/panels")
async def list_panels(
    service: DashboardService = Depends(get_dashboard_service)
):
    """列出所有面板"""
    return {
        'panels': [
            {
                'id': panel.id,
                'title': panel.title,
                'type': panel.type,
                'refresh_interval': panel.refresh_interval
            }
            for panel in service.panels.values()
        ]
    }

@router.get("/panels/{panel_id}")
async def get_panel(
    panel_id: str,
    start_time: datetime = None,
    end_time: datetime = None,
    service: DashboardService = Depends(get_dashboard_service)
):
    """获取面板数据"""
    try:
        data = await service.get_panel_data(
            panel_id,
            start_time or datetime.now(),
            end_time or datetime.now()
        )
        return data
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/panels/{panel_id}/refresh")
async def refresh_panel(
    panel_id: str,
    service: DashboardService = Depends(get_dashboard_service)
):
    """刷新面板数据"""
    try:
        data = await service.refresh_panel(panel_id)
        return data
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
