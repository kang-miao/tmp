from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
import asyncio
import logging
from dataclasses import dataclass
import json

@dataclass
class MetricPoint:
    """指标数据点"""
    timestamp: datetime
    value: float
    labels: Dict[str, str]

class BaseMonitor(ABC):
    """监控基类"""
    def __init__(self, retention_days: int = 7):
        self.logger = logging.getLogger(self.__class__.__name__)
        self.retention_days = retention_days
        self.metrics: Dict[str, List[MetricPoint]] = {}
        self._cleanup_task: Optional[asyncio.Task] = None

    async def start(self):
        """启动监控"""
        self._cleanup_task = asyncio.create_task(self._periodic_cleanup())
        await self._init_monitor()

    async def stop(self):
        """停止监控"""
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
        await self._cleanup_metrics()

    @abstractmethod
    async def _init_monitor(self):
        """初始化监控"""
        pass

    async def _periodic_cleanup(self):
        """定期清理过期数据"""
        while True:
            try:
                await asyncio.sleep(3600)  # 每小时清理一次
                await self._cleanup_metrics()
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Error in periodic cleanup: {e}")

    async def _cleanup_metrics(self):
        """清理过期指标数据"""
        cutoff_time = datetime.now() - timedelta(days=self.retention_days)
        for metric_name in list(self.metrics.keys()):
            self.metrics[metric_name] = [
                point for point in self.metrics[metric_name]
                if point.timestamp > cutoff_time
            ]

    def add_metric_point(self, 
                        metric_name: str,
                        value: float,
                        labels: Optional[Dict[str, str]] = None):
        """添加指标数据点"""
        if metric_name not in self.metrics:
            self.metrics[metric_name] = []
        
        self.metrics[metric_name].append(
            MetricPoint(
                timestamp=datetime.now(),
                value=value,
                labels=labels or {}
            )
        )

    def get_metric_stats(self, 
                        metric_name: str,
                        time_window: timedelta = timedelta(minutes=5)
                        ) -> Dict[str, Any]:
        """获取指标统计信息"""
        if metric_name not in self.metrics:
            return {}

        cutoff_time = datetime.now() - time_window
        recent_points = [
            point for point in self.metrics[metric_name]
            if point.timestamp > cutoff_time
        ]

        if not recent_points:
            return {}

        values = [point.value for point in recent_points]
        return {
            'count': len(values),
            'min': min(values),
            'max': max(values),
            'avg': sum(values) / len(values),
            'latest': values[-1],
            'latest_timestamp': recent_points[-1].timestamp.isoformat()
        }

    def export_metrics(self) -> Dict[str, Any]:
        """导出所有指标数据"""
        return {
            metric_name: [
                {
                    'timestamp': point.timestamp.isoformat(),
                    'value': point.value,
                    'labels': point.labels
                }
                for point in points
            ]
            for metric_name, points in self.metrics.items()
        }
