from typing import Dict, Any, Optional
from datetime import datetime, timedelta
import statistics
from monitor.base_monitor import BaseMonitor

class LatencyMonitor(BaseMonitor):
    """延迟监控器"""
    def __init__(self, retention_days: int = 7):
        super().__init__(retention_days)
        self.current_operations: Dict[str, datetime] = {}

    async def _init_monitor(self):
        """初始化监控"""
        pass

    def start_operation(self, operation_id: str):
        """开始操作计时"""
        self.current_operations[operation_id] = datetime.now()

    def end_operation(self, operation_id: str, labels: Optional[Dict[str, str]] = None):
        """结束操作计时"""
        start_time = self.current_operations.pop(operation_id, None)
        if start_time:
            latency = (datetime.now() - start_time).total_seconds() * 1000  # 转换为毫秒
            self.add_metric_point(
                f'latency_{labels.get("type", "unknown")}',
                latency,
                labels
            )

    def get_latency_stats(self, 
                         operation_type: str,
                         time_window: timedelta = timedelta(minutes=5)
                         ) -> Dict[str, Any]:
        """获取延迟统计信息"""
        metric_name = f'latency_{operation_type}'
        stats = self.get_metric_stats(metric_name, time_window)
        
        if not stats:
            return {}

        recent_points = [
            point for point in self.metrics.get(metric_name, [])
            if point.timestamp > (datetime.now() - time_window)
        ]

        if recent_points:
            values = [point.value for point in recent_points]
            stats.update({
                'p50': statistics.median(values),
                'p95': statistics.quantiles(values, n=20)[18],
                'p99': statistics.quantiles(values, n=100)[98]
            })

        return stats
