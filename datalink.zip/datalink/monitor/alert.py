# monitor/alert.py

import asyncio
import logging
from typing import Dict, Any, List, Optional, Set
from datetime import datetime, timedelta
from dataclasses import dataclass
import json
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import aiohttp
from collections import defaultdict

@dataclass
class Alert:
    """告警信息"""
    id: str
    severity: str  # 'critical', 'warning', 'info'
    category: str  # 'system', 'performance', 'data', 'security'
    title: str
    message: str
    source: str
    timestamp: datetime
    metadata: Optional[Dict[str, Any]] = None
    acknowledged: bool = False
    resolved: bool = False
    resolve_time: Optional[datetime] = None

class AlertManager:
    """告警管理器
    
    负责系统告警的生成、分发、聚合和持久化，
    支持多种通知方式和告警策略。
    """

    def __init__(self, config: Dict[str, Any]):
        """初始化告警管理器
        
        Args:
            config: 告警配置
        """
        self.logger = logging.getLogger("monitor.alert")
        self.config = config
        
        # 告警存储
        self.active_alerts: Dict[str, Alert] = {}
        self.alert_history: List[Alert] = []
        
        # 告警聚合
        self.alert_groups: Dict[str, Set[str]] = defaultdict(set)
        self.group_cooldown = config.get('group_cooldown', 300)  # 5分钟
        self.last_group_notification: Dict[str, datetime] = {}
        
        # 通知配置
        self.notification_config = config.get('notifications', {})
        self.notification_cooldown = config.get('notification_cooldown', 60)  # 1分钟
        self.last_notification: Dict[str, datetime] = {}
        
        # 告警级别阈值
        self.severity_thresholds = config.get('severity_thresholds', {
            'critical': 0.9,  # 90%
            'warning': 0.7,   # 70%
            'info': 0.5       # 50%
        })
        
        # 运行标志
        self.is_running = False
        self._cleanup_task: Optional[asyncio.Task] = None

    async def start(self) -> None:
        """启动告警管理器"""
        self.is_running = True
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())
        self.logger.info("Alert manager started")

    async def stop(self) -> None:
        """停止告警管理器"""
        self.is_running = False
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
        self.logger.info("Alert manager stopped")

    async def raise_alert(self, category: str, title: str, message: str,
                         severity: str = 'warning', source: str = 'system',
                         metadata: Optional[Dict[str, Any]] = None) -> str:
        """生成新告警
        
        Args:
            category: 告警类别
            title: 告警标题
            message: 告警信息
            severity: 告警级别
            source: 告警来源
            metadata: 附加信息
            
        Returns:
            str: 告警ID
        """
        try:
            # 生成告警ID
            alert_id = f"{category}:{source}:{title}:{datetime.now().timestamp()}"
            
            # 创建告警对象
            alert = Alert(
                id=alert_id,
                severity=severity,
                category=category,
                title=title,
                message=message,
                source=source,
                timestamp=datetime.now(),
                metadata=metadata
            )
            
            # 存储告警
            self.active_alerts[alert_id] = alert
            self.alert_history.append(alert)
            
            # 添加到告警组
            group_key = f"{category}:{source}:{title}"
            self.alert_groups[group_key].add(alert_id)
            
            # 检查是否需要发送通知
            await self._check_notification(alert, group_key)
            
            return alert_id
            
        except Exception as e:
            self.logger.error(f"Error raising alert: {e}")
            raise

    async def acknowledge_alert(self, alert_id: str) -> bool:
        """确认告警
        
        Args:
            alert_id: 告警ID
            
        Returns:
            bool: 是否确认成功
        """
        try:
            if alert_id in self.active_alerts:
                alert = self.active_alerts[alert_id]
                alert.acknowledged = True
                return True
            return False
            
        except Exception as e:
            self.logger.error(f"Error acknowledging alert: {e}")
            return False

    async def resolve_alert(self, alert_id: str) -> bool:
        """解决告警
        
        Args:
            alert_id: 告警ID
            
        Returns:
            bool: 是否解决成功
        """
        try:
            if alert_id in self.active_alerts:
                alert = self.active_alerts[alert_id]
                alert.resolved = True
                alert.resolve_time = datetime.now()
                
                # 从活动告警中移除
                del self.active_alerts[alert_id]
                
                # 从告警组中移除
                for group in self.alert_groups.values():
                    group.discard(alert_id)
                
                return True
            return False
            
        except Exception as e:
            self.logger.error(f"Error resolving alert: {e}")
            return False

    async def _check_notification(self, alert: Alert, group_key: str) -> None:
        """检查是否需要发送通知"""
        try:
            current_time = datetime.now()
            
            # 检查告警组冷却时间
            if (group_key in self.last_group_notification and
                (current_time - self.last_group_notification[group_key]).total_seconds() 
                < self.group_cooldown):
                return
            
            # 获取组内告警数量
            group_alerts = len(self.alert_groups[group_key])
            
            # 检查是否需要发送通知
            should_notify = (
                alert.severity == 'critical' or
                group_alerts >= self.config.get('group_threshold', 3)
            )
            
            if should_notify:
                # 更新最后通知时间
                self.last_group_notification[group_key] = current_time
                
                # 发送通知
                await self._send_notifications(alert, group_alerts)
            
        except Exception as e:
            self.logger.error(f"Error checking notification: {e}")

    async def _send_notifications(self, alert: Alert, group_count: int) -> None:
        """发送告警通知"""
        try:
            # 准备通知内容
            notification = {
                'title': alert.title,
                'message': alert.message,
                'severity': alert.severity,
                'category': alert.category,
                'source': alert.source,
                'timestamp': alert.timestamp.isoformat(),
                'group_count': group_count,
                'metadata': alert.metadata
            }
            
            # 发送邮件通知
            if 'email' in self.notification_config:
                await self._send_email_notification(notification)
            
            # 发送Webhook通知
            if 'webhook' in self.notification_config:
                await self._send_webhook_notification(notification)
            
            # 发送Slack通知
            if 'slack' in self.notification_config:
                await self._send_slack_notification(notification)
            
        except Exception as e:
            self.logger.error(f"Error sending notifications: {e}")

    async def _send_email_notification(self, notification: Dict[str, Any]) -> None:
        """发送邮件通知"""
        try:
            email_config = self.notification_config['email']
            
            # 创建邮件
            msg = MIMEMultipart()
            msg['Subject'] = f"[{notification['severity'].upper()}] {notification['title']}"
            msg['From'] = email_config['sender']
            msg['To'] = ', '.join(email_config['recipients'])
            
            # 邮件内容
            body = f"""
            Alert Details:
            -------------
            Severity: {notification['severity']}
            Category: {notification['category']}
            Source: {notification['source']}
            Time: {notification['timestamp']}
            
            Message:
            {notification['message']}
            
            Similar Alerts: {notification['group_count']}
            
            Metadata:
            {json.dumps(notification['metadata'], indent=2) if notification['metadata'] else 'None'}
            """
            
            msg.attach(MIMEText(body, 'plain'))
            
            # 发送邮件
            with smtplib.SMTP(email_config['smtp_server'], email_config['smtp_port']) as server:
                server.starttls()
                server.login(email_config['sender'], email_config['password'])
                server.send_message(msg)
            
        except Exception as e:
            self.logger.error(f"Error sending email notification: {e}")

    async def _send_webhook_notification(self, notification: Dict[str, Any]) -> None:
        """发送Webhook通知"""
        try:
            webhook_config = self.notification_config['webhook']
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    webhook_config['url'],
                    json=notification,
                    headers=webhook_config.get('headers', {})
                ) as response:
                    if response.status != 200:
                        raise Exception(f"Webhook request failed: {response.status}")
                        
        except Exception as e:
            self.logger.error(f"Error sending webhook notification: {e}")

    async def _send_slack_notification(self, notification: Dict[str, Any]) -> None:
        """发送Slack通知"""
        try:
            slack_config = self.notification_config['slack']
            
            # 构建Slack消息
            message = {
                'text': f"*[{notification['severity'].upper()}] {notification['title']}*",
                'blocks': [
                    {
                        'type': 'section',
                        'text': {
                            'type': 'mrkdwn',
                            'text': f"*Alert Details*\n"
                                   f">Severity: {notification['severity']}\n"
                                   f">Category: {notification['category']}\n"
                                   f">Source: {notification['source']}\n"
                                   f">Time: {notification['timestamp']}\n\n"
                                   f"*Message*\n"
                                   f">{notification['message']}\n\n"
                                   f"Similar Alerts: {notification['group_count']}"
                        }
                    }
                ]
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    slack_config['webhook_url'],
                    json=message
                ) as response:
                    if response.status != 200:
                        raise Exception(f"Slack notification failed: {response.status}")
                        
        except Exception as e:
            self.logger.error(f"Error sending slack notification: {e}")

    async def _cleanup_loop(self) -> None:
        """清理过期告警的循环"""
        while self.is_running:
            try:
                await self._cleanup_old_alerts()
                await asyncio.sleep(3600)  # 每小时清理一次
                
            except Exception as e:
                self.logger.error(f"Error in cleanup loop: {e}")
                await asyncio.sleep(60)

    async def _cleanup_old_alerts(self) -> None:
        """清理过期告警"""
        try:
            current_time = datetime.now()
            retention_days = self.config.get('alert_retention_days', 30)
            cutoff_time = current_time - timedelta(days=retention_days)
            
            # 清理历史告警
            self.alert_history = [
                alert for alert in self.alert_history
                if alert.timestamp > cutoff_time
            ]
            
            # 清理过期的告警组
            for group_key in list(self.alert_groups.keys()):
                if (group_key in self.last_group_notification and
                    self.last_group_notification[group_key] < cutoff_time):
                    del self.alert_groups[group_key]
                    del self.last_group_notification[group_key]
            
        except Exception as e:
            self.logger.error(f"Error cleaning up old alerts: {e}")

    async def get_active_alerts(self, 
                              category: Optional[str] = None,
                              severity: Optional[str] = None) -> List[Alert]:
        """获取活动告警列表"""
        try:
            alerts = list(self.active_alerts.values())
            
            if category:
                alerts = [a for a in alerts if a.category == category]
            if severity:
                alerts = [a for a in alerts if a.severity == severity]
                
            return sorted(alerts, key=lambda x: x.timestamp, reverse=True)
            
        except Exception as e:
            self.logger.error(f"Error getting active alerts: {e}")
            return []

    async def get_alert_summary(self) -> Dict[str, Any]:
        """获取告警摘要"""
        try:
            return {
                'total_active': len(self.active_alerts),
                'total_history': len(self.alert_history),
                'by_severity': {
                    severity: len([a for a in self.active_alerts.values() 
                                 if a.severity == severity])
                    for severity in ['critical', 'warning', 'info']
                },
                'by_category': {
                    category: len([a for a in self.active_alerts.values() 
                                 if a.category == category])
                    for category in set(a.category for a in self.active_alerts.values())
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error getting alert summary: {e}")
            return {}