from typing import Dict, Any, List, Optional
from datetime import datetime
import psutil
import asyncio
from dataclasses import dataclass
from logging import Logger

@dataclass
class MetricPoint:
    """指标数据点"""
    name: str
    value: float
    labels: Dict[str, str]
    timestamp: datetime

class MetricsCollector:
    """指标收集器"""
    def __init__(self, logger: Logger, collection_interval: int = 60):
        self.logger = logger
        self.collection_interval = collection_interval
        self.collectors = {
            'system': self._collect_system_metrics,
            'business': self._collect_business_metrics,
            'storage': self._collect_storage_metrics,
            'network': self._collect_network_metrics
        }
        self.metrics: List[MetricPoint] = []
        self._running = False
        self._collection_task: Optional[asyncio.Task] = None

    async def start(self):
        """启动收集器"""
        self._running = True
        self._collection_task = asyncio.create_task(self._collection_loop())
        self.logger.info("Metrics collector started")

    async def stop(self):
        """停止收集器"""
        self._running = False
        if self._collection_task:
            self._collection_task.cancel()
            try:
                await self._collection_task
            except asyncio.CancelledError:
                pass
        self.logger.info("Metrics collector stopped")

    async def _collection_loop(self):
        """收集循环"""
        while self._running:
            try:
                await self._collect_all_metrics()
                await asyncio.sleep(self.collection_interval)
            except Exception as e:
                self.logger.error(f"Error collecting metrics: {str(e)}", exc_info=True)
                await asyncio.sleep(5)  # 错误后等待较短时间

    async def _collect_all_metrics(self):
        """收集所有指标"""
        for collector_name, collector_func in self.collectors.items():
            try:
                metrics = await collector_func()
                self._store_metrics(metrics, {'collector': collector_name})
            except Exception as e:
                self.logger.error(
                    f"Error collecting {collector_name} metrics: {str(e)}",
                    exc_info=True
                )

    async def _collect_system_metrics(self) -> List[MetricPoint]:
        """收集系统指标"""
        metrics = []
        now = datetime.now()

        # CPU 使用率
        cpu_percent = psutil.cpu_percent(interval=1)
        metrics.append(MetricPoint(
            name='system_cpu_usage',
            value=cpu_percent,
            labels={'type': 'cpu'},
            timestamp=now
        ))

        # 内存使用
        memory = psutil.virtual_memory()
        metrics.append(MetricPoint(
            name='system_memory_usage',
            value=memory.percent,
            labels={'type': 'memory'},
            timestamp=now
        ))

        # 磁盘使用
        disk = psutil.disk_usage('/')
        metrics.append(MetricPoint(
            name='system_disk_usage',
            value=disk.percent,
            labels={'type': 'disk', 'path': '/'},
            timestamp=now
        ))

        return metrics

    async def _collect_business_metrics(self) -> List[MetricPoint]:
        """收集业务指标"""
        metrics = []
        now = datetime.now()

        # 这里添加业务相关的指标收集
        # 例如：处理的消息数量、活跃连接数等
        
        return metrics

    async def _collect_storage_metrics(self) -> List[MetricPoint]:
        """收集存储指标"""
        metrics = []
        now = datetime.now()

        # 这里添加存储相关的指标收集
        # 例如：数据库连接数、查询延迟等
        
        return metrics

    async def _collect_network_metrics(self) -> List[MetricPoint]:
        """收集网络指标"""
        metrics = []
        now = datetime.now()

        # 网络 IO 统计
        net_io = psutil.net_io_counters()
        metrics.extend([
            MetricPoint(
                name='system_network_bytes_sent',
                value=net_io.bytes_sent,
                labels={'type': 'network', 'direction': 'out'},
                timestamp=now
            ),
            MetricPoint(
                name='system_network_bytes_recv',
                value=net_io.bytes_recv,
                labels={'type': 'network', 'direction': 'in'},
                timestamp=now
            )
        ])

        return metrics

    def _store_metrics(self, metrics: List[MetricPoint], 
                      additional_labels: Dict[str, str]):
        """存储指标"""
        for metric in metrics:
            metric.labels.update(additional_labels)
            self.metrics.append(metric)

    def get_metrics(self, 
                   metric_name: Optional[str] = None,
                   labels: Optional[Dict[str, str]] = None,
                   start_time: Optional[datetime] = None,
                   end_time: Optional[datetime] = None) -> List[MetricPoint]:
        """获取指标"""
        filtered_metrics = self.metrics

        if metric_name:
            filtered_metrics = [
                m for m in filtered_metrics if m.name == metric_name
            ]

        if labels:
            filtered_metrics = [
                m for m in filtered_metrics
                if all(m.labels.get(k) == v for k, v in labels.items())
            ]

        if start_time:
            filtered_metrics = [
                m for m in filtered_metrics if m.timestamp >= start_time
            ]

        if end_time:
            filtered_metrics = [
                m for m in filtered_metrics if m.timestamp <= end_time
            ]

        return filtered_metrics

    def clear_old_metrics(self, retention_time: datetime):
        """清理旧指标"""
        self.metrics = [
            m for m in self.metrics if m.timestamp >= retention_time
        ]
