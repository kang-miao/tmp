from typing import Dict, Any, List
from datetime import datetime
import json
from prometheus_client import (
    Counter, Gauge, Histogram,
    CollectorRegistry, generate_latest
)
from monitor.metrics.collector import MetricsCollector, MetricPoint

class MetricsExporter:
    """指标导出器"""
    def __init__(self, collector: MetricsCollector):
        self.collector = collector
        self.registry = CollectorRegistry()
        self._setup_metrics()

    def _setup_metrics(self):
        """设置 Prometheus 指标"""
        self.metrics = {
            # 系统指标
            'system_cpu_usage': Gauge(
                'system_cpu_usage',
                'System CPU usage percentage',
                ['type'],
                registry=self.registry
            ),
            'system_memory_usage': Gauge(
                'system_memory_usage',
                'System memory usage percentage',
                ['type'],
                registry=self.registry
            ),
            'system_disk_usage': Gauge(
                'system_disk_usage',
                'System disk usage percentage',
                ['type', 'path'],
                registry=self.registry
            ),
            'system_network_bytes': Counter(
                'system_network_bytes',
                'Network traffic in bytes',
                ['type', 'direction'],
                registry=self.registry
            ),
            
            # 业务指标
            'business_message_count': Counter(
                'business_message_count',
                'Number of processed messages',
                ['type', 'status'],
                registry=self.registry
            ),
            'business_processing_time': Histogram(
                'business_processing_time',
                'Message processing time in seconds',
                ['type'],
                registry=self.registry
            ),
            
            # 存储指标
            'storage_operation_count': Counter(
                'storage_operation_count',
                'Number of storage operations',
                ['type', 'operation'],
                registry=self.registry
            ),
            'storage_operation_time': Histogram(
                'storage_operation_time',
                'Storage operation time in seconds',
                ['type', 'operation'],
                registry=self.registry
            )
        }

    def update_prometheus_metrics(self):
        """更新 Prometheus 指标"""
        metrics = self.collector.get_metrics()
        
        for metric in metrics:
            if metric.name in self.metrics:
                prom_metric = self.metrics[metric.name]
                
                if isinstance(prom_metric, (Counter, Gauge)):
                    prom_metric.labels(**metric.labels).set(metric.value)
                elif isinstance(prom_metric, Histogram):
                    prom_metric.labels(**metric.labels).observe(metric.value)

    def export_prometheus(self) -> bytes:
        """导出 Prometheus 格式的指标"""
        self.update_prometheus_metrics()
        return generate_latest(self.registry)

    def export_json(self) -> str:
        """导出 JSON 格式的指标"""
        metrics = self.collector.get_metrics()
        return json.dumps([
            {
                'name': m.name,
                'value': m.value,
                'labels': m.labels,
                'timestamp': m.timestamp.isoformat()
            }
            for m in metrics
        ])

    def export_influx(self) -> List[str]:
        """导出 InfluxDB 行协议格式的指标"""
        metrics = self.collector.get_metrics()
        lines = []
        
        for metric in metrics:
            tags = ','.join(
                f"{k}={v}" for k, v in metric.labels.items()
            )
            timestamp = int(metric.timestamp.timestamp() * 1e9)  # 纳秒
            lines.append(
                f"{metric.name},{tags} value={metric.value} {timestamp}"
            )
            
        return lines
