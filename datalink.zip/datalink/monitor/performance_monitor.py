# monitor/performance_monitor.py

import asyncio
import logging
from typing import Dict, Any, List, Optional, DefaultDict
from datetime import datetime, timedelta
from collections import defaultdict
import statistics
import time
import psutil
import gc
from dataclasses import dataclass
import json

from utils.metrics import MetricsManager, Timer
from core.market_data import MarketType, DataType
from monitor.base_monitor import BaseMonitor

@dataclass
class LatencyStats:
    """延迟统计信息"""
    count: int
    min_latency: float
    max_latency: float
    avg_latency: float
    p95_latency: float
    p99_latency: float

@dataclass
class ThroughputStats:
    """吞吐量统计信息"""
    messages_per_second: float
    bytes_per_second: float
    total_messages: int
    total_bytes: int

class PerformanceMonitor(BaseMonitor):
    """性能监控器"""
    def __init__(self, retention_days: int = 7):
        super().__init__(retention_days)
        self.process = psutil.Process()
        self._monitoring_task: Optional[asyncio.Task] = None

    async def _init_monitor(self):
        """初始化监控"""
        self._monitoring_task = asyncio.create_task(
            self._collect_metrics()
        )

    async def stop(self):
        """停止监控"""
        if self._monitoring_task:
            self._monitoring_task.cancel()
            try:
                await self._monitoring_task
            except asyncio.CancelledError:
                pass
        await super().stop()

    async def _collect_metrics(self):
        """收集性能指标"""
        while True:
            try:
                # CPU使用率
                cpu_percent = self.process.cpu_percent()
                self.add_metric_point('cpu_usage', cpu_percent)

                # 内存使用
                memory_info = self.process.memory_info()
                self.add_metric_point('memory_rss', memory_info.rss)
                self.add_metric_point('memory_vms', memory_info.vms)

                # 系统内存
                system_memory = psutil.virtual_memory()
                self.add_metric_point('system_memory_used', system_memory.percent)

                # 文件描述符
                try:
                    fd_count = self.process.num_fds()
                    self.add_metric_point('file_descriptors', fd_count)
                except AttributeError:  # Windows系统不支持
                    pass

                # GC统计
                gc_counts = gc.get_count()
                for i, count in enumerate(gc_counts):
                    self.add_metric_point(f'gc_generation_{i}', count)

                # 线程数
                thread_count = self.process.num_threads()
                self.add_metric_point('thread_count', thread_count)

                # IO统计
                io_counters = self.process.io_counters()
                self.add_metric_point('io_read_bytes', io_counters.read_bytes)
                self.add_metric_point('io_write_bytes', io_counters.write_bytes)

                await asyncio.sleep(1)  # 每秒采集一次

            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Error collecting metrics: {e}")
                await asyncio.sleep(5)  # 发生错误时等待较长时间

    async def get_performance_report(self, 
                                   time_window: timedelta = timedelta(minutes=5)
                                   ) -> Dict[str, Any]:
        """获取性能报告"""
        return {
            'cpu': self.get_metric_stats('cpu_usage', time_window),
            'memory': {
                'rss': self.get_metric_stats('memory_rss', time_window),
                'vms': self.get_metric_stats('memory_vms', time_window),
                'system': self.get_metric_stats('system_memory_used', time_window)
            },
            'io': {
                'read': self.get_metric_stats('io_read_bytes', time_window),
                'write': self.get_metric_stats('io_write_bytes', time_window)
            },
            'threads': self.get_metric_stats('thread_count', time_window),
            'file_descriptors': self.get_metric_stats('file_descriptors', time_window),
            'gc': {
                f'gen_{i}': self.get_metric_stats(f'gc_generation_{i}', time_window)
                for i in range(3)
            }
        }

    def get_resource_usage(self) -> Dict[str, Any]:
        """获取当前资源使用情况"""
        memory_info = self.process.memory_info()
        return {
            'cpu_percent': self.process.cpu_percent(),
            'memory_rss': memory_info.rss,
            'memory_vms': memory_info.vms,
            'thread_count': self.process.num_threads(),
            'file_descriptors': getattr(self.process, 'num_fds', lambda: None)()
        }