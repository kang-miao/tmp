# monitor/performance_monitor.py

import asyncio
import logging
from typing import Dict, Any, List, Optional, DefaultDict
from datetime import datetime, timedelta
from collections import defaultdict
import statistics
import time
import psutil
import gc
from dataclasses import dataclass
import json

from utils.metrics import MetricsManager, Timer
from core.market_data import MarketType, DataType

@dataclass
class LatencyStats:
    """延迟统计信息"""
    count: int
    min_latency: float
    max_latency: float
    avg_latency: float
    p95_latency: float
    p99_latency: float

@dataclass
class ThroughputStats:
    """吞吐量统计信息"""
    messages_per_second: float
    bytes_per_second: float
    total_messages: int
    total_bytes: int

class PerformanceMonitor:
    """性能监控器
    
    监控系统关键操作的性能指标，包括：
    - 数据处理延迟
    - 系统吞吐量
    - 资源使用效率
    - GC性能
    """

    def __init__(self, metrics_manager: MetricsManager, config: Dict[str, Any]):
        """初始化性能监控器
        
        Args:
            metrics_manager: 指标管理器
            config: 监控配置
        """
        self.logger = logging.getLogger("monitor.performance")
        self.metrics = metrics_manager
        self.config = config
        
        # 延迟统计
        self.latency_samples: DefaultDict[str, List[float]] = defaultdict(list)
        self.latency_window = config.get('latency_window', 3600)  # 1小时
        
        # 吞吐量统计
        self.throughput_stats: DefaultDict[str, ThroughputStats] = defaultdict(
            lambda: ThroughputStats(0, 0, 0, 0)
        )
        
        # 资源使用统计
        self.resource_stats: Dict[str, List[float]] = {
            'cpu': [],
            'memory': [],
            'disk_io': [],
            'network_io': []
        }
        
        # GC统计
        self.gc_stats: Dict[str, int] = {
            'collections': 0,
            'collected': 0,
            'uncollectable': 0
        }
        
        # 监控配置
        self.check_interval = config.get('check_interval', 5)  # 秒
        self.stats_retention = config.get('stats_retention', 86400)  # 24小时
        
        # 运行标志
        self.is_running = False
        self._monitor_task: Optional[asyncio.Task] = None
        
        # 性能基准
        self.baseline_stats: Dict[str, Any] = {}

    async def start(self) -> None:
        """启动性能监控"""
        self.is_running = True
        self._monitor_task = asyncio.create_task(self._monitor_loop())
        await self._establish_baseline()
        self.logger.info("Performance monitor started")

    async def stop(self) -> None:
        """停止性能监控"""
        self.is_running = False
        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass
        self.logger.info("Performance monitor stopped")

    async def _monitor_loop(self) -> None:
        """主监控循环"""
        while self.is_running:
            try:
                # 收集性能指标
                await self._collect_resource_stats()
                await self._collect_gc_stats()
                
                # 清理过期数据
                self._cleanup_old_stats()
                
                # 分析性能指标
                await self._analyze_performance()
                
                await asyncio.sleep(self.check_interval)
                
            except Exception as e:
                self.logger.error(f"Error in monitor loop: {e}")
                await asyncio.sleep(5)

    async def record_latency(self, operation: str, latency: float,
                           metadata: Optional[Dict[str, Any]] = None) -> None:
        """记录操作延迟
        
        Args:
            operation: 操作名称
            latency: 延迟时间（秒）
            metadata: 附加信息
        """
        try:
            self.latency_samples[operation].append(latency)
            await self.metrics.performance.record_latency(
                operation,
                latency,
                metadata
            )
        except Exception as e:
            self.logger.error(f"Error recording latency: {e}")

    async def record_throughput(self, operation: str, message_count: int,
                              byte_count: int) -> None:
        """记录吞吐量
        
        Args:
            operation: 操作名称
            message_count: 消息数量
            byte_count: 字节数
        """
        try:
            stats = self.throughput_stats[operation]
            stats.total_messages += message_count
            stats.total_bytes += byte_count
            
            # 计算每秒统计
            stats.messages_per_second = (
                message_count / self.check_interval
            )
            stats.bytes_per_second = byte_count / self.check_interval
            
            await self.metrics.performance.record_throughput(
                operation,
                stats.messages_per_second,
                {'bytes_per_second': stats.bytes_per_second}
            )
        except Exception as e:
            self.logger.error(f"Error recording throughput: {e}")

    async def _collect_resource_stats(self) -> None:
        """收集资源使用统计"""
        try:
            # CPU使用率
            cpu_percent = psutil.cpu_percent(interval=1)
            self.resource_stats['cpu'].append(cpu_percent)
            
            # 内存使用
            memory = psutil.virtual_memory()
            self.resource_stats['memory'].append(memory.percent)
            
            # 磁盘IO
            disk_io = psutil.disk_io_counters()
            self.resource_stats['disk_io'].append(
                disk_io.read_bytes + disk_io.write_bytes
            )
            
            # 网络IO
            net_io = psutil.net_io_counters()
            self.resource_stats['network_io'].append(
                net_io.bytes_sent + net_io.bytes_recv
            )
            
            # 记录资源指标
            await self.metrics.business.record_market_data(
                'system',
                'resources',
                cpu_percent,
                {
                    'memory_percent': memory.percent,
                    'disk_io': disk_io.read_bytes + disk_io.write_bytes,
                    'network_io': net_io.bytes_sent + net_io.bytes_recv
                }
            )
            
        except Exception as e:
            self.logger.error(f"Error collecting resource stats: {e}")

    async def _collect_gc_stats(self) -> None:
        """收集GC统计"""
        try:
            # 触发GC并收集统计
            gc.collect()
            stats = gc.get_stats()
            
            for gen, stat in enumerate(stats):
                self.gc_stats['collections'] += stat['collections']
                self.gc_stats['collected'] += stat['collected']
                self.gc_stats['uncollectable'] += stat['uncollectable']
                
            await self.metrics.business.record_market_data(
                'system',
                'gc_stats',
                self.gc_stats['collections'],
                {
                    'collected': self.gc_stats['collected'],
                    'uncollectable': self.gc_stats['uncollectable']
                }
            )
            
        except Exception as e:
            self.logger.error(f"Error collecting GC stats: {e}")

    def _cleanup_old_stats(self) -> None:
        """清理过期统计数据"""
        try:
            current_time = time.time()
            cutoff_time = current_time - self.stats_retention
            
            # 清理延迟样本
            for operation in self.latency_samples:
                self.latency_samples[operation] = [
                    sample for sample in self.latency_samples[operation]
                    if sample > cutoff_time
                ]
            
            # 清理资源统计
            for resource in self.resource_stats:
                self.resource_stats[resource] = [
                    stat for stat in self.resource_stats[resource]
                    if stat > cutoff_time
                ]
                
        except Exception as e:
            self.logger.error(f"Error cleaning up old stats: {e}")

    async def _analyze_performance(self) -> None:
        """分析性能指标"""
        try:
            # 分析延迟
            for operation, samples in self.latency_samples.items():
                if samples:
                    stats = self._calculate_latency_stats(samples)
                    await self._check_latency_threshold(operation, stats)
            
            # 分析资源使用
            await self._analyze_resource_usage()
            
            # 分析GC性能
            await self._analyze_gc_performance()
            
        except Exception as e:
            self.logger.error(f"Error analyzing performance: {e}")

    def _calculate_latency_stats(self, samples: List[float]) -> LatencyStats:
        """计算延迟统计信息"""
        if not samples:
            return LatencyStats(0, 0, 0, 0, 0, 0)
            
        sorted_samples = sorted(samples)
        p95_index = int(len(samples) * 0.95)
        p99_index = int(len(samples) * 0.99)
        
        return LatencyStats(
            count=len(samples),
            min_latency=min(samples),
            max_latency=max(samples),
            avg_latency=statistics.mean(samples),
            p95_latency=sorted_samples[p95_index],
            p99_latency=sorted_samples[p99_index]
        )

    async def _analyze_resource_usage(self) -> None:
        """分析资源使用情况"""
        try:
            for resource, stats in self.resource_stats.items():
                if stats:
                    avg_usage = statistics.mean(stats)
                    max_usage = max(stats)
                    
                    # 检查是否超过基准线
                    baseline = self.baseline_stats.get(resource, {})
                    if baseline and avg_usage > baseline.get('avg', 0) * 1.5:
                        await self._raise_performance_alert(
                            f"High {resource} usage",
                            f"Current: {avg_usage:.1f}%, Baseline: {baseline['avg']:.1f}%"
                        )
                        
        except Exception as e:
            self.logger.error(f"Error analyzing resource usage: {e}")

    async def _analyze_gc_performance(self) -> None:
        """分析GC性能"""
        try:
            # 检查GC效率
            if self.gc_stats['collections'] > 0:
                efficiency = (
                    self.gc_stats['collected'] /
                    (self.gc_stats['collected'] + self.gc_stats['uncollectable'])
                )
                
                if efficiency < 0.9:  # 如果GC效率低于90%
                    await self._raise_performance_alert(
                        "Low GC efficiency",
                        f"Current efficiency: {efficiency:.1%}"
                    )
                    
        except Exception as e:
            self.logger.error(f"Error analyzing GC performance: {e}")

    async def _establish_baseline(self) -> None:
        """建立性能基准"""
        try:
            # 收集初始性能数据
            for _ in range(10):
                await self._collect_resource_stats()
                await asyncio.sleep(1)
            
            # 计算基准值
            self.baseline_stats = {
                resource: {
                    'avg': statistics.mean(stats),
                    'std': statistics.stdev(stats) if len(stats) > 1 else 0
                }
                for resource, stats in self.resource_stats.items()
            }
            
            self.logger.info("Performance baseline established")
            
        except Exception as e:
            self.logger.error(f"Error establishing baseline: {e}")

    async def _raise_performance_alert(self, title: str, message: str) -> None:
        """发送性能告警"""
        try:
            self.logger.warning(f"Performance Alert: {title} - {message}")
            
            # 记录告警指标
            await self.metrics.business.record_market_data(
                'alerts',
                'performance',
                1,
                {
                    'title': title,
                    'message': message
                }
            )
            
        except Exception as e:
            self.logger.error(f"Error raising performance alert: {e}")

    async def get_performance_report(self) -> Dict[str, Any]:
        """生成性能报告"""
        try:
            return {
                'timestamp': datetime.now().isoformat(),
                'latency': {
                    operation: self._calculate_latency_stats(samples).__dict__
                    for operation, samples in self.latency_samples.items()
                },
                'throughput': {
                    operation: stats.__dict__
                    for operation, stats in self.throughput_stats.items()
                },
                'resources': {
                    resource: {
                        'current': stats[-1] if stats else None,
                        'avg': statistics.mean(stats) if stats else None,
                        'max': max(stats) if stats else None
                    }
                    for resource, stats in self.resource_stats.items()
                },
                'gc': self.gc_stats,
                'baseline': self.baseline_stats
            }
            
        except Exception as e:
            self.logger.error(f"Error generating performance report: {e}")
            return {
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }