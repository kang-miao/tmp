from typing import Dict, List, Callable, Any, Optional
import asyncio
from logging import Logger
from events.base_event import BaseEvent

class EventBus:
    """事件总线"""
    def __init__(self, logger: Logger):
        self.logger = logger
        self.handlers: Dict[str, List[Callable]] = {}
        self.middleware: List[Callable] = []
        self._running = False
        self._queue: asyncio.Queue = asyncio.Queue()

    def subscribe(self, event_type: str, handler: Callable):
        """订阅事件"""
        if event_type not in self.handlers:
            self.handlers[event_type] = []
        self.handlers[event_type].append(handler)
        self.logger.info(
            f"Handler {handler.__name__} subscribed to {event_type}"
        )

    def unsubscribe(self, event_type: str, handler: Callable):
        """取消订阅"""
        if event_type in self.handlers:
            self.handlers[event_type].remove(handler)
            self.logger.info(
                f"Handler {handler.__name__} unsubscribed from {event_type}"
            )

    def add_middleware(self, middleware: Callable):
        """添加中间件"""
        self.middleware.append(middleware)
        self.logger.info(f"Middleware {middleware.__name__} added")

    async def publish(self, event: BaseEvent):
        """发布事件"""
        await self._queue.put(event)
        self.logger.debug(
            f"Event {event.event_type} queued",
            extra={'event_id': event.event_id}
        )

    async def start(self):
        """启动事件总线"""
        self._running = True
        self.logger.info("Event bus started")
        while self._running:
            try:
                event = await self._queue.get()
                await self._process_event(event)
                self._queue.task_done()
            except Exception as e:
                self.logger.error(
                    f"Error processing event: {str(e)}",
                    exc_info=True
                )

    async def stop(self):
        """停止事件总线"""
        self._running = False
        self.logger.info("Event bus stopped")

    async def _process_event(self, event: BaseEvent):
        """处理事件"""
        try:
            # 应用中间件
            processed_event = event
            for middleware in self.middleware:
                processed_event = await middleware(processed_event)
                if processed_event is None:
                    return

            # 调用处理器
            if event.event_type in self.handlers:
                for handler in self.handlers[event.event_type]:
                    try:
                        await handler(processed_event)
                    except Exception as e:
                        self.logger.error(
                            f"Error in handler {handler.__name__}: {str(e)}",
                            exc_info=True,
                            extra={'event_id': event.event_id}
                        )
            else:
                self.logger.warning(
                    f"No handlers for event type: {event.event_type}",
                    extra={'event_id': event.event_id}
                )

        except Exception as e:
            self.logger.error(
                f"Error processing event: {str(e)}",
                exc_info=True,
                extra={'event_id': event.event_id}
            )
