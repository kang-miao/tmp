from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Any, Optional
from uuid import uuid4

@dataclass
class BaseEvent:
    """事件基类"""
    event_id: str = field(default_factory=lambda: str(uuid4()))
    event_type: str = field(default="base_event")
    timestamp: datetime = field(default_factory=datetime.now)
    source: str = field(default="system")
    data: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    correlation_id: Optional[str] = field(default=None)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'event_id': self.event_id,
            'event_type': self.event_type,
            'timestamp': self.timestamp.isoformat(),
            'source': self.source,
            'data': self.data,
            'metadata': self.metadata,
            'correlation_id': self.correlation_id
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BaseEvent':
        """从字典创建事件"""
        data['timestamp'] = datetime.fromisoformat(data['timestamp'])
        return cls(**data)
