from abc import ABC, abstractmethod
from typing import Dict, Any
from events.base_event import BaseEvent
from logging import Logger

class BaseHandler(ABC):
    """事件处理器基类"""
    def __init__(self, logger: Logger):
        self.logger = logger

    @abstractmethod
    async def handle(self, event: BaseEvent):
        """处理事件"""
        pass

    async def __call__(self, event: BaseEvent):
        """使处理器可调用"""
        await self.handle(event)
