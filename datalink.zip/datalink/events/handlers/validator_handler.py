from events.handlers.base_handler import BaseHandler
from events.base_event import BaseEvent
from validators.market_validator import MarketDataValidator

class ValidatorEventHandler(BaseHandler):
    """验证器事件处理器"""
    def __init__(self, logger, validator: MarketDataValidator):
        super().__init__(logger)
        self.validator = validator

    async def handle(self, event: BaseEvent):
        """处理验证事件"""
        if event.event_type == 'market_data':
            await self._handle_market_data(event)

    async def _handle_market_data(self, event: BaseEvent):
        """处理市场数据验证"""
        data = event.data
        validation_result = await self.validator.validate(data)
        
        if not validation_result.is_valid:
            self.logger.warning(
                "Market data validation failed",
                extra={
                    'event_id': event.event_id,
                    'errors': validation_result.errors,
                    'warnings': validation_result.warnings
                }
            )
            
            # 发布验证失败事件
            await self.publish_validation_result(event, validation_result)

    async def publish_validation_result(self, original_event: BaseEvent,
                                      validation_result):
        """发布验证结果事件"""
        validation_event = BaseEvent(
            event_type='validation_result',
            source='validator',
            data={
                'original_event_id': original_event.event_id,
                'is_valid': validation_result.is_valid,
                'errors': validation_result.errors,
                'warnings': validation_result.warnings,
                'metadata': validation_result.metadata
            },
            correlation_id=original_event.event_id
        )
        await self.event_bus.publish(validation_event)
