from events.handlers.base_handler import BaseHandler
from events.base_event import BaseEvent
from consistency.data_checker import DataConsistencyChecker

class CheckerEventHandler(BaseHandler):
    """检查器事件处理器"""
    def __init__(self, logger, checker: DataConsistencyChecker):
        super().__init__(logger)
        self.checker = checker

    async def handle(self, event: BaseEvent):
        """处理检查事件"""
        if event.event_type == 'consistency_check':
            await self._handle_consistency_check(event)

    async def _handle_consistency_check(self, event: BaseEvent):
        """处理一致性检查"""
        check_params = event.data
        check_result = await self.checker.check_consistency(**check_params)
        
        if not check_result.is_consistent:
            self.logger.warning(
                "Consistency check failed",
                extra={
                    'event_id': event.event_id,
                    'inconsistencies': check_result.inconsistencies,
                    'details': check_result.details
                }
            )
            
            # 发布检查结果事件
            await self.publish_check_result(event, check_result)

    async def publish_check_result(self, original_event: BaseEvent,
                                 check_result):
        """发布检查结果事件"""
        check_event = BaseEvent(
            event_type='consistency_check_result',
            source='checker',
            data={
                'original_event_id': original_event.event_id,
                'is_consistent': check_result.is_consistent,
                'inconsistencies': check_result.inconsistencies,
                'details': check_result.details,
                'check_duration': check_result.check_duration
            },
            correlation_id=original_event.event_id
        )
        await self.event_bus.publish(check_event)
