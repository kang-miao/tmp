from events.handlers.base_handler import BaseHandler
from events.base_event import BaseEvent
from monitor.performance_monitor import PerformanceMonitor
from monitor.latency_monitor import LatencyMonitor

class MonitorEventHandler(BaseHandler):
    """监控事件处理器"""
    def __init__(self, logger, performance_monitor: PerformanceMonitor,
                 latency_monitor: LatencyMonitor):
        super().__init__(logger)
        self.performance_monitor = performance_monitor
        self.latency_monitor = latency_monitor

    async def handle(self, event: BaseEvent):
        """处理监控事件"""
        if event.event_type == 'performance_metric':
            await self._handle_performance_metric(event)
        elif event.event_type == 'latency_metric':
            await self._handle_latency_metric(event)

    async def _handle_performance_metric(self, event: BaseEvent):
        """处理性能指标事件"""
        metric_name = event.data.get('metric_name')
        value = event.data.get('value')
        labels = event.data.get('labels', {})
        
        if metric_name and value is not None:
            self.performance_monitor.add_metric_point(
                metric_name,
                value,
                labels
            )
            self.logger.debug(
                f"Performance metric recorded: {metric_name}={value}",
                extra={'event_id': event.event_id}
            )

    async def _handle_latency_metric(self, event: BaseEvent):
        """处理延迟指标事件"""
        operation_id = event.data.get('operation_id')
        duration = event.data.get('duration')
        labels = event.data.get('labels', {})
        
        if operation_id and duration is not None:
            self.latency_monitor.record_latency(
                operation_id,
                duration,
                labels
            )
            self.logger.debug(
                f"Latency metric recorded: {operation_id}={duration}ms",
                extra={'event_id': event.event_id}
            )
