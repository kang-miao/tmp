from typing import Dict, Any, List
from pathlib import Path
import json
from datetime import datetime
from docs.base_generator import BaseDocGenerator, DocumentationSection
from benchmarks.base_benchmark import BenchmarkResult

class PerformanceDocGenerator(BaseDocGenerator):
    """性能报告生成器"""
    def __init__(self, logger, output_dir: Path,
                 benchmark_results: List[BenchmarkResult]):
        super().__init__(logger, output_dir)
        self.benchmark_results = benchmark_results

    async def generate(self) -> bool:
        """生成性能报告"""
        try:
            self.clear_sections()
            
            # 添加概述章节
            overview = self._generate_overview()
            self.add_section(overview)
            
            # 添加详细结果章节
            for result in self.benchmark_results:
                result_doc = self._generate_result_doc(result)
                self.add_section(result_doc)
                
            self.logger.info("Performance documentation generated successfully")
            return True
            
        except Exception as e:
            self.logger.error(
                f"Failed to generate performance documentation: {str(e)}",
                exc_info=True
            )
            return False

    async def export(self, format: str = 'markdown') -> Path:
        """导出性能报告"""
        self._ensure_output_dir()
        
        if format == 'markdown':
            return await self._export_markdown()
        elif format == 'html':
            return await self._export_html()
        else:
            raise ValueError(f"Unsupported format: {format}")

    def _generate_overview(self) -> DocumentationSection:
        """生成概述章节"""
        total_tests = len(self.benchmark_results)
        successful_tests = sum(
            1 for r in self.benchmark_results if not r.error
        )
        
        content = f"""
## Performance Test Summary

- Total Tests: {total_tests}
- Successful Tests: {successful_tests}
- Failed Tests: {total_tests - successful_tests}
- Test Period: {self._get_test_period()}

### Key Findings

{self._generate_key_findings()}
"""
        
        return DocumentationSection(
            title="Performance Test Overview",
            content=content,
            metadata={'type': 'overview'}
        )

    def _generate_result_doc(self, result: BenchmarkResult
                            ) -> DocumentationSection:
        """生成测试结果文档"""
        duration = (result.end_time - result.start_time).total_seconds()
        
        content = f"""
### Test Parameters

```json
{json.dumps(result.parameters, indent=2)}
```
</code_block_to_apply_changes_from>

### Test Metrics

```json
{json.dumps(result.metrics, indent=2)}
```

### Test Details

- Duration: {duration:.2f} seconds
- Start Time: {result.start_time.isoformat()}
- End Time: {result.end_time.isoformat()}

{self._format_details(result.details)}

{"### Error\n\n" + result.error if result.error else ""}
"""
        
        return DocumentationSection(
            title=f"Test Result: {result.name}",
            content=content,
            metadata={
                'type': 'test_result',
                'name': result.name,
                'status': 'failed' if result.error else 'success'
            }
        )

    def _get_test_period(self) -> str:
        """获取测试时间段"""
        if not self.benchmark_results:
            return "N/A"
            
        start = min(r.start_time for r in self.benchmark_results)
        end = max(r.end_time for r in self.benchmark_results)
        
        return f"{start.isoformat()} to {end.isoformat()}"

    def _generate_key_findings(self) -> str:
        """生成关键发现"""
        findings = []
        
        for result in self.benchmark_results:
            if not result.error:
                metrics = result.metrics
                if 'throughput' in metrics:
                    findings.append(
                        f"- {result.name}: "
                        f"Achieved {metrics['throughput']:.2f} ops/sec"
                    )
                if 'avg_latency' in metrics:
                    findings.append(
                        f"- {result.name}: "
                        f"Average latency {metrics['avg_latency']:.2f}ms"
                    )
                    
        return "\n".join(findings) if findings else "No key findings available"

    def _format_details(self, details: Dict[str, Any]) -> str:
        """格式化详细信息"""
        if not details:
            return "No additional details available"
            
        formatted = ["### Additional Details\n"]
        
        for key, value in details.items():
            if isinstance(value, dict):
                formatted.append(f"#### {key}\n```json\n{json.dumps(value, indent=2)}\n```\n")
            else:
                formatted.append(f"- **{key}**: {value}\n")
                
        return "\n".join(formatted)

    async def _export_markdown(self) -> Path:
        """导出Markdown格式报告"""
        output_file = self.output_dir / 'performance_report.md'
        
        with output_file.open('w', encoding='utf-8') as f:
            f.write("# Performance Test Report\n\n")
            
            for section in self.sections:
                f.write(self._section_to_markdown(section))
                
        return output_file

    async def _export_html(self) -> Path:
        """导出HTML格式报告"""
        # 实现HTML导出逻辑
        pass
