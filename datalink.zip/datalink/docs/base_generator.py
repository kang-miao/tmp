from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from pathlib import Path
from logging import Logger

@dataclass
class DocumentationSection:
    """文档章节"""
    title: str
    content: str
    subsections: List['DocumentationSection'] = None
    metadata: Dict[str, Any] = None

class BaseDocGenerator(ABC):
    """文档生成器基类"""
    def __init__(self, logger: Logger, output_dir: Path):
        self.logger = logger
        self.output_dir = output_dir
        self.sections: List[DocumentationSection] = []

    @abstractmethod
    async def generate(self) -> bool:
        """生成文档"""
        pass

    @abstractmethod
    async def export(self, format: str) -> Path:
        """导出文档"""
        pass

    def add_section(self, section: DocumentationSection):
        """添加文档章节"""
        self.sections.append(section)

    def clear_sections(self):
        """清空所有章节"""
        self.sections.clear()

    def _ensure_output_dir(self):
        """确保输出目录存在"""
        self.output_dir.mkdir(parents=True, exist_ok=True)
