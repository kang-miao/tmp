from typing import Dict, Any, List
import inspect
import asyncio
from pathlib import Path
from docs.base_generator import BaseDocGenerator, DocumentationSection

class APIDocGenerator(BaseDocGenerator):
    """API文档生成器"""
    def __init__(self, logger, output_dir: Path, api_modules: List[Any]):
        super().__init__(logger, output_dir)
        self.api_modules = api_modules

    async def generate(self) -> bool:
        """生成API文档"""
        try:
            self.clear_sections()
            
            for module in self.api_modules:
                module_doc = self._generate_module_doc(module)
                self.add_section(module_doc)
                
            self.logger.info("API documentation generated successfully")
            return True
            
        except Exception as e:
            self.logger.error(
                f"Failed to generate API documentation: {str(e)}",
                exc_info=True
            )
            return False

    async def export(self, format: str = 'markdown') -> Path:
        """导出API文档"""
        self._ensure_output_dir()
        
        if format == 'markdown':
            return await self._export_markdown()
        else:
            raise ValueError(f"Unsupported format: {format}")

    def _generate_module_doc(self, module: Any) -> DocumentationSection:
        """生成模块文档"""
        module_name = module.__name__.split('.')[-1]
        module_doc = inspect.getdoc(module) or "No module documentation"
        
        subsections = []
        
        # 获取所有类
        for name, obj in inspect.getmembers(module, inspect.isclass):
            if obj.__module__ == module.__name__:
                class_doc = self._generate_class_doc(obj)
                subsections.append(class_doc)
                
        return DocumentationSection(
            title=f"Module: {module_name}",
            content=module_doc,
            subsections=subsections,
            metadata={'type': 'module', 'name': module_name}
        )

    def _generate_class_doc(self, cls: type) -> DocumentationSection:
        """生成类文档"""
        class_doc = inspect.getdoc(cls) or "No class documentation"
        subsections = []
        
        # 获取所有方法
        for name, method in inspect.getmembers(cls, inspect.isfunction):
            if not name.startswith('_'):  # 跳过私有方法
                method_doc = self._generate_method_doc(method)
                subsections.append(method_doc)
                
        return DocumentationSection(
            title=f"Class: {cls.__name__}",
            content=class_doc,
            subsections=subsections,
            metadata={'type': 'class', 'name': cls.__name__}
        )

    def _generate_method_doc(self, method: callable) -> DocumentationSection:
        """生成方法文档"""
        method_doc = inspect.getdoc(method) or "No method documentation"
        signature = inspect.signature(method)
        
        # 格式化参数信息
        params = []
        for name, param in signature.parameters.items():
            if name != 'self':
                annotation = param.annotation.__name__ if param.annotation != inspect.Parameter.empty else 'Any'
                default = f" = {param.default}" if param.default != inspect.Parameter.empty else ""
                params.append(f"{name}: {annotation}{default}")
                
        params_str = ", ".join(params)
        
        return DocumentationSection(
            title=f"Method: {method.__name__}",
            content=f"```python\ndef {method.__name__}({params_str})\n```\n\n{method_doc}",
            metadata={
                'type': 'method',
                'name': method.__name__,
                'signature': str(signature)
            }
        )

    async def _export_markdown(self) -> Path:
        """导出Markdown格式文档"""
        output_file = self.output_dir / 'api_documentation.md'
        
        with output_file.open('w', encoding='utf-8') as f:
            f.write("# API Documentation\n\n")
            
            for section in self.sections:
                f.write(self._section_to_markdown(section))
                
        return output_file

    def _section_to_markdown(self, section: DocumentationSection,
                           level: int = 1) -> str:
        """将章节转换为Markdown格式"""
        md = f"{'#' * level} {section.title}\n\n"
        md += f"{section.content}\n\n"
        
        if section.subsections:
            for subsection in section.subsections:
                md += self._section_to_markdown(subsection, level + 1)
                
        return md
