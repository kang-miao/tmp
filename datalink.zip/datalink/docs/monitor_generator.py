from typing import Dict, Any, List
from pathlib import Path
from datetime import datetime, timedelta
from docs.base_generator import BaseDocGenerator, DocumentationSection
from monitor.metrics.collector import MetricsCollector

class MonitorDocGenerator(BaseDocGenerator):
    """监控报告生成器"""
    def __init__(self, logger, output_dir: Path,
                 metrics_collector: MetricsCollector,
                 time_range: timedelta = timedelta(hours=24)):
        super().__init__(logger, output_dir)
        self.metrics_collector = metrics_collector
        self.time_range = time_range

    async def generate(self) -> bool:
        """生成监控报告"""
        try:
            self.clear_sections()
            
            # 添加系统概览
            overview = self._generate_system_overview()
            self.add_section(overview)
            
            # 添加详细指标
            metrics = self._generate_metrics_section()
            self.add_section(metrics)
            
            # 添加告警摘要
            alerts = self._generate_alerts_section()
            self.add_section(alerts)
            
            self.logger.info("Monitor documentation generated successfully")
            return True
            
        except Exception as e:
            self.logger.error(
                f"Failed to generate monitor documentation: {str(e)}",
                exc_info=True
            )
            return False

    async def export(self, format: str = 'markdown') -> Path:
        """导出监控报告"""
        self._ensure_output_dir()
        
        if format == 'markdown':
            return await self._export_markdown()
        else:
            raise ValueError(f"Unsupported format: {format}")

    def _generate_system_overview(self) -> DocumentationSection:
        """生成系统概览"""
        end_time = datetime.now()
        start_time = end_time - self.time_range
        
        metrics = self.metrics_collector.get_metrics(
            start_time=start_time,
            end_time=end_time
        )
        
        # 计算系统状态统计
        cpu_metrics = [m for m in metrics if m.name == 'system_cpu_usage']
        memory_metrics = [m for m in metrics if m.name == 'system_memory_usage']
        
        content = f"""
## System Status

- Report Period: {start_time.isoformat()} to {end_time.isoformat()}
- Total Metrics Collected: {len(metrics)}

### Resource Usage Summary

#### CPU Usage
- Average: {self._calculate_average([m.value for m in cpu_metrics]):.2f}%
- Peak: {max([m.value for m in cpu_metrics]):.2f}%

#### Memory Usage
- Average: {self._calculate_average([m.value for m in memory_metrics]):.2f}%
- Peak: {max([m.value for m in memory_metrics]):.2f}%
"""
        
        return DocumentationSection(
            title="System Overview",
            content=content,
            metadata={'type': 'overview'}
        )

    def _generate_metrics_section(self) -> DocumentationSection:
        """生成指标章节"""
        end_time = datetime.now()
        start_time = end_time - self.time_range
        
        metrics = self.metrics_collector.get_metrics(
            start_time=start_time,
            end_time=end_time
        )
        
        # 按指标类型分组
        metric_groups = {}
        for metric in metrics:
            if metric.name not in metric_groups:
                metric_groups[metric.name] = []
            metric_groups[metric.name].append(metric)
            
        content = ["## Detailed Metrics\n"]
        
        for name, group in metric_groups.items():
            values = [m.value for m in group]
            content.append(f"### {name}\n")
            content.append(f"- Count: {len(group)}")
            content.append(f"- Average: {self._calculate_average(values):.2f}")
            content.append(f"- Minimum: {min(values):.2f}")
            content.append(f"- Maximum: {max(values):.2f}")
            content.append(f"- Standard Deviation: {self._calculate_stddev(values):.2f}\n")
            
        return DocumentationSection(
            title="Metrics Analysis",
            content="\n".join(content),
            metadata={'type': 'metrics'}
        )

    def _generate_alerts_section(self) -> DocumentationSection:
        """生成告警章节"""
        # 这里需要实现告警统计逻辑
        content = """
## Alert Summary

To be implemented
"""
        
        return DocumentationSection(
            title="Alert Analysis",
            content=content,
            metadata={'type': 'alerts'}
        )

    def _calculate_average(self, values: List[float]) -> float:
        """计算平均值"""
        return sum(values) / len(values) if values else 0

    def _calculate_stddev(self, values: List[float]) -> float:
        """计算标准差"""
        if not values:
            return 0
        avg = self._calculate_average(values)
        variance = sum((x - avg) ** 2 for x in values) / len(values)
        return variance ** 0.5

    async def _export_markdown(self) -> Path:
        """导出Markdown格式报告"""
        output_file = self.output_dir / 'monitor_report.md'
        
        with output_file.open('w', encoding='utf-8') as f:
            f.write("# System Monitoring Report\n\n")
            f.write(f"Generated at: {datetime.now().isoformat()}\n\n")
            
            for section in self.sections:
                f.write(self._section_to_markdown(section))
                
        return output_file
