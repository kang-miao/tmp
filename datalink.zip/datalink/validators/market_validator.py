from typing import Dict, Any, List, Optional
from datetime import datetime
import numpy as np
from validators.base_validator import BaseValidator, ValidationResult

class MarketDataValidator(BaseValidator):
    """市场数据验证器"""
    def __init__(self):
        super().__init__()
        self.validators = {
            'trade': self._validate_trade,
            'orderbook': self._validate_orderbook,
            'kline': self._validate_kline,
            'ticker': self._validate_ticker
        }

    async def validate(self, data: Dict[str, Any]) -> ValidationResult:
        """验证市场数据"""
        data_type = data.get('type')
        if not data_type or data_type not in self.validators:
            return ValidationResult(
                is_valid=False,
                errors=[f"Invalid data type: {data_type}"],
                warnings=[],
                metadata={'data_type': data_type}
            )

        return await self.validators[data_type](data)

    async def _validate_trade(self, data: Dict[str, Any]) -> ValidationResult:
        """验证交易数据"""
        errors = []
        warnings = []
        metadata = {}

        # 检查必需字段
        required_fields = {
            'exchange': str,
            'symbol': str,
            'timestamp': datetime,
            'price': (int, float),
            'volume': (int, float),
            'side': str
        }
        errors.extend(self._check_required_fields(data, required_fields))

        if not errors:
            # 价格检查
            price_error = self._check_numeric_range(
                data['price'], 0, 1e10, 'price'
            )
            if price_error:
                errors.append(price_error)

            # 成交量检查
            volume_error = self._check_numeric_range(
                data['volume'], 0, 1e10, 'volume'
            )
            if volume_error:
                errors.append(volume_error)

            # 交易方向检查
            if data['side'] not in ['buy', 'sell']:
                errors.append(f"Invalid trade side: {data['side']}")

            # 时间戳检查
            timestamp_error = self._check_timestamp(data['timestamp'])
            if timestamp_error:
                warnings.append(timestamp_error)

            # 计算交易金额
            metadata['amount'] = data['price'] * data['volume']

        return ValidationResult(
            is_valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            metadata=metadata
        )

    async def _validate_orderbook(self, data: Dict[str, Any]) -> ValidationResult:
        """验证订单簿数据"""
        errors = []
        warnings = []
        metadata = {
            'bid_levels': 0,
            'ask_levels': 0,
            'spread': None,
            'mid_price': None
        }

        # 检查必需字段
        required_fields = {
            'exchange': str,
            'symbol': str,
            'timestamp': datetime,
            'bids': list,
            'asks': list
        }
        errors.extend(self._check_required_fields(data, required_fields))

        if not errors:
            # 检查订单簿结构
            if not all(len(bid) == 2 for bid in data['bids']):
                errors.append("Invalid bid format")
            if not all(len(ask) == 2 for ask in data['asks']):
                errors.append("Invalid ask format")

            if not errors:
                # 检查价格排序
                bids = sorted(data['bids'], key=lambda x: x[0], reverse=True)
                asks = sorted(data['asks'], key=lambda x: x[0])
                
                if bids != data['bids']:
                    warnings.append("Bids not properly sorted")
                if asks != data['asks']:
                    warnings.append("Asks not properly sorted")

                # 检查买卖盘是否交叉
                if bids and asks and bids[0][0] >= asks[0][0]:
                    errors.append("Crossed orderbook detected")

                # 计算统计信息
                metadata.update({
                    'bid_levels': len(bids),
                    'ask_levels': len(asks),
                    'spread': asks[0][0] - bids[0][0] if bids and asks else None,
                    'mid_price': (asks[0][0] + bids[0][0]) / 2 if bids and asks else None
                })

        return ValidationResult(
            is_valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            metadata=metadata
        )

    async def _validate_kline(self, data: Dict[str, Any]) -> ValidationResult:
        """验证K线数据"""
        errors = []
        warnings = []
        metadata = {}

        # 检查必需字段
        required_fields = {
            'exchange': str,
            'symbol': str,
            'timestamp': datetime,
            'interval': str,
            'open': (int, float),
            'high': (int, float),
            'low': (int, float),
            'close': (int, float),
            'volume': (int, float)
        }
        errors.extend(self._check_required_fields(data, required_fields))

        if not errors:
            # 检查OHLC关系
            if not (data['low'] <= data['open'] <= data['high'] and 
                   data['low'] <= data['close'] <= data['high']):
                errors.append("Invalid OHLC values")

            # 检查数值范围
            for field in ['open', 'high', 'low', 'close']:
                price_error = self._check_numeric_range(
                    data[field], 0, 1e10, field
                )
                if price_error:
                    errors.append(price_error)

            volume_error = self._check_numeric_range(
                data['volume'], 0, 1e10, 'volume'
            )
            if volume_error:
                errors.append(volume_error)

            # 计算统计信息
            metadata.update({
                'price_range': data['high'] - data['low'],
                'price_change': data['close'] - data['open'],
                'price_change_percent': (
                    (data['close'] - data['open']) / data['open'] * 100
                    if data['open'] != 0 else 0
                )
            })

        return ValidationResult(
            is_valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            metadata=metadata
        )
