from abc import ABC, abstractmethod
from typing import Dict, Any, List, Tuple, Optional
from datetime import datetime
import logging
from dataclasses import dataclass

@dataclass
class ValidationResult:
    """验证结果"""
    is_valid: bool
    errors: List[str]
    warnings: List[str]
    metadata: Dict[str, Any]

class BaseValidator(ABC):
    """验证器基类"""
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        self.validation_stats: Dict[str, int] = {
            'total': 0,
            'valid': 0,
            'invalid': 0,
            'warnings': 0
        }

    @abstractmethod
    async def validate(self, data: Dict[str, Any]) -> ValidationResult:
        """验证数据"""
        pass

    def _check_required_fields(self, 
                             data: Dict[str, Any],
                             required_fields: Dict[str, type]) -> List[str]:
        """检查必需字段"""
        errors = []
        for field, field_type in required_fields.items():
            if field not in data:
                errors.append(f"Missing required field: {field}")
            elif not isinstance(data[field], field_type):
                errors.append(
                    f"Invalid type for {field}: expected {field_type.__name__}, "
                    f"got {type(data[field]).__name__}"
                )
        return errors

    def _check_numeric_range(self, 
                           value: float,
                           min_value: float,
                           max_value: float,
                           field_name: str) -> Optional[str]:
        """检查数值范围"""
        if value < min_value or value > max_value:
            return (f"Invalid {field_name}: {value} "
                   f"(should be between {min_value} and {max_value})")
        return None

    def _check_timestamp(self, 
                        timestamp: datetime,
                        max_delay: int = 60,
                        max_future: int = 5) -> Optional[str]:
        """检查时间戳"""
        now = datetime.now()
        delay = (now - timestamp).total_seconds()
        if delay > max_delay:
            return f"Timestamp too old: {delay}s delay"
        if delay < -max_future:
            return f"Future timestamp detected: {-delay}s ahead"
        return None

    def update_stats(self, result: ValidationResult):
        """更新验证统计"""
        self.validation_stats['total'] += 1
        if result.is_valid:
            self.validation_stats['valid'] += 1
        else:
            self.validation_stats['invalid'] += 1
        if result.warnings:
            self.validation_stats['warnings'] += 1
