# main.py

import asyncio
import logging
import signal
import sys
from pathlib import Path
from typing import Optional

from core.data_link import DataLink
from utils.logger import DataLinkLogger

class DataLinkApp:
    """DataLink应用程序主类"""

    def __init__(self, config_path: str = 'config/settings.py'):
        # 初始化日志
        self.logger_manager = DataLinkLogger('config/logging.yaml')
        self.logger = logging.getLogger('app.main')
        
        # 创建DataLink实例
        self.datalink: Optional[DataLink] = None
        self.config_path = config_path
        
        # 信号处理
        self._setup_signal_handlers()

    def _setup_signal_handlers(self) -> None:
        """设置信号处理器"""
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

    def _signal_handler(self, signum: int, frame) -> None:
        """处理进程信号"""
        self.logger.info(f"Received signal {signum}")
        if self.datalink:
            asyncio.create_task(self.shutdown())

    async def startup(self) -> None:
        """启动应用程序"""
        try:
            self.logger.info("Starting DataLink application...")
            
            # 创建DataLink实例
            self.datalink = DataLink(self.config_path)
            
            # 启动DataLink
            await self.datalink.start()
            
            self.logger.info("DataLink application started successfully")
            
        except Exception as e:
            self.logger.error(f"Error starting application: {e}")
            await self.shutdown()
            sys.exit(1)

    async def shutdown(self) -> None:
        """关闭应用程序"""
        if self.datalink:
            self.logger.info("Shutting down DataLink application...")
            await self.datalink.stop()
            self.logger.info("DataLink application shutdown complete")

async def main():
    """主程序入口"""
    # 确保配置目录存在
    Path('config').mkdir(exist_ok=True)
    Path('logs').mkdir(exist_ok=True)
    
    # 创建应用实例
    app = DataLinkApp()
    
    try:
        # 启动应用
        await app.startup()
        
        # 保持运行直到收到退出信号
        while True:
            await asyncio.sleep(1)
            
    except asyncio.CancelledError:
        await app.shutdown()
    except Exception as e:
        logging.error(f"Unexpected error: {e}")
        await app.shutdown()
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())