# processors/validator.py

import logging
from typing import Dict, Any, Optional, List, Union, Callable
from datetime import datetime
import re
import numpy as np
from dataclasses import dataclass

@dataclass
class ValidationRule:
    """验证规则"""
    field: str
    type: type
    required: bool = True
    min_value: Optional[Union[int, float]] = None
    max_value: Optional[Union[int, float]] = None
    pattern: Optional[str] = None
    custom_validator: Optional[Callable] = None
    error_message: Optional[str] = None

class DataValidator:
    """数据验证器

    进行数据字段验证、数据类型检查、业务规则验证等，
    支持自定义验证规则和验证函数。
    """

    def __init__(self, config: Dict[str, Any]):
        """初始化数据验证器

        Args:
            config: 验证配置
        """
        self.logger = logging.getLogger("processor.validator")
        self.config = config

        # 验证规则
        self.rules = self._init_validation_rules()

        # 验证统计
        self.validation_stats = {
            'total': 0,
            'passed': 0,
            'failed': 0,
            'errors': {}
        }

    def _init_validation_rules(self) -> Dict[str, List[ValidationRule]]:
        """初始化验证规则"""
        rules = {}

        # 交易数据规则
        rules['trade'] = [
            ValidationRule(
                field='exchange',
                type=str,
                required=True,
                pattern=r'^[A-Za-z0-9_-]+$'
            ),
            ValidationRule(
                field='symbol',
                type=str,
                required=True,
                pattern=r'^[A-Za-z0-9_/-]+$'
            ),
            ValidationRule(
                field='timestamp',
                type=datetime,
                required=True,
                custom_validator=self._validate_timestamp
            ),
            ValidationRule(
                field='price',
                type=float,
                required=True,
                min_value=0
            ),
            ValidationRule(
                field='volume',
                type=float,
                required=True,
                min_value=0
            ),
            ValidationRule(
                field='side',
                type=str,
                required=True,
                pattern=r'^(buy|sell)$'
            ),
            ValidationRule(
                field='trade_id',
                type=str,
                required=True
            )
        ]

        # 订单簿数据规则
        rules['order_book'] = [
            ValidationRule(
                field='exchange',
                type=str,
                required=True
            ),
            ValidationRule(
                field='symbol',
                type=str,
                required=True
            ),
            ValidationRule(
                field='timestamp',
                type=datetime,
                required=True,
                custom_validator=self._validate_timestamp
            ),
            ValidationRule(
                field='bids',
                type=list,
                required=True,
                custom_validator=self._validate_order_book_level
            ),
            ValidationRule(
                field='asks',
                type=list,
                required=True,
                custom_validator=self._validate_order_book_level
            )
        ]

        # K线数据规则
        rules['kline'] = [
            ValidationRule(
                field='exchange',
                type=str,
                required=True
            ),
            ValidationRule(
                field='symbol',
                type=str,
                required=True
            ),
            ValidationRule(
                field='timestamp',
                type=datetime,
                required=True,
                custom_validator=self._validate_timestamp
            ),
            ValidationRule(
                field='interval',
                type=str,
                required=True,
                pattern=r'^[0-9]+[mhd]$'
            ),
            ValidationRule(
                field='open',
                type=float,
                required=True,
                min_value=0
            ),
            ValidationRule(
                field='high',
                type=float,
                required=True,
                min_value=0,
                custom_validator=self._validate_high_price
            ),
            ValidationRule(
                field='low',
                type=float,
                required=True,
                min_value=0,
                custom_validator=self._validate_low_price
            ),
            ValidationRule(
                field='close',
                type=float,
                required=True,
                min_value=0
            ),
            ValidationRule(
                field='volume',
                type=float,
                required=True,
                min_value=0
            )
        ]

        return rules

    async def validate_trade(self, data: Dict[str, Any]) -> bool:
        """验证交易数据"""
        return await self._validate_data(data, 'trade')

    async def validate_order_book(self, data: Dict[str, Any]) -> bool:
        """验证订单簿数据"""
        return await self._validate_data(data, 'order_book')

    async def validate_kline(self, data: Dict[str, Any]) -> bool:
        """验证K线数据"""
        return await self._validate_data(data, 'kline')

    async def _validate_data(self, data: Dict[str, Any], data_type: str) -> bool:
        """验证数据

        Args:
            data: 待验证的数据
            data_type: 数据类型

        Returns:
            bool: 验证是否通过
        """
        try:
            self.validation_stats['total'] += 1

            # 获取验证规则
            rules = self.rules.get(data_type)
            if not rules:
                self.logger.warning(f"No validation rules found for {data_type}")
                return False

            # 验证每个字段
            for rule in rules:
                if not await self._validate_field(data, rule):
                    self._record_validation_failure(data_type, rule.field)
                    return False

            # 执行业务规则验证
            if not await self._validate_business_rules(data, data_type):
                self._record_validation_failure(data_type, 'business_rules')
                return False

            self.validation_stats['passed'] += 1
            return True

        except Exception as e:
            self.logger.error(f"Error validating {data_type} data: {e}")
            self._record_validation_failure(data_type, 'validation_error')
            return False

    async def _validate_field(self, data: Dict[str, Any], 
                            rule: ValidationRule) -> bool:
        """验证字段"""
        try:
            # 检查必需字段
            if rule.required and rule.field not in data:
                return False

            value = data.get(rule.field)
            if value is None:
                return not rule.required

            # 类型检查
            if not isinstance(value, rule.type):
                return False

            # 数值范围检查
            if isinstance(value, (int, float)):
                if rule.min_value is not None and value < rule.min_value:
                    return False
                if rule.max_value is not None and value > rule.max_value:
                    return False

            # 模式匹配
            if rule.pattern and isinstance(value, str):
                if not re.match(rule.pattern, value):
                    return False

            # 自定义验证
            if rule.custom_validator:
                return await rule.custom_validator(value, data)

            return True

        except Exception as e:
            self.logger.error(f"Error validating field {rule.field}: {e}")
            return False

    async def _validate_business_rules(self, data: Dict[str, Any], 
                                     data_type: str) -> bool:
        """验证业务规则"""
        try:
            if data_type == 'order_book':
                # 验证买卖价格关系
                best_bid = data['bids'][0][0] if data['bids'] else 0
                best_ask = data['asks'][0][0] if data['asks'] else float('inf')
                if best_bid >= best_ask:
                    return False

            elif data_type == 'kline':
                # 验证OHLC关系
                if not (data['low'] <= data['open'] <= data['high'] and
                       data['low'] <= data['close'] <= data['high']):
                    return False

            return True

        except Exception as e:
            self.logger.error(f"Error validating business rules: {e}")
            return False

    async def _validate_timestamp(self, timestamp: datetime, 
                                data: Dict[str, Any]) -> bool:
        """验证时间戳"""
        try:
            now = datetime.now()
            # 不允许未来时间戳，且不能早于1天
            return (timestamp <= now and 
                   timestamp >= now - self.config.get('max_delay', 86400))
        except Exception:
            return False

    async def _validate_order_book_level(self, levels: List, 
                                       data: Dict[str, Any]) -> bool:
        """验证订单簿价格档位"""
        try:
            if not levels:
                return False

            for level in levels:
                if (not isinstance(level, (list, tuple)) or
                    len(level) != 2 or
                    not isinstance(level[0], (int, float)) or
                    not isinstance(level[1], (int, float)) or
                    level[0] <= 0 or
                    level[1] <= 0):
                    return False

            return True

        except Exception:
            return False

    async def _validate_high_price(self, high: float, 
                                 data: Dict[str, Any]) -> bool:
        """验证最高价"""
        return high >= data['open'] and high >= data['close']

    async def _validate_low_price(self, low: float, 
                                data: Dict[str, Any]) -> bool:
        """验证最低价"""
        return low <= data['open'] and low <= data['close']

    def _record_validation_failure(self, data_type: str, field: str) -> None:
        """记录验证失败"""
        self.validation_stats['failed'] += 1
        if data_type not in self.validation_stats['errors']:
            self.validation_stats['errors'][data_type] = {}
        if field not in self.validation_stats['errors'][data_type]:
            self.validation_stats['errors'][data_type][field] = 0
        self.validation_stats['errors'][data_type][field] += 1

    async def get_validation_stats(self) -> Dict[str, Any]:
        """获取验证统计"""
        return {
            'total': self.validation_stats['total'],
            'passed': self.validation_stats['passed'],
            'failed': self.validation_stats['failed'],
            'pass_rate': (self.validation_stats['passed'] / 
                         self.validation_stats['total'] 
                         if self.validation_stats['total'] > 0 else 0),
            'errors': self.validation_stats['errors']
        }