# processors/data_processor.py

import asyncio
import logging
from typing import Dict, Any, List, Optional, Callable
from datetime import datetime
import json

from core.market_data import MarketType, DataType
from utils.metrics import MetricsManager
from processors.validator import DataValidator
from processors.cleaner import DataCleaner
from processors.transformer import DataTransformer

class ProcessingRule:
    """数据处理规则"""
    def __init__(self, name: str, 
                 validator: Optional[Callable] = None,
                 cleaner: Optional[Callable] = None,
                 transformer: Optional[Callable] = None):
        self.name = name
        self.validator = validator
        self.cleaner = cleaner
        self.transformer = transformer

class DataProcessor:
    """数据处理器

    负责数据的验证、清洗、转换和分发，
    支持自定义处理规则和处理流水线。
    """

    def __init__(self, metrics: MetricsManager, config: Dict[str, Any]):
        """初始化数据处理器

        Args:
            metrics: 指标管理器
            config: 处理器配置
        """
        self.logger = logging.getLogger("processor.data")
        self.metrics = metrics
        self.config = config

        # 初始化组件
        self.validator = DataValidator(config.get('validation', {}))
        self.cleaner = DataCleaner(config.get('cleaning', {}))
        self.transformer = DataTransformer(config.get('transformation', {}))

        # 处理规则
        self.rules: Dict[str, ProcessingRule] = {}
        self._init_rules()

        # 处理队列
        self.queue = asyncio.Queue()
        self.max_queue_size = config.get('max_queue_size', 10000)

        # 回调函数
        self.callbacks: Dict[str, Callable] = {}

        # 运行标志
        self.is_running = False
        self._process_task: Optional[asyncio.Task] = None

    def _init_rules(self) -> None:
        """初始化处理规则"""
        # 交易数据规则
        self.rules['trade'] = ProcessingRule(
            name='trade',
            validator=self.validator.validate_trade,
            cleaner=self.cleaner.clean_trade,
            transformer=self.transformer.transform_trade
        )

        # 订单簿数据规则
        self.rules['order_book'] = ProcessingRule(
            name='order_book',
            validator=self.validator.validate_order_book,
            cleaner=self.cleaner.clean_order_book,
            transformer=self.transformer.transform_order_book
        )

        # K线数据规则
        self.rules['kline'] = ProcessingRule(
            name='kline',
            validator=self.validator.validate_kline,
            cleaner=self.cleaner.clean_kline,
            transformer=self.transformer.transform_kline
        )

    async def start(self) -> None:
        """启动处理器"""
        self.is_running = True
        self._process_task = asyncio.create_task(self._process_loop())
        self.logger.info("Data processor started")

    async def stop(self) -> None:
        """停止处理器"""
        self.is_running = False
        if self._process_task:
            self._process_task.cancel()
            try:
                await self._process_task
            except asyncio.CancelledError:
                pass
        self.logger.info("Data processor stopped")

    def register_callback(self, data_type: str, callback: Callable) -> None:
        """注册回调函数"""
        self.callbacks[data_type] = callback

    async def process(self, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """处理数据

        Args:
            data: 待处理的数据

        Returns:
            Optional[Dict[str, Any]]: 处理后的数据
        """
        try:
            if self.queue.qsize() >= self.max_queue_size:
                raise ValueError("Process queue is full")

            await self.queue.put(data)
            return data

        except Exception as e:
            self.logger.error(f"Error processing data: {e}")
            await self.metrics.performance.record_error_rate(
                'data_processing',
                1,
                1
            )
            return None

    async def _process_loop(self) -> None:
        """处理循环"""
        while self.is_running:
            try:
                # 获取数据
                data = await self.queue.get()

                # 获取处理规则
                rule = self.rules.get(data.get('type'))
                if not rule:
                    self.logger.warning(f"No rule found for data type: {data.get('type')}")
                    continue

                # 处理数据
                processed_data = await self._apply_rule(rule, data)
                if processed_data:
                    # 调用回调函数
                    if data['type'] in self.callbacks:
                        await self.callbacks[data['type']](processed_data)

                # 更新指标
                await self._update_metrics(data['type'], bool(processed_data))

                self.queue.task_done()

            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Error in process loop: {e}")
                await asyncio.sleep(1)

    async def _apply_rule(self, rule: ProcessingRule, 
                         data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """应用处理规则"""
        try:
            # 验证数据
            if rule.validator:
                if not await rule.validator(data):
                    self.logger.warning(f"Data validation failed: {data}")
                    return None

            # 清洗数据
            if rule.cleaner:
                data = await rule.cleaner(data)

            # 转换数据
            if rule.transformer:
                data = await rule.transformer(data)

            return data

        except Exception as e:
            self.logger.error(f"Error applying rule {rule.name}: {e}")
            return None

    async def _update_metrics(self, data_type: str, success: bool) -> None:
        """更新处理指标"""
        try:
            # 记录处理延迟
            await self.metrics.performance.record_latency(
                f'process_{data_type}',
                self.queue.qsize()
            )

            # 记录处理结果
            await self.metrics.performance.record_throughput(
                f'process_{data_type}',
                1 if success else 0
            )

        except Exception as e:
            self.logger.error(f"Error updating metrics: {e}")

    async def get_queue_stats(self) -> Dict[str, Any]:
        """获取队列统计信息"""
        return {
            'queue_size': self.queue.qsize(),
            'queue_full_percent': (self.queue.qsize() / self.max_queue_size) * 100
        }

    async def flush(self) -> None:
        """清空处理队列"""
        while not self.queue.empty():
            await self.queue.get()
            self.queue.task_done()