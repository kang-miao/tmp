# processors/cleaner.py

import logging
from typing import Dict, Any, List, Optional, Union, Callable
from datetime import datetime
import numpy as np
from dataclasses import dataclass

@dataclass
class CleaningRule:
    """清洗规则"""
    field: str
    method: str  # 'remove', 'fill', 'clip', 'normalize'
    params: Optional[Dict[str, Any]] = None
    custom_cleaner: Optional[Callable] = None

class DataCleaner:
    """数据清洗器
    
    负责数据的清洗、标准化和预处理，包括：
    - 异常值检测和处理
    - 缺失值填充
    - 数据标准化
    - 数据格式统一
    """

    def __init__(self, config: Dict[str, Any]):
        """初始化数据清洗器
        
        Args:
            config: 清洗配置
        """
        self.logger = logging.getLogger("processor.cleaner")
        self.config = config

        # 清洗规则
        self.rules = self._init_cleaning_rules()

        # 清洗统计
        self.cleaning_stats = {
            'processed': 0,
            'cleaned': 0,
            'anomalies': {},
            'missing_values': {}
        }

        # 数据缓存，用于计算移动统计量
        self.data_cache: Dict[str, List[Dict[str, Any]]] = {}
        self.cache_size = config.get('cache_size', 1000)

    def _init_cleaning_rules(self) -> Dict[str, List[CleaningRule]]:
        """初始化清洗规则"""
        rules = {}

        # 交易数据清洗规则
        rules['trade'] = [
            CleaningRule(
                field='price',
                method='clip',
                params={
                    'std_multiplier': 3,  # 3倍标准差
                    'window_size': 100    # 移动窗口大小
                }
            ),
            CleaningRule(
                field='volume',
                method='clip',
                params={
                    'std_multiplier': 3,
                    'window_size': 100
                }
            ),
            CleaningRule(
                field='timestamp',
                method='fill',
                params={
                    'method': 'forward'
                }
            )
        ]

        # 订单簿清洗规则
        rules['order_book'] = [
            CleaningRule(
                field='bids',
                method='normalize',
                custom_cleaner=self._clean_order_book_levels
            ),
            CleaningRule(
                field='asks',
                method='normalize',
                custom_cleaner=self._clean_order_book_levels
            ),
            CleaningRule(
                field='timestamp',
                method='fill',
                params={
                    'method': 'forward'
                }
            )
        ]

        # K线数据清洗规则
        rules['kline'] = [
            CleaningRule(
                field='volume',
                method='fill',
                params={
                    'method': 'zero'
                }
            ),
            CleaningRule(
                field='open',
                method='clip',
                params={
                    'std_multiplier': 3,
                    'window_size': 100
                }
            ),
            CleaningRule(
                field='high',
                method='clip',
                params={
                    'std_multiplier': 3,
                    'window_size': 100
                }
            ),
            CleaningRule(
                field='low',
                method='clip',
                params={
                    'std_multiplier': 3,
                    'window_size': 100
                }
            ),
            CleaningRule(
                field='close',
                method='clip',
                params={
                    'std_multiplier': 3,
                    'window_size': 100
                }
            )
        ]

        return rules

    async def clean_trade(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """清洗交易数据"""
        return await self._clean_data(data, 'trade')

    async def clean_order_book(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """清洗订单簿数据"""
        return await self._clean_data(data, 'order_book')

    async def clean_kline(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """清洗K线数据"""
        return await self._clean_data(data, 'kline')

    async def _clean_data(self, data: Dict[str, Any], 
                         data_type: str) -> Dict[str, Any]:
        """清洗数据

        Args:
            data: 待清洗的数据
            data_type: 数据类型

        Returns:
            Dict[str, Any]: 清洗后的数据
        """
        try:
            self.cleaning_stats['processed'] += 1

            # 更新数据缓存
            await self._update_cache(data, data_type)

            # 获取清洗规则
            rules = self.rules.get(data_type, [])

            # 应用清洗规则
            cleaned_data = data.copy()
            for rule in rules:
                cleaned_data = await self._apply_cleaning_rule(
                    cleaned_data, rule, data_type
                )

            self.cleaning_stats['cleaned'] += 1
            return cleaned_data

        except Exception as e:
            self.logger.error(f"Error cleaning {data_type} data: {e}")
            return data

    async def _update_cache(self, data: Dict[str, Any], data_type: str) -> None:
        """更新数据缓存"""
        cache_key = f"{data_type}_{data['symbol']}"
        if cache_key not in self.data_cache:
            self.data_cache[cache_key] = []

        self.data_cache[cache_key].append(data)
        if len(self.data_cache[cache_key]) > self.cache_size:
            self.data_cache[cache_key].pop(0)

    async def _apply_cleaning_rule(self, data: Dict[str, Any], 
                                 rule: CleaningRule,
                                 data_type: str) -> Dict[str, Any]:
        """应用清洗规则"""
        try:
            if rule.field not in data:
                return data

            value = data[rule.field]
            if value is None:
                if rule.method == 'fill':
                    data[rule.field] = await self._fill_missing_value(
                        rule.field, data, data_type
                    )
                return data

            # 使用自定义清洗函数
            if rule.custom_cleaner:
                data[rule.field] = await rule.custom_cleaner(value, data)
                return data

            # 应用标准清洗方法
            if rule.method == 'clip':
                data[rule.field] = await self._clip_outliers(
                    value, rule.field, data, data_type, rule.params
                )
            elif rule.method == 'normalize':
                data[rule.field] = await self._normalize_value(
                    value, rule.field, data, data_type, rule.params
                )

            return data

        except Exception as e:
            self.logger.error(f"Error applying cleaning rule: {e}")
            return data

    async def _fill_missing_value(self, field: str, data: Dict[str, Any],
                                data_type: str) -> Any:
        """填充缺失值"""
        try:
            cache_key = f"{data_type}_{data['symbol']}"
            cache = self.data_cache.get(cache_key, [])

            if not cache:
                return 0 if field in ['volume', 'amount'] else None

            # 获取最近的非空值
            for item in reversed(cache):
                if field in item and item[field] is not None:
                    return item[field]

            return 0 if field in ['volume', 'amount'] else None

        except Exception as e:
            self.logger.error(f"Error filling missing value: {e}")
            return None

    async def _clip_outliers(self, value: Union[int, float], field: str,
                           data: Dict[str, Any], data_type: str,
                           params: Optional[Dict[str, Any]] = None) -> Union[int, float]:
        """处理异常值"""
        try:
            cache_key = f"{data_type}_{data['symbol']}"
            cache = self.data_cache.get(cache_key, [])

            if not cache:
                return value

            # 获取历史数据
            history = [item[field] for item in cache if field in item 
                      and item[field] is not None]

            if not history:
                return value

            # 计算统计量
            mean = np.mean(history)
            std = np.std(history)
            std_multiplier = params.get('std_multiplier', 3)

            # 计算上下限
            lower_bound = mean - std_multiplier * std
            upper_bound = mean + std_multiplier * std

            # 记录异常值
            if value < lower_bound or value > upper_bound:
                self._record_anomaly(data_type, field)

            # 截断异常值
            return min(max(value, lower_bound), upper_bound)

        except Exception as e:
            self.logger.error(f"Error clipping outliers: {e}")
            return value

    async def _normalize_value(self, value: Any, field: str,
                             data: Dict[str, Any], data_type: str,
                             params: Optional[Dict[str, Any]] = None) -> Any:
        """标准化数据"""
        try:
            if isinstance(value, (list, tuple)):
                return [await self._normalize_value(v, field, data, data_type, params)
                       for v in value]
            elif isinstance(value, (int, float)):
                return float(value)
            elif isinstance(value, str):
                return value.strip()
            return value

        except Exception as e:
            self.logger.error(f"Error normalizing value: {e}")
            return value

    async def _clean_order_book_levels(self, levels: List, 
                                     data: Dict[str, Any]) -> List:
        """清洗订单簿价格档位"""
        try:
            cleaned_levels = []
            for level in levels:
                if len(level) >= 2:
                    price = float(level[0])
                    volume = float(level[1])
                    if price > 0 and volume > 0:
                        cleaned_levels.append([price, volume])
            return sorted(cleaned_levels, 
                        key=lambda x: x[0], 
                        reverse=isinstance(levels, list))

        except Exception as e:
            self.logger.error(f"Error cleaning order book levels: {e}")
            return levels

    def _record_anomaly(self, data_type: str, field: str) -> None:
        """记录异常值"""
        if data_type not in self.cleaning_stats['anomalies']:
            self.cleaning_stats['anomalies'][data_type] = {}
        if field not in self.cleaning_stats['anomalies'][data_type]:
            self.cleaning_stats['anomalies'][data_type][field] = 0
        self.cleaning_stats['anomalies'][data_type][field] += 1

    async def get_cleaning_stats(self) -> Dict[str, Any]:
        """获取清洗统计"""
        return {
            'processed': self.cleaning_stats['processed'],
            'cleaned': self.cleaning_stats['cleaned'],
            'clean_rate': (self.cleaning_stats['cleaned'] / 
                         self.cleaning_stats['processed'] 
                         if self.cleaning_stats['processed'] > 0 else 0),
            'anomalies': self.cleaning_stats['anomalies'],
            'missing_values': self.cleaning_stats['missing_values']
        }