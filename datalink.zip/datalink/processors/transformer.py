# processors/transformer.py

import logging
from typing import Dict, Any, List, Optional, Union, Callable
from datetime import datetime, timedelta
import numpy as np
from dataclasses import dataclass
import pandas as pd

@dataclass
class TransformRule:
    """转换规则"""
    name: str
    method: str  # 'aggregate', 'feature', 'format', 'custom'
    input_fields: List[str]
    output_field: str
    params: Optional[Dict[str, Any]] = None
    transform_func: Optional[Callable] = None

class DataTransformer:
    """数据转换器
    
    负责数据的转换和特征计算，包括：
    - 数据格式转换
    - 特征工程
    - 数据聚合
    - 指标计算
    """

    def __init__(self, config: Dict[str, Any]):
        """初始化数据转换器
        
        Args:
            config: 转换配置
        """
        self.logger = logging.getLogger("processor.transformer")
        self.config = config

        # 转换规则
        self.rules = self._init_transform_rules()

        # 数据缓存
        self.data_cache: Dict[str, List[Dict[str, Any]]] = {}
        self.cache_size = config.get('cache_size', 1000)

        # 转换统计
        self.transform_stats = {
            'processed': 0,
            'transformed': 0,
            'features': {},
            'errors': {}
        }

    def _init_transform_rules(self) -> Dict[str, List[TransformRule]]:
        """初始化转换规则"""
        rules = {}

        # 交易数据转换规则
        rules['trade'] = [
            TransformRule(
                name='vwap',
                method='feature',
                input_fields=['price', 'volume'],
                output_field='vwap',
                transform_func=self._calculate_vwap
            ),
            TransformRule(
                name='trade_size',
                method='feature',
                input_fields=['price', 'volume'],
                output_field='trade_size',
                transform_func=lambda p, v: p * v
            ),
            TransformRule(
                name='trade_side_indicator',
                method='feature',
                input_fields=['side'],
                output_field='side_indicator',
                transform_func=lambda s: 1 if s == 'buy' else -1
            )
        ]

        # 订单簿转换规则
        rules['order_book'] = [
            TransformRule(
                name='mid_price',
                method='feature',
                input_fields=['bids', 'asks'],
                output_field='mid_price',
                transform_func=self._calculate_mid_price
            ),
            TransformRule(
                name='spread',
                method='feature',
                input_fields=['bids', 'asks'],
                output_field='spread',
                transform_func=self._calculate_spread
            ),
            TransformRule(
                name='depth_imbalance',
                method='feature',
                input_fields=['bids', 'asks'],
                output_field='depth_imbalance',
                transform_func=self._calculate_depth_imbalance
            ),
            TransformRule(
                name='book_pressure',
                method='feature',
                input_fields=['bids', 'asks'],
                output_field='book_pressure',
                transform_func=self._calculate_book_pressure
            )
        ]

        # K线数据转换规则
        rules['kline'] = [
            TransformRule(
                name='returns',
                method='feature',
                input_fields=['open', 'close'],
                output_field='returns',
                transform_func=lambda o, c: (c - o) / o
            ),
            TransformRule(
                name='amplitude',
                method='feature',
                input_fields=['high', 'low', 'open'],
                output_field='amplitude',
                transform_func=lambda h, l, o: (h - l) / o
            ),
            TransformRule(
                name='typical_price',
                method='feature',
                input_fields=['high', 'low', 'close'],
                output_field='typical_price',
                transform_func=lambda h, l, c: (h + l + c) / 3
            )
        ]

        return rules

    async def transform_trade(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """转换交易数据"""
        return await self._transform_data(data, 'trade')

    async def transform_order_book(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """转换订单簿数据"""
        return await self._transform_data(data, 'order_book')

    async def transform_kline(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """转换K线数据"""
        return await self._transform_data(data, 'kline')

    async def _transform_data(self, data: Dict[str, Any], 
                            data_type: str) -> Dict[str, Any]:
        """转换数据

        Args:
            data: 待转换的数据
            data_type: 数据类型

        Returns:
            Dict[str, Any]: 转换后的数据
        """
        try:
            self.transform_stats['processed'] += 1

            # 更新数据缓存
            await self._update_cache(data, data_type)

            # 获取转换规则
            rules = self.rules.get(data_type, [])

            # 应用转换规则
            transformed_data = data.copy()
            for rule in rules:
                try:
                    transformed_data = await self._apply_transform_rule(
                        transformed_data, rule, data_type
                    )
                except Exception as e:
                    self._record_transform_error(data_type, rule.name, str(e))

            self.transform_stats['transformed'] += 1
            return transformed_data

        except Exception as e:
            self.logger.error(f"Error transforming {data_type} data: {e}")
            return data

    async def _update_cache(self, data: Dict[str, Any], data_type: str) -> None:
        """更新数据缓存"""
        cache_key = f"{data_type}_{data['symbol']}"
        if cache_key not in self.data_cache:
            self.data_cache[cache_key] = []

        self.data_cache[cache_key].append(data)
        if len(self.data_cache[cache_key]) > self.cache_size:
            self.data_cache[cache_key].pop(0)

    async def _apply_transform_rule(self, data: Dict[str, Any],
                                  rule: TransformRule,
                                  data_type: str) -> Dict[str, Any]:
        """应用转换规则"""
        try:
            # 检查输入字段是否存在
            if not all(field in data for field in rule.input_fields):
                return data

            # 获取输入值
            input_values = [data[field] for field in rule.input_fields]

            # 执行转换
            if rule.transform_func:
                result = await rule.transform_func(*input_values)
            else:
                result = None

            # 保存结果
            if result is not None:
                data[rule.output_field] = result
                self._record_feature(data_type, rule.name)

            return data

        except Exception as e:
            self.logger.error(f"Error applying transform rule {rule.name}: {e}")
            return data

    async def _calculate_vwap(self, price: float, volume: float) -> float:
        """计算成交量加权平均价格"""
        return price * volume / volume if volume > 0 else price

    async def _calculate_mid_price(self, bids: List, asks: List) -> float:
        """计算中间价格"""
        if not bids or not asks:
            return 0
        return (bids[0][0] + asks[0][0]) / 2

    async def _calculate_spread(self, bids: List, asks: List) -> float:
        """计算买卖价差"""
        if not bids or not asks:
            return 0
        return asks[0][0] - bids[0][0]

    async def _calculate_depth_imbalance(self, bids: List, asks: List) -> float:
        """计算深度不平衡"""
        try:
            bid_volume = sum(level[1] for level in bids)
            ask_volume = sum(level[1] for level in asks)
            total_volume = bid_volume + ask_volume
            return (bid_volume - ask_volume) / total_volume if total_volume > 0 else 0
        except Exception:
            return 0

    async def _calculate_book_pressure(self, bids: List, asks: List) -> float:
        """计算订单簿压力"""
        try:
            # 计算买卖双方的累计量
            bid_pressure = sum(level[0] * level[1] for level in bids)
            ask_pressure = sum(level[0] * level[1] for level in asks)
            total_pressure = bid_pressure + ask_pressure
            return (bid_pressure - ask_pressure) / total_pressure if total_pressure > 0 else 0
        except Exception:
            return 0

    def _record_feature(self, data_type: str, feature_name: str) -> None:
        """记录特征计算"""
        if data_type not in self.transform_stats['features']:
            self.transform_stats['features'][data_type] = {}
        if feature_name not in self.transform_stats['features'][data_type]:
            self.transform_stats['features'][data_type][feature_name] = 0
        self.transform_stats['features'][data_type][feature_name] += 1

    def _record_transform_error(self, data_type: str, rule_name: str,
                              error: str) -> None:
        """记录转换错误"""
        if data_type not in self.transform_stats['errors']:
            self.transform_stats['errors'][data_type] = {}
        if rule_name not in self.transform_stats['errors'][data_type]:
            self.transform_stats['errors'][data_type][rule_name] = []
        self.transform_stats['errors'][data_type][rule_name].append(error)

    async def get_transform_stats(self) -> Dict[str, Any]:
        """获取转换统计"""
        return {
            'processed': self.transform_stats['processed'],
            'transformed': self.transform_stats['transformed'],
            'transform_rate': (self.transform_stats['transformed'] / 
                             self.transform_stats['processed'] 
                             if self.transform_stats['processed'] > 0 else 0),
            'features': self.transform_stats['features'],
            'errors': self.transform_stats['errors']
        }

    async def calculate_technical_indicators(self, data: Dict[str, Any],
                                          indicators: List[str]) -> Dict[str, Any]:
        """计算技术指标"""
        try:
            cache_key = f"kline_{data['symbol']}"
            cache = self.data_cache.get(cache_key, [])
            if not cache:
                return data

            # 创建DataFrame
            df = pd.DataFrame(cache)
            
            # 计算技术指标
            result = data.copy()
            for indicator in indicators:
                if indicator == 'sma':
                    result['sma'] = df['close'].rolling(window=20).mean().iloc[-1]
                elif indicator == 'ema':
                    result['ema'] = df['close'].ewm(span=20).mean().iloc[-1]
                elif indicator == 'rsi':
                    changes = df['close'].diff()
                    gains = changes.where(changes > 0, 0)
                    losses = -changes.where(changes < 0, 0)
                    avg_gain = gains.rolling(window=14).mean()
                    avg_loss = losses.rolling(window=14).mean()
                    rs = avg_gain / avg_loss
                    result['rsi'] = 100 - (100 / (1 + rs.iloc[-1]))
                elif indicator == 'bollinger_bands':
                    sma = df['close'].rolling(window=20).mean()
                    std = df['close'].rolling(window=20).std()
                    result['bb_upper'] = sma + (std * 2)
                    result['bb_lower'] = sma - (std * 2)
                    result['bb_middle'] = sma

            return result

        except Exception as e:
            self.logger.error(f"Error calculating technical indicators: {e}")
            return data