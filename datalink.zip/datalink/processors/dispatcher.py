# processors/dispatcher.py

import logging
import asyncio
from typing import Dict, Any, List, Optional, Set, Callable
from datetime import datetime
import json

from utils.metrics import MetricsManager

class DataDispatcher:
    """数据分发器
    
    负责将处理后的数据分发到不同的存储系统和消费者，
    支持：
    - 多目标分发
    - 分发规则配置
    - 失败重试
    - 分发监控
    """

    def __init__(self, storage_connectors: Dict[str, Any], 
                 metrics: MetricsManager, config: Dict[str, Any]):
        """初始化数据分发器
        
        Args:
            storage_connectors: 存储连接器字典
            metrics: 指标管理器
            config: 分发配置
        """
        self.logger = logging.getLogger("processor.dispatcher")
        self.storage = storage_connectors
        self.metrics = metrics
        self.config = config

        # 分发规则
        self.dispatch_rules = self._init_dispatch_rules()

        # 分发队列
        self.queues: Dict[str, asyncio.Queue] = {}
        self.max_queue_size = config.get('max_queue_size', 10000)

        # 重试配置
        self.max_retries = config.get('max_retries', 3)
        self.retry_delay = config.get('retry_delay', 1)

        # 分发统计
        self.dispatch_stats = {
            'total': 0,
            'success': 0,
            'failed': 0,
            'retries': 0
        }

        # 运行标志
        self.is_running = False
        self._dispatch_tasks: Set[asyncio.Task] = set()

    def _init_dispatch_rules(self) -> Dict[str, List[str]]:
        """初始化分发规则"""
        return {
            'trade': ['keydb', 'redpanda', 'tdengine', 'minio'],
            'order_book': ['keydb', 'redpanda', 'minio'],
            'kline': ['tdengine', 'minio']
        }

    async def start(self) -> None:
        """启动分发器"""
        self.is_running = True
        self.queues = {
            target: asyncio.Queue(maxsize=self.max_queue_size)
            for target in set().union(*self.dispatch_rules.values())
        }
        
        # 为每个存储目标创建分发任务
        for target in self.queues.keys():
            task = asyncio.create_task(self._dispatch_loop(target))
            self._dispatch_tasks.add(task)
            task.add_done_callback(self._dispatch_tasks.discard)

        self.logger.info("Data dispatcher started")

    async def stop(self) -> None:
        """停止分发器"""
        self.is_running = False
        
        # 等待所有队列处理完成
        await asyncio.gather(*(queue.join() for queue in self.queues.values()))
        
        # 取消所有分发任务
        for task in self._dispatch_tasks:
            task.cancel()
        
        await asyncio.gather(*self._dispatch_tasks, return_exceptions=True)
        self.logger.info("Data dispatcher stopped")

    async def dispatch(self, data: Dict[str, Any]) -> bool:
        """分发数据
        
        Args:
            data: 待分发的数据

        Returns:
            bool: 分发是否成功
        """
        try:
            self.dispatch_stats['total'] += 1
            data_type = data.get('type')
            
            if data_type not in self.dispatch_rules:
                self.logger.warning(f"No dispatch rule for data type: {data_type}")
                return False

            # 获取目标存储系统
            targets = self.dispatch_rules[data_type]
            
            # 将数据放入相应的队列
            for target in targets:
                if target not in self.queues:
                    continue
                    
                queue = self.queues[target]
                if queue.full():
                    self.logger.warning(f"Queue for {target} is full")
                    continue
                
                await queue.put(data)

            self.dispatch_stats['success'] += 1
            return True

        except Exception as e:
            self.logger.error(f"Error dispatching data: {e}")
            self.dispatch_stats['failed'] += 1
            return False

    async def _dispatch_loop(self, target: str) -> None:
        """分发循环
        
        Args:
            target: 目标存储系统
        """
        while self.is_running:
            try:
                # 获取数据
                data = await self.queues[target].get()
                
                # 分发数据
                success = await self._dispatch_to_target(target, data)
                
                if success:
                    self.queues[target].task_done()
                else:
                    # 重新放入队列重试
                    await self.queues[target].put(data)
                
                # 更新指标
                await self._update_metrics(target, success)

            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Error in dispatch loop for {target}: {e}")
                await asyncio.sleep(1)

    async def _dispatch_to_target(self, target: str, 
                                data: Dict[str, Any]) -> bool:
        """分发数据到目标存储
        
        Args:
            target: 目标存储系统
            data: 待分发的数据

        Returns:
            bool: 分发是否成功
        """
        for attempt in range(self.max_retries):
            try:
                if target == 'keydb':
                    await self._dispatch_to_keydb(data)
                elif target == 'redpanda':
                    await self._dispatch_to_redpanda(data)
                elif target == 'tdengine':
                    await self._dispatch_to_tdengine(data)
                elif target == 'minio':
                    await self._dispatch_to_minio(data)
                return True

            except Exception as e:
                self.logger.error(
                    f"Error dispatching to {target} (attempt {attempt+1}): {e}"
                )
                self.dispatch_stats['retries'] += 1
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(self.retry_delay * (attempt + 1))
                else:
                    self.dispatch_stats['failed'] += 1
                    return False

    async def _dispatch_to_keydb(self, data: Dict[str, Any]) -> None:
        """分发到KeyDB"""
        if data['type'] == 'order_book':
            await self.storage['keydb'].update_order_book(
                data['exchange'],
                data['symbol'],
                data['bids'],
                data['asks'],
                data['timestamp']
            )
        else:
            key = f"{data['type']}:{data['exchange']}:{data['symbol']}"
            await self.storage['keydb'].set(key, json.dumps(data))

    async def _dispatch_to_redpanda(self, data: Dict[str, Any]) -> None:
        """分发到Redpanda"""
        topic = f"{data['type']}.raw"
        await self.storage['redpanda'].publish_message(
            topic,
            data,
            key=f"{data['exchange']}_{data['symbol']}"
        )

    async def _dispatch_to_tdengine(self, data: Dict[str, Any]) -> None:
        """分发到TDengine"""
        if data['type'] == 'trade':
            await self.storage['tdengine'].insert_trade(data)
        elif data['type'] == 'kline':
            await self.storage['tdengine'].insert_kline(data)

    async def _dispatch_to_minio(self, data: Dict[str, Any]) -> None:
        """分发到MinIO"""
        date = data['timestamp'].date()
        key = (f"{data['type']}/{data['exchange']}/{data['symbol']}/"
               f"{date.strftime('%Y/%m/%d')}/{data['timestamp'].hour}.json")
        
        await self.storage['minio'].put_object(
            'market-data',
            key,
            json.dumps(data)
        )

    async def _update_metrics(self, target: str, success: bool) -> None:
        """更新分发指标"""
        try:
            # 记录分发延迟
            await self.metrics.performance.record_latency(
                f'dispatch_{target}',
                self.queues[target].qsize()
            )

            # 记录分发结果
            await self.metrics.performance.record_throughput(
                f'dispatch_{target}',
                1 if success else 0
            )

        except Exception as e:
            self.logger.error(f"Error updating metrics: {e}")

    async def get_dispatch_stats(self) -> Dict[str, Any]:
        """获取分发统计"""
        return {
            'total': self.dispatch_stats['total'],
            'success': self.dispatch_stats['success'],
            'failed': self.dispatch_stats['failed'],
            'retries': self.dispatch_stats['retries'],
            'success_rate': (self.dispatch_stats['success'] / 
                           self.dispatch_stats['total'] 
                           if self.dispatch_stats['total'] > 0 else 0),
            'queue_sizes': {
                target: queue.qsize()
                for target, queue in self.queues.items()
            }
        }