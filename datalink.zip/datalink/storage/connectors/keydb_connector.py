# storage/keydb_connector.py

import logging
from typing import Dict, Any, Optional, List, Union
import json
from datetime import datetime
import yaml
import asyncio
import redis
from redis.exceptions import ConnectionError, RedisError
import os

class KeyDBConnector:
    """KeyDB连接器增强版
    
    支持完整的Schema定义和验证，包括：
    - 数据结构验证
    - 字段类型检查
    - 缓存策略管理
    - 性能监控
    """

    def __init__(self, config: Dict[str, Any]):
        """初始化KeyDB连接器
        
        Args:
            config: 连接配置
        """
        self.logger = logging.getLogger("storage.keydb")
        self.config = config

        # 加载Schema定义
        schema_path = os.path.join(
            os.path.dirname(__file__), 
            '../schemas/keydb/schema.yaml'
        )
        self.schema = self._load_schema(schema_path)

        # 初始化Redis连接池
        self.pool = redis.ConnectionPool(
            host=config.get('host', 'localhost'),
            port=config.get('port', 6379),
            db=config.get('db', 0),
            password=config.get('password'),
            decode_responses=True,
            max_connections=config.get('max_connections', 100),
            socket_timeout=config.get('socket_timeout', 5),
            socket_connect_timeout=config.get('connect_timeout', 2),
            socket_keepalive=True,
            retry_on_timeout=True
        )

        self.client = redis.Redis(connection_pool=self.pool)
        
        # 监控指标
        self.metrics = {
            'operations': 0,
            'errors': 0,
            'cache_hits': 0,
            'cache_misses': 0
        }

    def _load_schema(self, schema_path: str) -> Dict[str, Any]:
        """加载Schema定义
        
        Args:
            schema_path: Schema文件路径
            
        Returns:
            Dict[str, Any]: Schema定义
        """
        try:
            with open(schema_path, 'r') as f:
                return yaml.safe_load(f)
        except Exception as e:
            self.logger.error(f"Error loading schema: {e}")
            raise

    async def set_market_ticker(self, market_type: str, exchange: str,
                              symbol: str, data: Dict[str, Any]) -> bool:
        """设置市场行情数据
        
        Args:
            market_type: 市场类型
            exchange: 交易所
            symbol: 交易对
            data: 行情数据
            
        Returns:
            bool: 是否成功
        """
        try:
            # 验证Schema
            if not self._validate_schema('market_ticker', data):
                return False

            # 生成key
            key = f"ticker:{market_type}:{exchange}:{symbol}"

            # 设置数据
            pipeline = self.client.pipeline()
            pipeline.hmset(key, data)
            pipeline.expire(key, self.schema['structures']['market_ticker']['ttl'])
            pipeline.execute()

            self.metrics['operations'] += 1
            return True

        except RedisError as e:
            self.logger.error(f"Error setting market ticker: {e}")
            self.metrics['errors'] += 1
            return False

    async def set_order_book(self, market_type: str, exchange: str,
                           symbol: str, bids: List[List[float]],
                           asks: List[List[float]]) -> bool:
        """设置订单簿数据
        
        Args:
            market_type: 市场类型
            exchange: 交易所
            symbol: 交易对
            bids: 买单列表
            asks: 卖单列表
            
        Returns:
            bool: 是否成功
        """
        try:
            data = {
                'bids': json.dumps(bids),
                'asks': json.dumps(asks),
                'timestamp': int(datetime.now().timestamp() * 1000)
            }

            # 验证Schema
            if not self._validate_schema('order_book', data):
                return False

            # 生成key
            key = f"orderbook:{market_type}:{exchange}:{symbol}"

            # 设置数据
            pipeline = self.client.pipeline()
            pipeline.hmset(key, data)
            pipeline.expire(key, self.schema['structures']['order_book']['ttl'])
            pipeline.execute()

            self.metrics['operations'] += 1
            return True

        except RedisError as e:
            self.logger.error(f"Error setting order book: {e}")
            self.metrics['errors'] += 1
            return False

    async def add_recent_trade(self, market_type: str, exchange: str,
                             symbol: str, trade: Dict[str, Any]) -> bool:
        """添加最新成交记录
        
        Args:
            market_type: 市场类型
            exchange: 交易所
            symbol: 交易对
            trade: 成交数据
            
        Returns:
            bool: 是否成功
        """
        try:
            # 验证Schema
            if not self._validate_schema('recent_trades', trade):
                return False

            key = f"trades:{market_type}:{exchange}:{symbol}"
            max_len = self.schema['structures']['recent_trades']['max_length']

            # 添加数据
            pipeline = self.client.pipeline()
            pipeline.lpush(key, json.dumps(trade))
            pipeline.ltrim(key, 0, max_len - 1)
            pipeline.expire(key, self.schema['structures']['recent_trades']['ttl'])
            pipeline.execute()

            self.metrics['operations'] += 1
            return True

        except RedisError as e:
            self.logger.error(f"Error adding recent trade: {e}")
            self.metrics['errors'] += 1
            return False

    async def get_market_ticker(self, market_type: str, exchange: str,
                              symbol: str) -> Optional[Dict[str, Any]]:
        """获取市场行情数据
        
        Args:
            market_type: 市场类型
            exchange: 交易所
            symbol: 交易对
            
        Returns:
            Optional[Dict[str, Any]]: 行情数据
        """
        try:
            key = f"ticker:{market_type}:{exchange}:{symbol}"
            data = self.client.hgetall(key)

            if data:
                self.metrics['cache_hits'] += 1
                return {k: float(v) if k != 'timestamp' else int(v)
                       for k, v in data.items()}
            else:
                self.metrics['cache_misses'] += 1
                return None

        except RedisError as e:
            self.logger.error(f"Error getting market ticker: {e}")
            self.metrics['errors'] += 1
            return None

    def _validate_schema(self, struct_name: str, data: Dict[str, Any]) -> bool:
        """验证数据结构是否符合Schema
        
        Args:
            struct_name: 结构名称
            data: 待验证数据
            
        Returns:
            bool: 是否符合Schema
        """
        try:
            struct_def = self.schema['structures'].get(struct_name)
            if not struct_def:
                return False

            # 检查必要字段
            for field, field_type in struct_def['fields'].items():
                if field not in data:
                    return False

                # 类型检查
                if field_type == 'float':
                    if not isinstance(data[field], (int, float)):
                        return False
                elif field_type == 'int':
                    if not isinstance(data[field], int):
                        return False
                elif field_type == 'string':
                    if not isinstance(data[field], str):
                        return False

            return True

        except Exception as e:
            self.logger.error(f"Schema validation error: {e}")
            return False

    async def get_metrics(self) -> Dict[str, Any]:
        """获取监控指标"""
        try:
            info = self.client.info()
            return {
                'operations': self.metrics['operations'],
                'errors': self.metrics['errors'],
                'cache_hits': self.metrics['cache_hits'],
                'cache_misses': self.metrics['cache_misses'],
                'connected_clients': info.get('connected_clients', 0),
                'used_memory': info.get('used_memory', 0),
                'used_memory_peak': info.get('used_memory_peak', 0),
                'total_connections_received': info.get('total_connections_received', 0),
                'instantaneous_ops_per_sec': info.get('instantaneous_ops_per_sec', 0)
            }
        except Exception as e:
            self.logger.error(f"Error getting metrics: {e}")
            return {}

    async def cleanup(self) -> None:
        """清理过期数据"""
        try:
            self.client.close()
            self.pool.disconnect()
        except Exception as e:
            self.logger.error(f"Error during cleanup: {e}")