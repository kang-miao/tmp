# storage/minio_connector.py

import logging
import json
import io
import gzip
from typing import Dict, Any, Optional, List, Union, BinaryIO
from datetime import datetime, timedelta
import pandas as pd
from minio import Minio
from minio.error import S3Error
from minio.commonconfig import GOVERNANCE, Tags
from minio.retention import Retention
import pyarrow as pa
import pyarrow.parquet as pq

class MinIOConnector:
    """MinIO连接器
    
    负责管理与MinIO的连接和数据归档，支持：
    - 数据文件的存储和检索
    - 数据的压缩和解压
    - 数据格式转换
    - 数据保留策略
    """

    def __init__(self, config: Dict[str, Any]):
        """初始化MinIO连接器
        
        Args:
            config: 包含连接参数的配置字典
        """
        self.logger = logging.getLogger("storage.minio")
        self.config = config
        
        # 连接配置
        self.endpoint = config.get('endpoint', 'localhost:9000')
        self.access_key = config.get('access_key', 'minioadmin')
        self.secret_key = config.get('secret_key', 'minioadmin')
        self.secure = config.get('secure', False)
        
        # 桶配置
        self.buckets = {
            'market_data': {
                'name': config.get('market_data_bucket', 'market-data'),
                'retention_days': 365  # 市场数据保留1年
            },
            'backup': {
                'name': config.get('backup_bucket', 'backup'),
                'retention_days': 90   # 备份数据保留90天
            }
        }
        
        # 初始化客户端
        self.client = Minio(
            endpoint=self.endpoint,
            access_key=self.access_key,
            secret_key=self.secret_key,
            secure=self.secure
        )
        
        # 数据格式配置
        self.COMPRESSION_LEVEL = 6  # gzip压缩级别
        self.DEFAULT_CHUNK_SIZE = 100000  # 分块大小

    async def check_connection(self) -> bool:
        """检查连接状态
        
        Returns:
            bool: 连接是否正常
        """
        try:
            self.client.list_buckets()
            return True
        except Exception as e:
            self.logger.error(f"MinIO connection error: {e}")
            return False

    async def init_buckets(self) -> bool:
        """初始化存储桶
        
        Returns:
            bool: 初始化是否成功
        """
        try:
            for bucket_config in self.buckets.values():
                bucket_name = bucket_config['name']
                if not self.client.bucket_exists(bucket_name):
                    self.client.make_bucket(bucket_name)
                    
                    # 设置数据保留策略
                    retention = Retention(
                        mode=GOVERNANCE,
                        validity=timedelta(days=bucket_config['retention_days'])
                    )
                    self.client.set_bucket_retention(bucket_name, retention)
                    
                    self.logger.info(f"Created bucket: {bucket_name}")
            return True
        except Exception as e:
            self.logger.error(f"Error initializing buckets: {e}")
            return False

    def _generate_object_path(self, market_type: str, exchange: str,
                            symbol: str, date: datetime,
                            data_type: str) -> str:
        """生成对象存储路径
        
        Args:
            market_type: 市场类型
            exchange: 交易所
            symbol: 交易对
            date: 数据日期
            data_type: 数据类型
            
        Returns:
            str: 对象存储路径
        """
        return (f"{market_type}/{exchange}/{symbol}/"
                f"{date.strftime('%Y/%m/%d')}/{data_type}.parquet")

    async def save_dataframe(self, df: pd.DataFrame, market_type: str,
                           exchange: str, symbol: str, data_type: str,
                           date: Optional[datetime] = None) -> bool:
        """保存DataFrame数据
        
        Args:
            df: 待保存的DataFrame
            market_type: 市场类型
            exchange: 交易所
            symbol: 交易对
            data_type: 数据类型
            date: 数据日期
            
        Returns:
            bool: 保存是否成功
        """
        try:
            if date is None:
                date = datetime.now()

            # 转换为pyarrow表格
            table = pa.Table.from_pandas(df)
            
            # 创建内存buffer
            buffer = io.BytesIO()
            
            # 写入Parquet格式
            pq.write_table(
                table,
                buffer,
                compression='snappy',
                version='2.6',
                flavor='spark'  # 兼容Spark
            )
            
            # 重置buffer位置
            buffer.seek(0)
            
            # 生成对象路径
            object_path = self._generate_object_path(
                market_type, exchange, symbol, date, data_type
            )
            
            # 设置标签
            tags = Tags(for_object=True)
            tags["market_type"] = market_type
            tags["exchange"] = exchange
            tags["symbol"] = symbol
            tags["data_type"] = data_type
            
            # 上传到MinIO
            self.client.put_object(
                bucket_name=self.buckets['market_data']['name'],
                object_name=object_path,
                data=buffer,
                length=buffer.getbuffer().nbytes,
                content_type='application/parquet',
                tags=tags
            )
            
            self.logger.info(f"Saved DataFrame to: {object_path}")
            return True
        except Exception as e:
            self.logger.error(f"Error saving DataFrame: {e}")
            return False

    async def load_dataframe(self, market_type: str, exchange: str,
                           symbol: str, data_type: str,
                           date: datetime) -> Optional[pd.DataFrame]:
        """加载DataFrame数据
        
        Args:
            market_type: 市场类型
            exchange: 交易所
            symbol: 交易对
            data_type: 数据类型
            date: 数据日期
            
        Returns:
            Optional[pd.DataFrame]: 加载的DataFrame
        """
        try:
            object_path = self._generate_object_path(
                market_type, exchange, symbol, date, data_type
            )
            
            # 检查对象是否存在
            try:
                self.client.stat_object(
                    self.buckets['market_data']['name'],
                    object_path
                )
            except S3Error:
                return None
            
            # 创建内存buffer
            buffer = io.BytesIO()
            
            # 从MinIO下载数据
            self.client.get_object(
                self.buckets['market_data']['name'],
                object_path
            ).read_into(buffer)
            
            # 重置buffer位置
            buffer.seek(0)
            
            # 读取Parquet格式
            table = pq.read_table(buffer)
            
            return table.to_pandas()
        except Exception as e:
            self.logger.error(f"Error loading DataFrame: {e}")
            return None

    async def create_backup(self, market_type: str, exchange: str,
                          symbol: str, date: datetime) -> bool:
        """创建数据备份
        
        Args:
            market_type: 市场类型
            exchange: 交易所
            symbol: 交易对
            date: 数据日期
            
        Returns:
            bool: 备份是否成功
        """
        try:
            source_bucket = self.buckets['market_data']['name']
            backup_bucket = self.buckets['backup']['name']
            
            # 构建源路径前缀
            prefix = f"{market_type}/{exchange}/{symbol}/{date.strftime('%Y/%m/%d')}/"
            
            # 列出所有匹配的对象
            objects = self.client.list_objects(source_bucket, prefix=prefix, recursive=True)
            
            for obj in objects:
                # 构建备份路径
                backup_path = f"backup_{date.strftime('%Y%m%d')}/{obj.object_name}"
                
                # 复制对象到备份桶
                self.client.copy_object(
                    backup_bucket,
                    backup_path,
                    f"{source_bucket}/{obj.object_name}"
                )
            
            self.logger.info(f"Created backup for: {prefix}")
            return True
        except Exception as e:
            self.logger.error(f"Error creating backup: {e}")
            return False

    async def get_storage_stats(self, market_type: Optional[str] = None,
                              exchange: Optional[str] = None) -> Dict[str, Any]:
        """获取存储统计信息
        
        Args:
            market_type: 市场类型（可选）
            exchange: 交易所（可选）
            
        Returns:
            Dict[str, Any]: 存储统计信息
        """
        try:
            stats = {
                'total_objects': 0,
                'total_size': 0,
                'by_market_type': {},
                'by_exchange': {}
            }
            
            # 构建前缀
            prefix = ""
            if market_type:
                prefix = f"{market_type}/"
                if exchange:
                    prefix = f"{market_type}/{exchange}/"
            
            # 统计对象
            objects = self.client.list_objects(
                self.buckets['market_data']['name'],
                prefix=prefix,
                recursive=True
            )
            
            for obj in objects:
                stats['total_objects'] += 1
                stats['total_size'] += obj.size
                
                # 按市场类型统计
                obj_market_type = obj.object_name.split('/')[0]
                if obj_market_type not in stats['by_market_type']:
                    stats['by_market_type'][obj_market_type] = {
                        'objects': 0,
                        'size': 0
                    }
                stats['by_market_type'][obj_market_type]['objects'] += 1
                stats['by_market_type'][obj_market_type]['size'] += obj.size
                
                # 按交易所统计
                if len(obj.object_name.split('/')) > 1:
                    obj_exchange = obj.object_name.split('/')[1]
                    if obj_exchange not in stats['by_exchange']:
                        stats['by_exchange'][obj_exchange] = {
                            'objects': 0,
                            'size': 0
                        }
                    stats['by_exchange'][obj_exchange]['objects'] += 1
                    stats['by_exchange'][obj_exchange]['size'] += obj.size
            
            return stats
        except Exception as e:
            self.logger.error(f"Error getting storage stats: {e}")
            return {}

    async def cleanup_expired_data(self) -> int:
        """清理过期数据
        
        Returns:
            int: 清理的对象数量
        """
        try:
            count = 0
            for bucket_config in self.buckets.values():
                bucket_name = bucket_config['name']
                retention_days = bucket_config['retention_days']
                expiry_date = datetime.now() - timedelta(days=retention_days)
                
                # 列出所有对象
                objects = self.client.list_objects(bucket_name, recursive=True)
                
                for obj in objects:
                    # 检查对象时间戳
                    if obj.last_modified.replace(tzinfo=None) < expiry_date:
                        self.client.remove_object(bucket_name, obj.object_name)
                        count += 1
            
            self.logger.info(f"Cleaned up {count} expired objects")
            return count
        except Exception as e:
            self.logger.error(f"Error cleaning up expired data: {e}")
            return 0