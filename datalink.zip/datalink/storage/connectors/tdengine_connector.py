# storage/tdengine_connector.py

import logging
from typing import Dict, Any, Optional, List, Union, Tuple
from datetime import datetime, timedelta
import taos
import pandas as pd
import numpy as np
import os
from decimal import Decimal
import json
import asyncio

class TDengineConnector:
    """TDengine连接器增强版
    
    支持完整的时序数据存储和查询功能，包括：
    - 超级表管理
    - 数据写入和查询
    - 数据降采样
    - 数据保留策略
    """

    def __init__(self, config: Dict[str, Any]):
        """初始化TDengine连接器
        
        Args:
            config: 连接配置
        """
        self.logger = logging.getLogger("storage.tdengine")
        self.config = config

        # 连接配置
        self.host = config.get('host', 'localhost')
        self.port = config.get('port', 6041)
        self.user = config.get('user', 'root')
        self.password = config.get('password', 'taosdata')
        self.database = config.get('database', 'market_data')

        # 连接对象
        self.conn = None
        self.tables_initialized = False

        # 加载SQL定义
        self.sql_definitions = self._load_sql_definitions()

        # 监控指标
        self.metrics = {
            'writes_total': 0,
            'writes_failed': 0,
            'queries_total': 0,
            'queries_failed': 0,
            'rows_written': 0,
            'rows_read': 0
        }

        # 写入缓冲
        self.write_buffer = []
        self.buffer_size = config.get('buffer_size', 1000)
        self.flush_interval = config.get('flush_interval', 1)  # 秒
        self._last_flush = datetime.now()

    def _load_sql_definitions(self) -> Dict[str, str]:
        """加载SQL定义文件"""
        try:
            sql_path = os.path.join(
                os.path.dirname(__file__),
                '../schemas/tdengine/tables.sql'
            )
            with open(sql_path, 'r') as f:
                content = f.read()
            
            # 分割SQL语句
            statements = {}
            current_statement = []
            current_name = None
            
            for line in content.split('\n'):
                if line.strip().startswith('--'):
                    if current_statement and current_name:
                        statements[current_name] = '\n'.join(current_statement)
                    current_name = line.strip('- ').lower()
                    current_statement = []
                elif line.strip():
                    current_statement.append(line)
            
            if current_statement and current_name:
                statements[current_name] = '\n'.join(current_statement)
                
            return statements
            
        except Exception as e:
            self.logger.error(f"Error loading SQL definitions: {e}")
            return {}

    async def initialize(self) -> bool:
        """初始化连接和表结构"""
        try:
            if not self.conn:
                self.conn = taos.connect(
                    host=self.host,
                    port=self.port,
                    user=self.user,
                    password=self.password,
                    database=self.database
                )

            if not self.tables_initialized:
                await self._initialize_tables()
                self.tables_initialized = True

            # 启动刷新缓冲的任务
            asyncio.create_task(self._flush_buffer_loop())
            return True

        except Exception as e:
            self.logger.error(f"Initialization error: {e}")
            return False

    async def _initialize_tables(self) -> None:
        """初始化表结构"""
        try:
            # 创建数据库
            self.conn.execute(self.sql_definitions['create_database'])
            
            # 创建超级表
            tables = [
                'trade_data',
                'kline_data',
                'order_book_data',
                'market_metrics',
                'data_quality_metrics',
                'system_metrics'
            ]
            
            for table in tables:
                if table in self.sql_definitions:
                    self.conn.execute(self.sql_definitions[table])

        except Exception as e:
            self.logger.error(f"Error initializing tables: {e}")
            raise

    async def insert_trade(self, trade_data: Dict[str, Any]) -> bool:
        """插入交易数据
        
        Args:
            trade_data: 交易数据
            
        Returns:
            bool: 是否成功
        """
        try:
            sql = """
                INSERT INTO trade_data_%(market)s_%(exchange)s_%(symbol)s 
                USING trade_data 
                TAGS ('%(market_type)s', '%(exchange)s', '%(symbol)s')
                VALUES (%(ts)d, %(price)f, %(volume)f, %(amount)f, 
                        '%(side)s', '%(trade_id)s', %(maker)d, NOW());
            """
            
            # 添加到写入缓冲
            self.write_buffer.append({
                'sql': sql,
                'data': trade_data
            })
            
            # 检查是否需要刷新缓冲
            if len(self.write_buffer) >= self.buffer_size:
                await self._flush_buffer()
            
            self.metrics['writes_total'] += 1
            self.metrics['rows_written'] += 1
            return True

        except Exception as e:
            self.logger.error(f"Error inserting trade data: {e}")
            self.metrics['writes_failed'] += 1
            return False

    async def insert_kline(self, kline_data: Dict[str, Any]) -> bool:
        """插入K线数据"""
        try:
            sql = """
                INSERT INTO kline_data_%(market)s_%(exchange)s_%(symbol)s 
                USING kline_data 
                TAGS ('%(market_type)s', '%(exchange)s', '%(symbol)s', '%(interval)s')
                VALUES (%(ts)d, %(open)f, %(high)f, %(low)f, %(close)f,
                        %(volume)f, %(amount)f, %(trade_count)d, NOW());
            """
            
            self.write_buffer.append({
                'sql': sql,
                'data': kline_data
            })
            
            if len(self.write_buffer) >= self.buffer_size:
                await self._flush_buffer()
            
            self.metrics['writes_total'] += 1
            self.metrics['rows_written'] += 1
            return True

        except Exception as e:
            self.logger.error(f"Error inserting kline data: {e}")
            self.metrics['writes_failed'] += 1
            return False

    async def _flush_buffer(self) -> None:
        """刷新写入缓冲"""
        if not self.write_buffer:
            return

        try:
            # 构建批量插入SQL
            batch_sql = []
            for item in self.write_buffer:
                sql = item['sql'] % item['data']
                batch_sql.append(sql)

            # 执行批量插入
            self.conn.execute(';'.join(batch_sql))
            
            # 清空缓冲
            self.write_buffer = []
            self._last_flush = datetime.now()

        except Exception as e:
            self.logger.error(f"Error flushing buffer: {e}")
            self.metrics['writes_failed'] += len(self.write_buffer)

    async def _flush_buffer_loop(self) -> None:
        """定期刷新缓冲的循环"""
        while True:
            try:
                if (datetime.now() - self._last_flush).seconds >= self.flush_interval:
                    await self._flush_buffer()
                await asyncio.sleep(0.1)
            except Exception as e:
                self.logger.error(f"Error in flush buffer loop: {e}")
                await asyncio.sleep(1)

    async def query_trades(self, market_type: str, exchange: str, symbol: str,
                         start_time: datetime, end_time: Optional[datetime] = None,
                         limit: int = 1000) -> pd.DataFrame:
        """查询交易数据"""
        try:
            self.metrics['queries_total'] += 1
            
            end_time = end_time or datetime.now()
            table_name = f"trade_data_{market_type}_{exchange}_{symbol}"
            
            sql = f"""
                SELECT * FROM {table_name}
                WHERE ts >= {int(start_time.timestamp() * 1000)}
                AND ts <= {int(end_time.timestamp() * 1000)}
                LIMIT {limit};
            """
            
            result = self.conn.query(sql)
            df = pd.DataFrame(result.fetch_all(), columns=result.fields)
            
            self.metrics['rows_read'] += len(df)
            return df

        except Exception as e:
            self.logger.error(f"Error querying trades: {e}")
            self.metrics['queries_failed'] += 1
            return pd.DataFrame()

    async def get_metrics(self) -> Dict[str, Any]:
        """获取监控指标"""
        try:
            # 获取数据库统计
            stats_sql = "SHOW DATABASES"
            result = self.conn.query(stats_sql)
            db_stats = pd.DataFrame(result.fetch_all(), columns=result.fields)
            
            return {
                'writes_total': self.metrics['writes_total'],
                'writes_failed': self.metrics['writes_failed'],
                'queries_total': self.metrics['queries_total'],
                'queries_failed': self.metrics['queries_failed'],
                'rows_written': self.metrics['rows_written'],
                'rows_read': self.metrics['rows_read'],
                'buffer_size': len(self.write_buffer),
                'database_stats': db_stats.to_dict('records')
            }

        except Exception as e:
            self.logger.error(f"Error getting metrics: {e}")
            return {}

    async def cleanup(self) -> None:
        """清理资源"""
        try:
            # 刷新剩余的缓冲数据
            await self._flush_buffer()
            
            # 关闭连接
            if self.conn:
                self.conn.close()

        except Exception as e:
            self.logger.error(f"Error during cleanup: {e}")