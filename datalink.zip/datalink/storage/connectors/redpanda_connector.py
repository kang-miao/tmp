# storage/redpanda_connector.py

import json
import logging
from typing import Dict, Any, Optional, List, Callable, Union
from datetime import datetime
import asyncio
from confluent_kafka import Producer, Consumer, KafkaError, KafkaException
from confluent_kafka.admin import AdminClient, NewTopic

class RedpandaConnector:
    """Redpanda连接器
    
    负责管理与Redpanda的连接和数据传输，支持：
    - 消息发布
    - 消息订阅
    - Topic管理
    - 消费者组管理
    """

    def __init__(self, config: Dict[str, Any]):
        """初始化Redpanda连接器
        
        Args:
            config: 包含连接参数的配置字典
        """
        self.logger = logging.getLogger("storage.redpanda")
        self.config = config
        
        # 基本配置
        self.bootstrap_servers = config.get('bootstrap_servers', 'localhost:9092')
        self.client_id = config.get('client_id', 'datalink')
        
        # 生产者配置
        self.producer_config = {
            'bootstrap.servers': self.bootstrap_servers,
            'client.id': f'{self.client_id}-producer',
            'acks': config.get('acks', 'all'),
            'retries': config.get('retries', 3),
            'compression.type': config.get('compression_type', 'lz4'),
            'linger.ms': config.get('linger_ms', 5),
            'batch.size': config.get('batch_size', 16384)
        }
        
        # 消费者配置
        self.consumer_config = {
            'bootstrap.servers': self.bootstrap_servers,
            'group.id': config.get('group_id', f'{self.client_id}-group'),
            'auto.offset.reset': config.get('auto_offset_reset', 'latest'),
            'enable.auto.commit': config.get('enable_auto_commit', True),
            'max.poll.interval.ms': config.get('max_poll_interval_ms', 300000)
        }
        
        # Topic配置
        self.topic_config = {
            'num_partitions': config.get('num_partitions', 3),
            'replication_factor': config.get('replication_factor', 1)
        }
        
        # 初始化组件
        self.producer: Optional[Producer] = None
        self.consumers: Dict[str, Consumer] = {}
        self.admin_client = AdminClient({'bootstrap.servers': self.bootstrap_servers})
        
        # Topic前缀
        self.TOPIC_PREFIX = {
            'trade': 'trades',
            'order_book': 'orderbooks',
            'kline': 'klines',
            'metrics': 'metrics'
        }

    def _create_producer(self) -> None:
        """创建生产者"""
        if not self.producer:
            self.producer = Producer(self.producer_config)
            self.logger.info("Created Redpanda producer")

    def _get_consumer(self, group_id: str) -> Consumer:
        """获取或创建消费者
        
        Args:
            group_id: 消费者组ID
            
        Returns:
            Consumer: Kafka消费者实例
        """
        if group_id not in self.consumers:
            config = self.consumer_config.copy()
            config['group.id'] = group_id
            self.consumers[group_id] = Consumer(config)
            self.logger.info(f"Created Redpanda consumer for group {group_id}")
        return self.consumers[group_id]

    async def check_connection(self) -> bool:
        """检查连接状态
        
        Returns:
            bool: 连接是否正常
        """
        try:
            cluster_metadata = self.admin_client.list_topics(timeout=5)
            return bool(cluster_metadata)
        except KafkaException as e:
            self.logger.error(f"Redpanda connection error: {e}")
            return False

    def _generate_topic(self, topic_type: str, *args: str) -> str:
        """生成Topic名称
        
        Args:
            topic_type: Topic类型
            *args: Topic名称组成部分
            
        Returns:
            str: 生成的Topic名称
        """
        prefix = self.TOPIC_PREFIX.get(topic_type, '')
        return f"{prefix}.{'.'.join(args)}"

    async def create_topics(self, topics: List[str]) -> bool:
        """创建Topics
        
        Args:
            topics: Topic列表
            
        Returns:
            bool: 创建是否成功
        """
        try:
            new_topics = [
                NewTopic(
                    topic,
                    num_partitions=self.topic_config['num_partitions'],
                    replication_factor=self.topic_config['replication_factor']
                )
                for topic in topics
            ]
            
            result = self.admin_client.create_topics(new_topics)
            for topic, future in result.items():
                try:
                    future.result()
                    self.logger.info(f"Created topic: {topic}")
                except Exception as e:
                    if "already exists" not in str(e):
                        self.logger.error(f"Failed to create topic {topic}: {e}")
                        return False
            return True
        except Exception as e:
            self.logger.error(f"Error creating topics: {e}")
            return False

    def publish_message(self, topic: str, message: Union[str, Dict],
                       key: Optional[str] = None) -> bool:
        """发布消息
        
        Args:
            topic: 目标Topic
            message: 消息内容
            key: 消息键（可选）
            
        Returns:
            bool: 发布是否成功
        """
        try:
            if not self.producer:
                self._create_producer()

            if isinstance(message, dict):
                message = json.dumps(message)

            def delivery_callback(err, msg):
                if err:
                    self.logger.error(f'Message delivery failed: {err}')
                else:
                    self.logger.debug(f'Message delivered to {msg.topic()}')

            self.producer.produce(
                topic,
                value=message.encode('utf-8'),
                key=key.encode('utf-8') if key else None,
                callback=delivery_callback
            )
            self.producer.poll(0)
            return True
        except Exception as e:
            self.logger.error(f"Error publishing message: {e}")
            return False

    async def consume_messages(self, topics: List[str], group_id: str,
                             callback: Callable[[str, Any], None],
                             batch_size: int = 100,
                             timeout: float = 1.0) -> None:
        """消费消息
        
        Args:
            topics: Topic列表
            group_id: 消费者组ID
            callback: 消息处理回调函数
            batch_size: 批处理大小
            timeout: 轮询超时时间
        """
        consumer = self._get_consumer(group_id)
        consumer.subscribe(topics)
        
        try:
            while True:
                messages = consumer.consume(batch_size, timeout)
                if not messages:
                    continue

                for msg in messages:
                    if msg.error():
                        if msg.error().code() == KafkaError._PARTITION_EOF:
                            continue
                        else:
                            self.logger.error(f"Consumer error: {msg.error()}")
                            break
                    else:
                        try:
                            value = json.loads(msg.value().decode('utf-8'))
                            callback(msg.topic(), value)
                        except Exception as e:
                            self.logger.error(f"Error processing message: {e}")

                await asyncio.sleep(0)  # 让出控制权
        except Exception as e:
            self.logger.error(f"Error in message consumption: {e}")
        finally:
            self._close_consumer(group_id)

    def _close_consumer(self, group_id: str) -> None:
        """关闭指定的消费者
        
        Args:
            group_id: 消费者组ID
        """
        if group_id in self.consumers:
            try:
                self.consumers[group_id].close()
                del self.consumers[group_id]
                self.logger.info(f"Closed consumer for group {group_id}")
            except Exception as e:
                self.logger.error(f"Error closing consumer: {e}")

    def flush(self) -> None:
        """刷新生产者缓冲区"""
        if self.producer:
            self.producer.flush()

    def close(self) -> None:
        """关闭所有连接"""
        try:
            # 关闭所有消费者
            for group_id in list(self.consumers.keys()):
                self._close_consumer(group_id)
            
            # 关闭生产者
            if self.producer:
                self.producer.flush()
                self.producer.close()
                self.producer = None
                
            self.logger.info("Closed all Redpanda connections")
        except Exception as e:
            self.logger.error(f"Error closing Redpanda connections: {e}")

    async def get_topic_metrics(self, topic: str) -> Dict[str, Any]:
        """获取Topic的监控指标
        
        Args:
            topic: Topic名称
            
        Returns:
            Dict[str, Any]: Topic统计信息
        """
        try:
            cluster_metadata = self.admin_client.list_topics(topic)
            topic_metadata = cluster_metadata.topics[topic]
            
            return {
                'topic': topic,
                'partition_count': len(topic_metadata.partitions),
                'replicas': [p.replicas for p in topic_metadata.partitions.values()],
                'timestamp': datetime.now().timestamp()
            }
        except Exception as e:
            self.logger.error(f"Error getting topic metrics: {e}")
            return {}