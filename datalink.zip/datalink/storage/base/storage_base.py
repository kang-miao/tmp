# storage/base/storage_base.py

import logging
from typing import Dict, Any, Optional
from datetime import datetime
from abc import ABC, abstractmethod
from utils.schema_validator import SchemaValidator, ValidationResult

class BaseStorageConnector(ABC):
    """存储连接器基类
    
    为所有存储连接器提供基础功能，包括：
    - Schema验证
    - 错误处理
    - 指标收集
    - 连接管理
    """

    def __init__(self, config: Dict[str, Any]):
        """初始化存储连接器
        
        Args:
            config: 连接配置
        """
        self.logger = logging.getLogger(f"storage.{self.__class__.__name__.lower()}")
        self.config = config
        self.validator = SchemaValidator()
        
        # 基础指标
        self.metrics = {
            'operations_total': 0,
            'operations_failed': 0,
            'validation_errors': 0,
            'last_error': None,
            'last_error_time': None
        }

    @abstractmethod
    async def connect(self) -> bool:
        """建立连接"""
        pass

    @abstractmethod
    async def disconnect(self) -> None:
        """断开连接"""
        pass

    async def validate_data(self, data: Dict[str, Any], 
                          data_type: str) -> ValidationResult:
        """验证数据
        
        Args:
            data: 待验证的数据
            data_type: 数据类型
            
        Returns:
            ValidationResult: 验证结果
        """
        validation_method = getattr(
            self.validator,
            f'validate_{data_type}',
            None
        )
        
        if validation_method:
            result = await validation_method(data)
            if not result.is_valid:
                self.metrics['validation_errors'] += 1
                self._record_error(f"Validation failed: {result.errors}")
            return result
        
        self.logger.warning(f"No validation method found for {data_type}")
        return ValidationResult(True, [], [f"No validation for {data_type}"])

    def _record_error(self, error: str) -> None:
        """记录错误信息
        
        Args:
            error: 错误信息
        """
        self.metrics['operations_failed'] += 1
        self.metrics['last_error'] = error
        self.metrics['last_error_time'] = datetime.now()
        self.logger.error(error)

    async def get_metrics(self) -> Dict[str, Any]:
        """获取监控指标"""
        return {
            **self.metrics,
            'validation_stats': self.validator.get_validation_stats()
        }

# 修改 KeyDB 连接器
class KeyDBConnector(BaseStorageConnector):
    """KeyDB连接器"""

    async def write_data(self, data: Dict[str, Any], 
                        data_type: str) -> bool:
        """写入数据
        
        Args:
            data: 待写入的数据
            data_type: 数据类型
            
        Returns:
            bool: 是否成功
        """
        try:
            # 验证数据
            validation_result = await self.validate_data(data, data_type)
            if not validation_result.is_valid:
                return False

            self.metrics['operations_total'] += 1
            
            # 根据数据类型选择写入方法
            if data_type == 'trade':
                return await self.set_market_ticker(
                    data['market_type'],
                    data['exchange'],
                    data['symbol'],
                    data
                )
            elif data_type == 'order_book':
                return await self.set_order_book(
                    data['market_type'],
                    data['exchange'],
                    data['symbol'],
                    data['bids'],
                    data['asks']
                )
            
            return False

        except Exception as e:
            self._record_error(f"Write error: {str(e)}")
            return False

# 修改 TDengine 连接器
class TDengineConnector(BaseStorageConnector):
    """TDengine连接器"""

    async def write_data(self, data: Dict[str, Any], 
                        data_type: str) -> bool:
        """写入数据"""
        try:
            # 验证数据
            validation_result = await self.validate_data(data, data_type)
            if not validation_result.is_valid:
                return False

            self.metrics['operations_total'] += 1
            
            # 根据数据类型选择写入方法
            if data_type == 'trade':
                return await self.insert_trade(data)
            elif data_type == 'kline':
                return await self.insert_kline(data)
            
            return False

        except Exception as e:
            self._record_error(f"Write error: {str(e)}")
            return False

# 修改 RisingWave 连接器
class RisingWaveConnector(BaseStorageConnector):
    """RisingWave连接器"""

    async def process_data(self, data: Dict[str, Any], 
                         data_type: str) -> bool:
        """处理数据"""
        try:
            # 验证数据
            validation_result = await self.validate_data(data, data_type)
            if not validation_result.is_valid:
                return False

            self.metrics['operations_total'] += 1
            
            # 根据数据类型选择处理方法
            if data_type == 'trade':
                return await self._process_trade(data)
            elif data_type == 'order_book':
                return await self._process_order_book(data)
            
            return False

        except Exception as e:
            self._record_error(f"Processing error: {str(e)}")
            return False

    async def _process_trade(self, data: Dict[str, Any]) -> bool:
        """处理交易数据"""
        try:
            async with self.pool.acquire() as conn:
                query = """
                    INSERT INTO trade_stream (
                        market_type, exchange, symbol, timestamp,
                        price, volume, amount, side, trade_id, maker
                    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
                """
                await conn.execute(
                    query,
                    data['market_type'],
                    data['exchange'],
                    data['symbol'],
                    data['timestamp'],
                    data['price'],
                    data['volume'],
                    data['amount'],
                    data['side'],
                    data['trade_id'],
                    data.get('maker', False)
                )
                return True

        except Exception as e:
            self._record_error(f"Trade processing error: {str(e)}")
            return False