# utils/config_loader.py

import os
import yaml
import json
import logging
from typing import Dict, Any, Optional
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

class ConfigLoader:
    """配置加载器，支持配置文件热更新"""

    def __init__(self, config_path: str):
        self.logger = logging.getLogger("utils.config")
        self.config_path = config_path
        self.config: Dict[str, Any] = {}
        self.observers: Dict[str, Observer] = {}
        self._load_config()
        self._setup_file_watchers()

    def _load_config(self) -> None:
        """加载配置文件"""
        try:
            if self.config_path.endswith('.yaml') or self.config_path.endswith('.yml'):
                with open(self.config_path, 'r') as f:
                    self.config = yaml.safe_load(f)
            elif self.config_path.endswith('.py'):
                with open(self.config_path, 'r') as f:
                    config_content = f.read()
                    exec_globals = {}
                    exec(config_content, exec_globals)
                    self.config = {k: v for k, v in exec_globals.items() 
                                 if not k.startswith('__')}
            else:
                raise ValueError(f"Unsupported config file type: {self.config_path}")
            
            self.logger.info(f"Loaded configuration from {self.config_path}")
        except Exception as e:
            self.logger.error(f"Error loading config: {e}")
            raise

    def _setup_file_watchers(self) -> None:
        """设置配置文件监听器"""
        class ConfigFileHandler(FileSystemEventHandler):
            def __init__(self, loader):
                self.loader = loader

            def on_modified(self, event):
                if not event.is_directory and event.src_path == self.loader.config_path:
                    self.loader._load_config()
                    self.loader.logger.info("Configuration reloaded due to file change")

        observer = Observer()
        observer.schedule(ConfigFileHandler(self), 
                        path=os.path.dirname(self.config_path), 
                        recursive=False)
        observer.start()
        self.observers[self.config_path] = observer

    def get(self, key: str, default: Any = None) -> Any:
        """获取配置值"""
        return self.config.get(key, default)

    def reload(self) -> None:
        """手动重新加载配置"""
        self._load_config()

    def stop_watching(self) -> None:
        """停止文件监听"""
        for observer in self.observers.values():
            observer.stop()
            observer.join()