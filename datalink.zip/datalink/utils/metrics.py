# utils/metrics.py

import time
from typing import Dict, Any, List, Optional, Tuple, Union
from datetime import datetime, timedelta
import statistics
from collections import defaultdict
import json
import asyncio
import logging
from dataclasses import dataclass, asdict
import numpy as np

@dataclass
class MetricPoint:
    """度量指标数据点"""
    timestamp: datetime
    value: float
    tags: Dict[str, str]
    metadata: Optional[Dict[str, Any]] = None

class MetricsBucket:
    """指标数据桶，用于存储特定时间窗口的指标数据"""

    def __init__(self, window_size: timedelta = timedelta(minutes=1)):
        self.window_size = window_size
        self.points: List[MetricPoint] = []
        self.sum = 0
        self.count = 0
        self.min = float('inf')
        self.max = float('-inf')
        self.last_update = datetime.now()

    def add_point(self, point: MetricPoint) -> None:
        """添加数据点"""
        self.points.append(point)
        self.sum += point.value
        self.count += 1
        self.min = min(self.min, point.value)
        self.max = max(self.max, point.value)
        self.last_update = point.timestamp

    def clear_expired(self, current_time: datetime) -> None:
        """清理过期数据"""
        cutoff = current_time - self.window_size
        valid_points = [p for p in self.points if p.timestamp > cutoff]
        
        self.points = valid_points
        if self.points:
            self.sum = sum(p.value for p in self.points)
            self.count = len(self.points)
            self.min = min(p.value for p in self.points)
            self.max = max(p.value for p in self.points)
        else:
            self.sum = 0
            self.count = 0
            self.min = float('inf')
            self.max = float('-inf')

    def get_statistics(self) -> Dict[str, float]:
        """获取统计信息"""
        if not self.points:
            return {
                'count': 0,
                'sum': 0,
                'mean': 0,
                'min': 0,
                'max': 0,
                'stddev': 0
            }

        values = [p.value for p in self.points]
        return {
            'count': self.count,
            'sum': self.sum,
            'mean': self.sum / self.count,
            'min': self.min,
            'max': self.max,
            'stddev': statistics.stdev(values) if len(values) > 1 else 0
        }

class MetricsAggregator:
    """指标聚合器，用于管理和聚合不同时间窗口的指标"""

    def __init__(self):
        self.windows: Dict[timedelta, MetricsBucket] = {
            timedelta(minutes=1): MetricsBucket(timedelta(minutes=1)),
            timedelta(minutes=5): MetricsBucket(timedelta(minutes=5)),
            timedelta(hours=1): MetricsBucket(timedelta(hours=1)),
            timedelta(days=1): MetricsBucket(timedelta(days=1))
        }

    def add_point(self, point: MetricPoint) -> None:
        """添加数据点到所有时间窗口"""
        current_time = datetime.now()
        for bucket in self.windows.values():
            bucket.clear_expired(current_time)
            bucket.add_point(point)

    def get_statistics(self, window: timedelta) -> Dict[str, float]:
        """获取指定时间窗口的统计信息"""
        if window not in self.windows:
            raise ValueError(f"Unsupported window size: {window}")
        return self.windows[window].get_statistics()

class MetricsCollector:
    """指标收集器"""

    def __init__(self, retention_period: timedelta = timedelta(days=7)):
        self.logger = logging.getLogger("metrics.collector")
        self.metrics: Dict[str, MetricsAggregator] = defaultdict(MetricsAggregator)
        self.retention_period = retention_period
        self._last_cleanup = datetime.now()

    def record(self, name: str, value: float, tags: Optional[Dict[str, str]] = None,
               metadata: Optional[Dict[str, Any]] = None) -> None:
        """记录指标"""
        point = MetricPoint(
            timestamp=datetime.now(),
            value=value,
            tags=tags or {},
            metadata=metadata
        )
        self.metrics[name].add_point(point)

    def get_metric_statistics(self, name: str, window: timedelta) -> Optional[Dict[str, float]]:
        """获取指标统计信息"""
        if name not in self.metrics:
            return None
        return self.metrics[name].get_statistics(window)

    def get_all_metrics(self) -> Dict[str, Dict[str, Any]]:
        """获取所有指标的统计信息"""
        result = {}
        for name, aggregator in self.metrics.items():
            result[name] = {
                str(window): stats 
                for window, stats in 
                [(w, aggregator.get_statistics(w)) for w in aggregator.windows.keys()]
            }
        return result

class PerformanceMetrics:
    """性能指标收集器"""

    def __init__(self, collector: MetricsCollector):
        self.collector = collector

    async def record_latency(self, operation: str, latency: float,
                           tags: Optional[Dict[str, str]] = None) -> None:
        """记录延迟指标"""
        self.collector.record(
            f"latency.{operation}",
            latency,
            tags=tags,
            metadata={'unit': 'seconds'}
        )

    async def record_throughput(self, operation: str, count: int,
                              tags: Optional[Dict[str, str]] = None) -> None:
        """记录吞吐量指标"""
        self.collector.record(
            f"throughput.{operation}",
            count,
            tags=tags,
            metadata={'unit': 'operations'}
        )

    async def record_error_rate(self, operation: str, error_count: int,
                              total_count: int,
                              tags: Optional[Dict[str, str]] = None) -> None:
        """记录错误率指标"""
        if total_count > 0:
            error_rate = error_count / total_count
            self.collector.record(
                f"error_rate.{operation}",
                error_rate,
                tags=tags,
                metadata={'unit': 'ratio'}
            )

class BusinessMetrics:
    """业务指标收集器"""

    def __init__(self, collector: MetricsCollector):
        self.collector = collector

    async def record_market_data(self, market_type: str, data_type: str,
                               value: float, tags: Optional[Dict[str, str]] = None) -> None:
        """记录市场数据指标"""
        self.collector.record(
            f"market_data.{market_type}.{data_type}",
            value,
            tags=tags
        )

    async def record_storage_usage(self, storage_type: str, size_bytes: int,
                                 tags: Optional[Dict[str, str]] = None) -> None:
        """记录存储使用指标"""
        self.collector.record(
            f"storage.{storage_type}.size",
            size_bytes,
            tags=tags,
            metadata={'unit': 'bytes'}
        )

class MetricsManager:
    """指标管理器"""

    def __init__(self):
        self.collector = MetricsCollector()
        self.performance = PerformanceMetrics(self.collector)
        self.business = BusinessMetrics(self.collector)

    async def get_system_metrics(self) -> Dict[str, Any]:
        """获取系统指标摘要"""
        metrics = self.collector.get_all_metrics()
        
        # 对指标进行分类
        categorized_metrics = {
            'performance': {},
            'business': {},
            'storage': {}
        }
        
        for name, data in metrics.items():
            if name.startswith('latency.') or name.startswith('throughput.'):
                categorized_metrics['performance'][name] = data
            elif name.startswith('market_data.'):
                categorized_metrics['business'][name] = data
            elif name.startswith('storage.'):
                categorized_metrics['storage'][name] = data
        
        return categorized_metrics

    def export_metrics(self, format: str = 'json') -> str:
        """导出指标数据"""
        metrics = self.collector.get_all_metrics()
        if format == 'json':
            return json.dumps(metrics, default=str, indent=2)
        raise ValueError(f"Unsupported format: {format}")

class Timer:
    """性能计时器"""

    def __init__(self, metrics: PerformanceMetrics, operation: str,
                 tags: Optional[Dict[str, str]] = None):
        self.metrics = metrics
        self.operation = operation
        self.tags = tags
        self.start_time = None

    async def __aenter__(self):
        self.start_time = time.perf_counter()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.start_time is not None:
            duration = time.perf_counter() - self.start_time
            await self.metrics.record_latency(self.operation, duration, self.tags)

class RateTracker:
    """速率追踪器"""

    def __init__(self, metrics: PerformanceMetrics, operation: str,
                 window_size: timedelta = timedelta(minutes=1),
                 tags: Optional[Dict[str, str]] = None):
        self.metrics = metrics
        self.operation = operation
        self.window_size = window_size
        self.tags = tags
        self.counts: List[Tuple[datetime, int]] = []

    async def increment(self, count: int = 1) -> None:
        """增加计数"""
        now = datetime.now()
        self.counts.append((now, count))
        
        # 清理过期数据
        cutoff = now - self.window_size
        self.counts = [(t, c) for t, c in self.counts if t > cutoff]
        
        # 计算速率
        total_count = sum(c for _, c in self.counts)
        rate = total_count / self.window_size.total_seconds()
        
        await self.metrics.record_throughput(self.operation, rate, self.tags)