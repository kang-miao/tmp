# utils/schema_validator.py

import logging
from typing import Dict, Any, Optional, List, Union, Tuple
from datetime import datetime
import yaml
import json
import os
from dataclasses import dataclass
import re

@dataclass
class ValidationResult:
    """验证结果"""
    is_valid: bool
    errors: List[str]
    warnings: List[str]

class SchemaValidator:
    """Schema验证器
    
    提供统一的Schema验证功能，支持：
    - 数据结构验证
    - 数据类型检查
    - 字段约束验证
    - 业务规则验证
    """

    def __init__(self):
        """初始化验证器"""
        self.logger = logging.getLogger("utils.schema")
        
        # 加载所有Schema定义
        self.schemas = self._load_schemas()
        
        # 验证统计
        self.validation_stats = {
            'total': 0,
            'passed': 0,
            'failed': 0,
            'warnings': 0
        }

    def _load_schemas(self) -> Dict[str, Any]:
        """加载所有Schema定义"""
        schemas = {}
        schema_dir = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            'schemas'
        )
        
        # 加载KeyDB Schema
        keydb_schema_path = os.path.join(schema_dir, 'keydb/schema.yaml')
        if os.path.exists(keydb_schema_path):
            with open(keydb_schema_path, 'r') as f:
                schemas['keydb'] = yaml.safe_load(f)
        
        # 加载TDengine Schema
        tdengine_schema_path = os.path.join(schema_dir, 'tdengine/tables.sql')
        if os.path.exists(tdengine_schema_path):
            schemas['tdengine'] = self._parse_sql_schema(tdengine_schema_path)
        
        # 加载RisingWave Schema
        risingwave_schema_path = os.path.join(schema_dir, 'risingwave/views.sql')
        if os.path.exists(risingwave_schema_path):
            schemas['risingwave'] = self._parse_sql_schema(risingwave_schema_path)
        
        return schemas

    def _parse_sql_schema(self, file_path: str) -> Dict[str, Any]:
        """解析SQL Schema文件"""
        try:
            with open(file_path, 'r') as f:
                content = f.read()
            
            schema = {}
            current_table = None
            
            for line in content.split('\n'):
                line = line.strip()
                
                # 解析CREATE TABLE/STABLE语句
                if line.startswith('CREATE'):
                    match = re.search(r'CREATE\s+(?:TABLE|STABLE)\s+(\w+)', line)
                    if match:
                        current_table = match.group(1)
                        schema[current_table] = {
                            'fields': [],
                            'tags': [],
                            'constraints': []
                        }
                
                # 解析字段定义
                elif current_table and line and not line.startswith(('--', ')')):
                    if 'TAGS' in line:
                        continue
                    
                    field_match = re.search(r'`?(\w+)`?\s+([A-Za-z0-9()]+)', line)
                    if field_match:
                        field_name, field_type = field_match.groups()
                        schema[current_table]['fields'].append({
                            'name': field_name,
                            'type': field_type
                        })
            
            return schema
            
        except Exception as e:
            self.logger.error(f"Error parsing SQL schema: {e}")
            return {}

    def validate_trade_data(self, data: Dict[str, Any]) -> ValidationResult:
        """验证交易数据
        
        Args:
            data: 交易数据
            
        Returns:
            ValidationResult: 验证结果
        """
        self.validation_stats['total'] += 1
        errors = []
        warnings = []
        
        # 基本字段验证
        required_fields = {
            'market_type': str,
            'exchange': str,
            'symbol': str,
            'timestamp': (int, float, datetime),
            'price': (int, float),
            'volume': (int, float),
            'side': str,
            'trade_id': str
        }
        
        for field, field_type in required_fields.items():
            if field not in data:
                errors.append(f"Missing required field: {field}")
                continue
            
            if not isinstance(data[field], field_type):
                errors.append(
                    f"Invalid type for {field}: expected {field_type}, "
                    f"got {type(data[field])}"
                )

        # 业务规则验证
        if not errors:
            # 价格和数量必须为正数
            if data['price'] <= 0:
                errors.append("Price must be positive")
            if data['volume'] <= 0:
                errors.append("Volume must be positive")
            
            # 交易方向必须是buy或sell
            if data['side'] not in ['buy', 'sell']:
                errors.append("Side must be 'buy' or 'sell'")
            
            # 时间戳不能超过当前时间
            if isinstance(data['timestamp'], datetime):
                timestamp = data['timestamp']
            else:
                timestamp = datetime.fromtimestamp(
                    data['timestamp'] if data['timestamp'] < 1e12 
                    else data['timestamp']/1000
                )
            
            if timestamp > datetime.now():
                errors.append("Timestamp cannot be in the future")
            
            # 添加警告
            time_diff = datetime.now() - timestamp
            if time_diff.total_seconds() > 60:
                warnings.append(f"Data is {time_diff.total_seconds()}s old")

        is_valid = len(errors) == 0
        if is_valid:
            self.validation_stats['passed'] += 1
        else:
            self.validation_stats['failed'] += 1
        
        if warnings:
            self.validation_stats['warnings'] += 1
        
        return ValidationResult(is_valid, errors, warnings)

    def validate_order_book(self, data: Dict[str, Any]) -> ValidationResult:
        """验证订单簿数据"""
        self.validation_stats['total'] += 1
        errors = []
        warnings = []
        
        # 基本字段验证
        required_fields = {
            'market_type': str,
            'exchange': str,
            'symbol': str,
            'timestamp': (int, float, datetime),
            'bids': list,
            'asks': list
        }
        
        for field, field_type in required_fields.items():
            if field not in data:
                errors.append(f"Missing required field: {field}")
                continue
            
            if not isinstance(data[field], field_type):
                errors.append(
                    f"Invalid type for {field}: expected {field_type}, "
                    f"got {type(data[field])}"
                )

        # 业务规则验证
        if not errors:
            # 检查价格档位格式
            for side in ['bids', 'asks']:
                for level in data[side]:
                    if not isinstance(level, (list, tuple)) or len(level) != 2:
                        errors.append(f"Invalid {side} format")
                        break
                    
                    price, volume = level
                    if not isinstance(price, (int, float)) or price <= 0:
                        errors.append(f"Invalid price in {side}")
                    if not isinstance(volume, (int, float)) or volume <= 0:
                        errors.append(f"Invalid volume in {side}")
            
            # 检查买卖价格关系
            if data['bids'] and data['asks']:
                best_bid = data['bids'][0][0]
                best_ask = data['asks'][0][0]
                if best_bid >= best_ask:
                    errors.append("Best bid price must be lower than best ask price")
            
            # 检查价格排序
            if len(data['bids']) > 1:
                for i in range(1, len(data['bids'])):
                    if data['bids'][i][0] > data['bids'][i-1][0]:
                        errors.append("Bids must be sorted in descending order")
                        break
            
            if len(data['asks']) > 1:
                for i in range(1, len(data['asks'])):
                    if data['asks'][i][0] < data['asks'][i-1][0]:
                        errors.append("Asks must be sorted in ascending order")
                        break

        is_valid = len(errors) == 0
        if is_valid:
            self.validation_stats['passed'] += 1
        else:
            self.validation_stats['failed'] += 1
        
        if warnings:
            self.validation_stats['warnings'] += 1
        
        return ValidationResult(is_valid, errors, warnings)

    def validate_kline(self, data: Dict[str, Any]) -> ValidationResult:
        """验证K线数据"""
        self.validation_stats['total'] += 1
        errors = []
        warnings = []
        
        # 基本字段验证
        required_fields = {
            'market_type': str,
            'exchange': str,
            'symbol': str,
            'timestamp': (int, float, datetime),
            'interval': str,
            'open': (int, float),
            'high': (int, float),
            'low': (int, float),
            'close': (int, float),
            'volume': (int, float)
        }
        
        for field, field_type in required_fields.items():
            if field not in data:
                errors.append(f"Missing required field: {field}")
                continue
            
            if not isinstance(data[field], field_type):
                errors.append(
                    f"Invalid type for {field}: expected {field_type}, "
                    f"got {type(data[field])}"
                )

        # 业务规则验证
        if not errors:
            # 验证OHLC关系
            if not (data['low'] <= data['open'] <= data['high'] and 
                   data['low'] <= data['close'] <= data['high']):
                errors.append("Invalid OHLC values")
            
            # 验证正数值
            for field in ['open', 'high', 'low', 'close', 'volume']:
                if data[field] <= 0:
                    errors.append(f"{field} must be positive")
            
            # 验证K线间隔格式
            if not re.match(r'^\d+[mhdwM]$', data['interval']):
                errors.append("Invalid interval format")

        is_valid = len(errors) == 0
        if is_valid:
            self.validation_stats['passed'] += 1
        else:
            self.validation_stats['failed'] += 1
        
        if warnings:
            self.validation_stats['warnings'] += 1
        
        return ValidationResult(is_valid, errors, warnings)

    def get_validation_stats(self) -> Dict[str, int]:
        """获取验证统计"""
        return {
            'total_validations': self.validation_stats['total'],
            'passed': self.validation_stats['passed'],
            'failed': self.validation_stats['failed'],
            'warnings': self.validation_stats['warnings'],
            'pass_rate': (self.validation_stats['passed'] / 
                         self.validation_stats['total']
                         if self.validation_stats['total'] > 0 else 0)
        }