# utils/error_handler.py

import logging
from typing import Dict, Any, Optional, Type
from datetime import datetime
import traceback
from dataclasses import dataclass
import asyncio
import uuid

@dataclass
class ErrorContext:
    """错误上下文"""
    error_type: str
    error_message: str
    stack_trace: str
    timestamp: datetime
    component: str
    additional_info: Optional[Dict[str, Any]] = None

class ErrorHandler:
    """错误处理器
    
    提供统一的错误处理机制，包括：
    - 错误分类
    - 错误日志
    - 错误恢复
    - 错误通知
    """

    def __init__(self):
        self.logger = logging.getLogger("utils.error")
        self.error_history: List[ErrorContext] = []
        self.error_counts: Dict[str, int] = {}
        
    def handle_error(self, error: Exception, component: str,
                    additional_info: Optional[Dict[str, Any]] = None) -> ErrorContext:
        """处理错误
        
        Args:
            error: 异常对象
            component: 组件名称
            additional_info: 额外信息
            
        Returns:
            ErrorContext: 错误上下文
        """
        # 创建错误上下文
        context = ErrorContext(
            error_type=error.__class__.__name__,
            error_message=str(error),
            stack_trace=traceback.format_exc(),
            timestamp=datetime.now(),
            component=component,
            additional_info=additional_info
        )
        
        # 更新错误统计
        error_type = context.error_type
        self.error_counts[error_type] = self.error_counts.get(error_type, 0) + 1
        
        # 记录错误历史
        self.error_history.append(context)
        if len(self.error_history) > 1000:  # 限制历史记录数量
            self.error_history.pop(0)
        
        # 记录日志
        self.logger.error(
            f"Error in {component}: {error_type} - {context.error_message}",
            exc_info=True,
            extra={
                'error_context': context,
                'additional_info': additional_info
            }
        )
        
        return context

    def get_error_stats(self) -> Dict[str, Any]:
        """获取错误统计"""
        return {
            'total_errors': sum(self.error_counts.values()),
            'error_counts': self.error_counts,
            'recent_errors': [
                {
                    'type': err.error_type,
                    'message': err.error_message,
                    'component': err.component,
                    'timestamp': err.timestamp.isoformat()
                }
                for err in self.error_history[-10:]  # 最近10条错误
            ]
        }

    def clear_error_history(self) -> None:
        """清空错误历史"""
        self.error_history.clear()
        self.error_counts.clear()

# 自定义异常类
class DataLinkError(Exception):
    """DataLink基础异常类"""
    pass

class ValidationError(DataLinkError):
    """数据验证错误"""
    pass

class StorageError(DataLinkError):
    """存储错误"""
    pass

class AdapterError(DataLinkError):
    """适配器错误"""
    pass

class ConfigurationError(DataLinkError):
    """配置错误"""
    pass

class MigrationError(DataLinkError):
    """迁移错误"""
    pass

# 错误处理装饰器
def handle_errors(component: str):
    """错误处理装饰器
    
    Args:
        component: 组件名称
    """
    def decorator(func):
        async def wrapper(*args, **kwargs):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                error_handler = ErrorHandler()
                error_context = error_handler.handle_error(
                    e, component,
                    {
                        'args': str(args),
                        'kwargs': str(kwargs)
                    }
                )
                # 根据错误类型决定是否重新抛出
                if isinstance(e, DataLinkError):
                    raise
                # 将其他异常转换为DataLink异常
                raise DataLinkError(f"Error in {component}: {str(e)}") from e
        return wrapper
    return decorator

def generate_trace_id() -> str:
    """生成追踪ID"""
    return str(uuid.uuid4())

class RetryStrategy:
    """重试策略类"""
    def __init__(self, 
                 max_retries: int = 3, 
                 backoff_factor: float = 1.5,
                 max_delay: float = 30.0,
                 retry_exceptions: tuple = (Exception,)):
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor
        self.max_delay = max_delay
        self.retry_exceptions = retry_exceptions
        self.logger = logging.getLogger(__name__)

    async def execute(self, func, *args, **kwargs):
        """执行带重试的函数调用"""
        last_exception = None
        for attempt in range(self.max_retries):
            try:
                return await func(*args, **kwargs)
            except self.retry_exceptions as e:
                last_exception = e
                if attempt < self.max_retries - 1:
                    delay = min(
                        self.backoff_factor ** attempt,
                        self.max_delay
                    )
                    self.logger.warning(
                        f"Retry attempt {attempt + 1}/{self.max_retries} "
                        f"for {func.__name__} after {delay:.2f}s"
                    )
                    await asyncio.sleep(delay)
                else:
                    self.logger.error(
                        f"Max retries ({self.max_retries}) reached "
                        f"for {func.__name__}"
                    )
        raise last_exception

class ErrorContext:
    """错误上下文类"""
    def __init__(self, 
                 error: Exception,
                 component: str,
                 context: Dict[str, Any],
                 trace_id: str):
        self.error = error
        self.component = component
        self.context = context
        self.trace_id = trace_id
        self.timestamp = datetime.now()
        self.traceback = traceback.format_exc()

class ErrorHandler:
    """错误处理器"""
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self._error_registry: Dict[str, list] = {}

    def handle_error(self, 
                    error: Exception,
                    component: str,
                    context: Dict[str, Any]) -> ErrorContext:
        """处理错误"""
        trace_id = generate_trace_id()
        error_context = ErrorContext(error, component, context, trace_id)
        
        # 记录错误
        self._register_error(error_context)
        
        # 记录日志
        self.logger.error(
            f"Error in {component} [trace_id: {trace_id}]: {str(error)}\n"
            f"Context: {context}\n"
            f"Traceback: {error_context.traceback}"
        )
        
        return error_context

    def _register_error(self, error_context: ErrorContext):
        """注册错误到内存中"""
        component = error_context.component
        if component not in self._error_registry:
            self._error_registry[component] = []
        self._error_registry[component].append(error_context)
        
        # 保持最近1000条错误记录
        if len(self._error_registry[component]) > 1000:
            self._error_registry[component].pop(0)

    def get_error_stats(self, component: Optional[str] = None) -> Dict[str, Any]:
        """获取错误统计信息"""
        if component:
            errors = self._error_registry.get(component, [])
            return {
                'total_errors': len(errors),
                'recent_errors': errors[-10:],
                'error_types': self._count_error_types(errors)
            }
        
        return {
            comp: {
                'total_errors': len(errs),
                'recent_errors': errs[-10:],
                'error_types': self._count_error_types(errs)
            }
            for comp, errs in self._error_registry.items()
        }

    def _count_error_types(self, errors: list) -> Dict[str, int]:
        """统计错误类型"""
        error_types = {}
        for error in errors:
            error_type = type(error.error).__name__
            error_types[error_type] = error_types.get(error_type, 0) + 1
        return error_types

def enhanced_error_handler(component: str, 
                         retry_strategy: Optional[RetryStrategy] = None):
    """增强的错误处理装饰器"""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            try:
                if retry_strategy:
                    return await retry_strategy.execute(func, *args, **kwargs)
                return await func(*args, **kwargs)
            except Exception as e:
                error_handler = ErrorHandler()
                context = {
                    'component': component,
                    'function': func.__name__,
                    'args': str(args),
                    'kwargs': str(kwargs),
                    'timestamp': datetime.now().isoformat(),
                    'trace_id': generate_trace_id()
                }
                error_context = error_handler.handle_error(e, component, context)
                
                # 根据错误类型决定是否重新抛出
                if isinstance(e, DataLinkError):
                    raise
                # 将其他异常转换为DataLink异常
                raise DataLinkError(
                    f"Error in {component} [trace_id: {error_context.trace_id}]: "
                    f"{str(e)}"
                ) from e
        return wrapper
    return decorator