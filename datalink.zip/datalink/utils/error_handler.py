# utils/error_handler.py

import logging
from typing import Dict, Any, Optional, Type
from datetime import datetime
import traceback
from dataclasses import dataclass

@dataclass
class ErrorContext:
    """错误上下文"""
    error_type: str
    error_message: str
    stack_trace: str
    timestamp: datetime
    component: str
    additional_info: Optional[Dict[str, Any]] = None

class ErrorHandler:
    """错误处理器
    
    提供统一的错误处理机制，包括：
    - 错误分类
    - 错误日志
    - 错误恢复
    - 错误通知
    """

    def __init__(self):
        self.logger = logging.getLogger("utils.error")
        self.error_history: List[ErrorContext] = []
        self.error_counts: Dict[str, int] = {}
        
    def handle_error(self, error: Exception, component: str,
                    additional_info: Optional[Dict[str, Any]] = None) -> ErrorContext:
        """处理错误
        
        Args:
            error: 异常对象
            component: 组件名称
            additional_info: 额外信息
            
        Returns:
            ErrorContext: 错误上下文
        """
        # 创建错误上下文
        context = ErrorContext(
            error_type=error.__class__.__name__,
            error_message=str(error),
            stack_trace=traceback.format_exc(),
            timestamp=datetime.now(),
            component=component,
            additional_info=additional_info
        )
        
        # 更新错误统计
        error_type = context.error_type
        self.error_counts[error_type] = self.error_counts.get(error_type, 0) + 1
        
        # 记录错误历史
        self.error_history.append(context)
        if len(self.error_history) > 1000:  # 限制历史记录数量
            self.error_history.pop(0)
        
        # 记录日志
        self.logger.error(
            f"Error in {component}: {error_type} - {context.error_message}",
            exc_info=True,
            extra={
                'error_context': context,
                'additional_info': additional_info
            }
        )
        
        return context

    def get_error_stats(self) -> Dict[str, Any]:
        """获取错误统计"""
        return {
            'total_errors': sum(self.error_counts.values()),
            'error_counts': self.error_counts,
            'recent_errors': [
                {
                    'type': err.error_type,
                    'message': err.error_message,
                    'component': err.component,
                    'timestamp': err.timestamp.isoformat()
                }
                for err in self.error_history[-10:]  # 最近10条错误
            ]
        }

    def clear_error_history(self) -> None:
        """清空错误历史"""
        self.error_history.clear()
        self.error_counts.clear()

# 自定义异常类
class DataLinkError(Exception):
    """DataLink基础异常类"""
    pass

class ValidationError(DataLinkError):
    """数据验证错误"""
    pass

class StorageError(DataLinkError):
    """存储错误"""
    pass

class AdapterError(DataLinkError):
    """适配器错误"""
    pass

class ConfigurationError(DataLinkError):
    """配置错误"""
    pass

class MigrationError(DataLinkError):
    """迁移错误"""
    pass

# 错误处理装饰器
def handle_errors(component: str):
    """错误处理装饰器
    
    Args:
        component: 组件名称
    """
    def decorator(func):
        async def wrapper(*args, **kwargs):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                error_handler = ErrorHandler()
                error_context = error_handler.handle_error(
                    e, component,
                    {
                        'args': str(args),
                        'kwargs': str(kwargs)
                    }
                )
                # 根据错误类型决定是否重新抛出
                if isinstance(e, DataLinkError):
                    raise
                # 将其他异常转换为DataLink异常
                raise DataLinkError(f"Error in {component}: {str(e)}") from e
        return wrapper
    return decorator