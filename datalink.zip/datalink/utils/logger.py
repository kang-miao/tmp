# utils/logger.py

import logging
import logging.config
import yaml
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional

class JsonFormatter(logging.Formatter):
   """JSON格式日志格式化器"""
   
   def __init__(self, fmt: Optional[str] = None):
       super().__init__()
       self.fmt = fmt or '%(asctime)s %(name)s %(levelname)s %(message)s'

   def format(self, record: logging.LogRecord) -> str:
       record_dict = {
           'timestamp': datetime.fromtimestamp(record.created).isoformat(),
           'logger': record.name,
           'level': record.levelname,
           'message': record.getMessage(),
           'module': record.module,
           'line': record.lineno
       }

       if record.exc_info:
           record_dict['exc_info'] = self.formatException(record.exc_info)

       if hasattr(record, 'data'):
           record_dict['data'] = record.data

       return json.dumps(record_dict)

class DataLinkLogger:
   """DataLink系统日志管理器"""

   def __init__(self, config_path: str = 'config/logging.yaml'):
       self.config_path = config_path
       self._setup_logging()

   def _setup_logging(self) -> None:
       """设置日志系统"""
       try:
           # 确保日志目录存在
           log_dir = Path('logs')
           log_dir.mkdir(exist_ok=True)

           # 加载日志配置
           with open(self.config_path, 'r') as f:
               config = yaml.safe_load(f)
               logging.config.dictConfig(config)

       except Exception as e:
           # 如果配置加载失败，使用基本配置
           logging.basicConfig(
               level=logging.INFO,
               format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
               handlers=[
                   logging.StreamHandler(),
                   logging.FileHandler('logs/datalink.log')
               ]
           )
           logging.error(f"Error loading logging config: {e}")

   @staticmethod
   def get_logger(name: str) -> logging.Logger:
       """获取命名日志器"""
       return logging.getLogger(name)

   @staticmethod
   def add_file_handler(logger: logging.Logger, 
                       filename: str,
                       level: int = logging.INFO) -> None:
       """添加文件处理器"""
       handler = logging.FileHandler(filename)
       handler.setLevel(level)
       formatter = logging.Formatter(
           '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
       )
       handler.setFormatter(formatter)
       logger.addHandler(handler)

   @staticmethod
   def add_json_handler(logger: logging.Logger,
                       filename: str,
                       level: int = logging.INFO) -> None:
       """添加JSON格式的文件处理器"""
       handler = logging.FileHandler(filename)
       handler.setLevel(level)
       handler.setFormatter(JsonFormatter())
       logger.addHandler(handler)

   @staticmethod
   def set_level(logger: logging.Logger, level: int) -> None:
       """设置日志级别"""
       logger.setLevel(level)