from setuptools import setup, find_packages

setup(
    name="datalink",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        'aiohttp>=3.8.0',
        'asyncpg>=0.25.0',
        'pandas>=1.3.0',
        'pyyaml>=5.4.0',
        'redis>=4.0.0',
        'taos>=2.0.0',
        'minio>=7.0.0',
        'confluent-kafka>=1.8.0',
        'fastapi>=0.68.0',
        'uvicorn>=0.15.0',
    ],
    extras_require={
        'dev': [
            'pytest>=6.0.0',
            'pytest-asyncio>=0.15.0',
            'pytest-cov>=2.12.0',
            'black>=21.5b2',
            'isort>=5.9.0',
            'flake8>=3.9.0',
            'mypy>=0.910',
        ],
    },
    python_requires='>=3.8',
    author="Your Name",
    author_email="your.email@example.com",
    description="A real-time market data collection and processing system",
    keywords="market-data,real-time,data-processing",
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Financial and Insurance Industry',
        'Topic :: Office/Business :: Financial :: Investment',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
    ],
)