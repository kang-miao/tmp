from di.providers.base_provider import BaseProvider
from consistency.data_checker import DataConsistencyChecker
from config.checker_config import DataCheckerConfig

class CheckerProvider(BaseProvider):
    """检查器服务提供者"""
    def register(self):
        """注册检查器服务"""
        # 注册配置
        self.container.register_instance(
            DataCheckerConfig,
            DataCheckerConfig()
        )
        
        # 注册检查器
        self.container.register(
            DataConsistencyChecker,
            DataConsistencyChecker,
            singleton=True
        )

    def boot(self):
        """启动检查器服务"""
        checker = self.container.resolve(DataConsistencyChecker)
        # 初始化检查器
        checker.initialize()
