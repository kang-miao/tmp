from abc import ABC, abstractmethod
from typing import Dict, Any
from di.container import DIContainer

class BaseProvider(ABC):
    """服务提供者基类"""
    def __init__(self, container: DIContainer):
        self.container = container

    @abstractmethod
    def register(self):
        """注册服务"""
        pass

    @abstractmethod
    def boot(self):
        """启动服务"""
        pass
