from di.providers.base_provider import BaseProvider
from core.data_link import DataLink
from config.base_config import BaseConfig

class AppProvider(BaseProvider):
    """应用服务提供者"""
    def register(self):
        """注册应用服务"""
        # 注册基础配置
        self.container.register_instance(
            BaseConfig,
            BaseConfig()
        )
        
        # 注册核心服务
        self.container.register(
            DataLink,
            DataLink,
            singleton=True
        )

    def boot(self):
        """启动应用服务"""
        data_link = self.container.resolve(DataLink)
        # 初始化数据链接
        data_link.initialize()
