from di.providers.base_provider import BaseProvider
from validators.market_validator import MarketDataValidator
from config.validator_config import ValidatorConfig

class ValidatorProvider(BaseProvider):
    """验证器服务提供者"""
    def register(self):
        """注册验证器服务"""
        # 注册配置
        self.container.register_instance(
            ValidatorConfig,
            ValidatorConfig()
        )
        
        # 注册验证器
        self.container.register(
            MarketDataValidator,
            MarketDataValidator,
            singleton=True
        )

    def boot(self):
        """启动验证器服务"""
        validator = self.container.resolve(MarketDataValidator)
        # 初始化验证器
        validator.initialize()
