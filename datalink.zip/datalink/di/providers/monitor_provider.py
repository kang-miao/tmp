from di.providers.base_provider import BaseProvider
from monitor.performance_monitor import PerformanceMonitor
from monitor.latency_monitor import LatencyMonitor
from config.monitor_config import MonitorConfig

class MonitorProvider(BaseProvider):
    """监控服务提供者"""
    def register(self):
        """注册监控服务"""
        # 注册配置
        self.container.register_instance(
            MonitorConfig,
            MonitorConfig()
        )
        
        # 注册监控服务
        self.container.register(
            PerformanceMonitor,
            PerformanceMonitor,
            singleton=True
        )
        self.container.register(
            LatencyMonitor,
            LatencyMonitor,
            singleton=True
        )

    def boot(self):
        """启动监控服务"""
        performance_monitor = self.container.resolve(PerformanceMonitor)
        latency_monitor = self.container.resolve(LatencyMonitor)
        
        # 启动监控
        performance_monitor.start()
        latency_monitor.start()
