from typing import Dict, Any, Type, TypeVar, Optional, Callable
import inspect
from functools import wraps

T = TypeVar('T')

class DIContainer:
    """依赖注入容器"""
    def __init__(self):
        self._services: Dict[str, Any] = {}
        self._factories: Dict[str, Callable[..., Any]] = {}
        self._singletons: Dict[str, Any] = {}

    def register(self, interface: Type[T], implementation: Type[T], 
                singleton: bool = True):
        """注册服务"""
        key = self._get_key(interface)
        if singleton:
            self._services[key] = implementation
        else:
            self._factories[key] = implementation

    def register_instance(self, interface: Type[T], instance: T):
        """注册实例"""
        key = self._get_key(interface)
        self._singletons[key] = instance

    def register_factory(self, interface: Type[T], 
                        factory: Callable[..., T]):
        """注册工厂函数"""
        key = self._get_key(interface)
        self._factories[key] = factory

    def resolve(self, interface: Type[T]) -> T:
        """解析服务"""
        key = self._get_key(interface)
        
        # 检查是否已有单例实例
        if key in self._singletons:
            return self._singletons[key]
            
        # 检查是否需要创建新实例
        if key in self._services:
            instance = self._create_instance(self._services[key])
            self._singletons[key] = instance
            return instance
            
        # 检查是否有工厂函数
        if key in self._factories:
            return self._factories[key]()
            
        raise KeyError(f"No registration found for {interface}")

    def _create_instance(self, cls: Type[T]) -> T:
        """创建实例并注入依赖"""
        if not inspect.isclass(cls):
            return cls
            
        # 获取构造函数参数
        init_signature = inspect.signature(cls.__init__)
        parameters = init_signature.parameters
        
        # 准备构造函数参数
        kwargs = {}
        for name, param in parameters.items():
            if name == 'self':
                continue
            if param.annotation != inspect.Parameter.empty:
                try:
                    kwargs[name] = self.resolve(param.annotation)
                except KeyError:
                    if param.default != inspect.Parameter.empty:
                        kwargs[name] = param.default
                    else:
                        raise ValueError(
                            f"Cannot resolve parameter {name} "
                            f"of type {param.annotation}"
                        )
                        
        return cls(**kwargs)

    def _get_key(self, interface: Type[T]) -> str:
        """获取服务键"""
        return f"{interface.__module__}.{interface.__name__}"

    def inject(self, func):
        """依赖注入装饰器"""
        signature = inspect.signature(func)
        
        @wraps(func)
        def wrapper(*args, **kwargs):
            # 准备注入的参数
            injected_kwargs = {}
            for name, param in signature.parameters.items():
                if param.annotation != inspect.Parameter.empty:
                    if name not in kwargs:
                        try:
                            injected_kwargs[name] = self.resolve(param.annotation)
                        except KeyError:
                            if param.default != inspect.Parameter.empty:
                                injected_kwargs[name] = param.default
                            
            # 合并参数
            kwargs.update(injected_kwargs)
            return func(*args, **kwargs)
            
        return wrapper
