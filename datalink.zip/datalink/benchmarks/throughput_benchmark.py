from typing import Dict, Any, List, Callable
from datetime import datetime
import asyncio
import statistics
from benchmarks.base_benchmark import BaseBenchmark, BenchmarkResult

class ThroughputBenchmark(BaseBenchmark):
    """吞吐量基准测试"""
    def __init__(self, logger, target_func: Callable,
                 name: str = "throughput_benchmark"):
        super().__init__(logger, name)
        self.target_func = target_func
        self.warmup_duration = 5  # 预热时间（秒）

    async def setup(self):
        """预热测试"""
        self.logger.info(f"Warming up {self.name}")
        end_time = asyncio.get_event_loop().time() + self.warmup_duration
        while asyncio.get_event_loop().time() < end_time:
            await self.target_func()

    async def run(self, parameters: Dict[str, Any]) -> BenchmarkResult:
        """执行吞吐量测试"""
        duration = parameters.get('duration', 60)  # 测试持续时间（秒）
        concurrency = parameters.get('concurrency', 1)  # 并发数
        
        self.logger.info(
            f"Starting {self.name} with {concurrency} "
            f"concurrent workers for {duration}s"
        )
        
        start_time = datetime.now()
        operations = []
        errors = 0
        
        try:
            # 创建并发任务
            tasks = []
            for _ in range(concurrency):
                task = asyncio.create_task(
                    self._worker(duration, operations, errors)
                )
                tasks.append(task)
                
            # 等待所有任务完成
            await asyncio.gather(*tasks)
            
            end_time = datetime.now()
            total_duration = (end_time - start_time).total_seconds()
            
            # 计算统计指标
            total_ops = len(operations)
            throughput = total_ops / total_duration
            
            metrics = {
                'total_operations': total_ops,
                'throughput': throughput,
                'avg_throughput_per_worker': throughput / concurrency,
                'error_rate': errors / (total_ops + errors) if total_ops > 0 else 1.0
            }
            
            if operations:
                metrics.update({
                    'min_batch_ops': min(operations),
                    'max_batch_ops': max(operations),
                    'avg_batch_ops': statistics.mean(operations),
                    'std_dev_batch_ops': statistics.stdev(operations)
                })
                
            details = {
                'duration': total_duration,
                'concurrency': concurrency,
                'successful_operations': total_ops,
                'failed_operations': errors,
                'operations_distribution': self._calculate_distribution(operations)
            }
            
            return self._create_result(
                metrics=metrics,
                parameters=parameters,
                details=details,
                start_time=start_time,
                end_time=end_time
            )
            
        except Exception as e:
            self.logger.error(f"Benchmark failed: {str(e)}", exc_info=True)
            return self._create_result(
                metrics={},
                parameters=parameters,
                details={},
                start_time=start_time,
                end_time=datetime.now(),
                error=str(e)
            )

    async def cleanup(self):
        """清理测试资源"""
        pass

    async def _worker(self, duration: int, operations: List[int], errors: int):
        """工作协程"""
        end_time = asyncio.get_event_loop().time() + duration
        batch_size = 0
        
        while asyncio.get_event_loop().time() < end_time:
            try:
                await self.target_func()
                batch_size += 1
            except Exception as e:
                errors += 1
                self.logger.error(f"Operation failed: {str(e)}", exc_info=True)
                
            # 每秒记录一次批次大小
            if asyncio.get_event_loop().time() % 1 < 0.1:
                if batch_size > 0:
                    operations.append(batch_size)
                batch_size = 0

    def _calculate_distribution(self, operations: List[int]
                              ) -> Dict[str, int]:
        """计算操作分布"""
        distribution = {}
        buckets = [10, 50, 100, 500, 1000, 5000, 10000]
        
        for ops in operations:
            bucket = next((b for b in buckets if ops <= b), '>10000')
            distribution[str(bucket)] = distribution.get(str(bucket), 0) + 1
            
        return distribution
