from typing import Dict, Any, List
from datetime import datetime
import asyncio
import statistics
from benchmarks.base_benchmark import BaseBenchmark, BenchmarkResult

class LatencyBenchmark(BaseBenchmark):
    """延迟基准测试"""
    def __init__(self, logger, target_func, name: str = "latency_benchmark"):
        super().__init__(logger, name)
        self.target_func = target_func
        self.warmup_rounds = 5

    async def setup(self):
        """预热测试"""
        self.logger.info(f"Warming up {self.name}")
        for _ in range(self.warmup_rounds):
            await self.target_func()

    async def run(self, parameters: Dict[str, Any]) -> BenchmarkResult:
        """执行延迟测试"""
        rounds = parameters.get('rounds', 100)
        self.logger.info(f"Starting {self.name} with {rounds} rounds")
        
        start_time = datetime.now()
        latencies = []
        errors = 0
        
        try:
            for i in range(rounds):
                round_start = asyncio.get_event_loop().time()
                try:
                    await self.target_func()
                    latency = (asyncio.get_event_loop().time() - round_start) * 1000
                    latencies.append(latency)
                except Exception as e:
                    errors += 1
                    self.logger.error(
                        f"Error in round {i}: {str(e)}",
                        exc_info=True
                    )
                    
            end_time = datetime.now()
            
            # 计算统计指标
            metrics = {
                'min_latency': min(latencies),
                'max_latency': max(latencies),
                'avg_latency': statistics.mean(latencies),
                'median_latency': statistics.median(latencies),
                'p95_latency': self._percentile(latencies, 95),
                'p99_latency': self._percentile(latencies, 99),
                'std_dev': statistics.stdev(latencies),
                'error_rate': errors / rounds
            }
            
            details = {
                'total_rounds': rounds,
                'successful_rounds': rounds - errors,
                'failed_rounds': errors,
                'latency_distribution': self._calculate_distribution(latencies)
            }
            
            return self._create_result(
                metrics=metrics,
                parameters=parameters,
                details=details,
                start_time=start_time,
                end_time=end_time
            )
            
        except Exception as e:
            self.logger.error(f"Benchmark failed: {str(e)}", exc_info=True)
            return self._create_result(
                metrics={},
                parameters=parameters,
                details={},
                start_time=start_time,
                end_time=datetime.now(),
                error=str(e)
            )

    async def cleanup(self):
        """清理测试资源"""
        pass

    def _percentile(self, data: List[float], percentile: float) -> float:
        """计算百分位数"""
        sorted_data = sorted(data)
        index = (len(sorted_data) - 1) * percentile / 100
        floor = int(index)
        ceil = min(floor + 1, len(sorted_data) - 1)
        if floor == ceil:
            return sorted_data[floor]
        d0 = sorted_data[floor] * (ceil - index)
        d1 = sorted_data[ceil] * (index - floor)
        return d0 + d1

    def _calculate_distribution(self, latencies: List[float]
                              ) -> Dict[str, int]:
        """计算延迟分布"""
        distribution = {}
        buckets = [1, 5, 10, 25, 50, 100, 250, 500, 1000]
        
        for latency in latencies:
            bucket = next((b for b in buckets if latency <= b), '>1000')
            distribution[str(bucket)] = distribution.get(str(bucket), 0) + 1
            
        return distribution
