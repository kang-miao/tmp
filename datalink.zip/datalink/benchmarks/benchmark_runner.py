from typing import Dict, Any, List, Type
import asyncio
from datetime import datetime
import json
from logging import Logger
from benchmarks.base_benchmark import BaseBenchmark, BenchmarkResult

class BenchmarkRunner:
    """基准测试运行器"""
    def __init__(self, logger: Logger):
        self.logger = logger
        self.benchmarks: Dict[str, BaseBenchmark] = {}
        self.results: List[BenchmarkResult] = []

    def register_benchmark(self, benchmark: BaseBenchmark):
        """注册基准测试"""
        self.benchmarks[benchmark.name] = benchmark
        self.logger.info(f"Registered benchmark: {benchmark.name}")

    async def run_benchmark(self, name: str, parameters: Dict[str, Any]
                          ) -> BenchmarkResult:
        """运行单个基准测试"""
        if name not in self.benchmarks:
            raise ValueError(f"Benchmark not found: {name}")
            
        benchmark = self.benchmarks[name]
        self.logger.info(f"Starting benchmark: {name}")
        
        try:
            # 准备测试
            await benchmark.setup()
            
            # 执行测试
            result = await benchmark.run(parameters)
            self.results.append(result)
            
            # 清理测试
            await benchmark.cleanup()
            
            self.logger.info(
                f"Benchmark {name} completed",
                extra={'metrics': result.metrics}
            )
            
            return result
            
        except Exception as e:
            self.logger.error(
                f"Benchmark {name} failed: {str(e)}",
                exc_info=True
            )
            raise

    async def run_all(self, parameters: Dict[str, Dict[str, Any]]
                     ) -> List[BenchmarkResult]:
        """运行所有基准测试"""
        results = []
        for name, params in parameters.items():
            try:
                result = await self.run_benchmark(name, params)
                results.append(result)
            except Exception as e:
                self.logger.error(
                    f"Failed to run benchmark {name}: {str(e)}",
                    exc_info=True
                )
        return results

    def export_results(self, format: str = 'json') -> str:
        """导出测试结果"""
        if format == 'json':
            return self._export_json()
        else:
            raise ValueError(f"Unsupported format: {format}")

    def _export_json(self) -> str:
        """导出JSON格式结果"""
        results_data = []
        for result in self.results:
            results_data.append({
                'name': result.name,
                'start_time': result.start_time.isoformat(),
                'end_time': result.end_time.isoformat(),
                'duration': (
                    result.end_time - result.start_time
                ).total_seconds(),
                'metrics': result.metrics,
                'parameters': result.parameters,
                'details': result.details,
                'error': result.error
            })
        return json.dumps(results_data, indent=2)
