from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime
import asyncio
from logging import Logger

@dataclass
class BenchmarkResult:
    """基准测试结果"""
    name: str
    start_time: datetime
    end_time: datetime
    metrics: Dict[str, float]
    parameters: Dict[str, Any]
    details: Dict[str, Any]
    error: Optional[str] = None

class BaseBenchmark(ABC):
    """基准测试基类"""
    def __init__(self, logger: Logger, name: str):
        self.logger = logger
        self.name = name
        self.results: List[BenchmarkResult] = []

    @abstractmethod
    async def setup(self):
        """测试准备"""
        pass

    @abstractmethod
    async def run(self, parameters: Dict[str, Any]) -> BenchmarkResult:
        """执行测试"""
        pass

    @abstractmethod
    async def cleanup(self):
        """测试清理"""
        pass

    def _create_result(self,
                      metrics: Dict[str, float],
                      parameters: Dict[str, Any],
                      details: Dict[str, Any],
                      start_time: datetime,
                      end_time: datetime,
                      error: Optional[str] = None) -> BenchmarkResult:
        """创建测试结果"""
        result = BenchmarkResult(
            name=self.name,
            start_time=start_time,
            end_time=end_time,
            metrics=metrics,
            parameters=parameters,
            details=details,
            error=error
        )
        self.results.append(result)
        return result
