from typing import Dict, Any, List, Optional, Callable
import asyncio
from datetime import datetime
from logging import Logger
import aioredis
import asyncpg

class DataWarmer:
    """数据预热器"""
    def __init__(self, logger: Logger,
                 cache_manager: 'CacheManager',
                 db_pool: asyncpg.Pool):
        self.logger = logger
        self.cache_manager = cache_manager
        self.db_pool = db_pool
        self.warmup_tasks: Dict[str, Callable] = {}
        self._running = False
        self._task: Optional[asyncio.Task] = None

    def register_task(self, name: str, task: Callable):
        """注册预热任务"""
        self.warmup_tasks[name] = task
        self.logger.info(f"Registered warmup task: {name}")

    async def start(self):
        """启动预热器"""
        self._running = True
        self._task = asyncio.create_task(self._warmup_loop())
        self.logger.info("Data warmer started")

    async def stop(self):
        """停止预热器"""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self.logger.info("Data warmer stopped")

    async def warmup(self, task_name: Optional[str] = None):
        """执行预热"""
        try:
            if task_name:
                if task_name not in self.warmup_tasks:
                    raise ValueError(f"Task not found: {task_name}")
                await self._execute_task(task_name)
            else:
                # 执行所有预热任务
                for name in self.warmup_tasks:
                    await self._execute_task(name)
                    
        except Exception as e:
            self.logger.error(
                f"Warmup error: {str(e)}",
                exc_info=True
            )
            raise

    async def _warmup_loop(self):
        """预热循环"""
        try:
            while self._running:
                await self.warmup()
                await asyncio.sleep(3600)  # 每小时预热一次
        except asyncio.CancelledError:
            pass
        except Exception as e:
            self.logger.error(
                f"Warmup loop error: {str(e)}",
                exc_info=True
            )

    async def _execute_task(self, name: str):
        """执行预热任务"""
        start_time = datetime.now()
        task = self.warmup_tasks[name]
        
        try:
            await task(self.cache_manager, self.db_pool)
            duration = (datetime.now() - start_time).total_seconds()
            
            self.logger.info(
                f"Completed warmup task {name} in {duration:.2f}s"
            )
            
        except Exception as e:
            self.logger.error(
                f"Error in warmup task {name}: {str(e)}",
                exc_info=True
            )

class CommonWarmupTasks:
    """常用预热任务"""
    @staticmethod
    async def warm_user_data(cache_manager: 'CacheManager',
                            db_pool: asyncpg.Pool):
        """预热用户数据"""
        async with db_pool.acquire() as conn:
            users = await conn.fetch(
                """
                SELECT id, username, email, last_login
                FROM users
                WHERE last_login > NOW() - INTERVAL '7 days'
                """
            )
            
            for user in users:
                key = f"user:{user['id']}"
                await cache_manager.set(
                    key,
                    dict(user),
                    expire=3600
                )

    @staticmethod
    async def warm_config_data(cache_manager: 'CacheManager',
                             db_pool: asyncpg.Pool):
        """预热配置数据"""
        async with db_pool.acquire() as conn:
            configs = await conn.fetch(
                """
                SELECT key, value, updated_at
                FROM system_configs
                WHERE is_active = true
                """
            )
            
            for config in configs:
                key = f"config:{config['key']}"
                await cache_manager.set(
                    key,
                    config['value'],
                    expire=3600
                )

    @staticmethod
    async def warm_statistics(cache_manager: 'CacheManager',
                            db_pool: asyncpg.Pool):
        """预热统计数据"""
        async with db_pool.acquire() as conn:
            # 用户统计
            user_stats = await conn.fetchrow(
                """
                SELECT 
                    COUNT(*) as total_users,
                    COUNT(CASE WHEN last_login > NOW() - INTERVAL '24 hours'
                          THEN 1 END) as active_users
                FROM users
                """
            )
            
            await cache_manager.set(
                'stats:users',
                dict(user_stats),
                expire=1800
            )
            
            # 系统统计
            system_stats = await conn.fetchrow(
                """
                SELECT 
                    COUNT(*) as total_records,
                    MAX(created_at) as last_record
                FROM system_logs
                WHERE created_at > NOW() - INTERVAL '24 hours'
                """
            )
            
            await cache_manager.set(
                'stats:system',
                dict(system_stats),
                expire=1800
            )
