from typing import Dict, Any, List, Optional, TypeVar, Generic
import asyncio
from datetime import datetime
from logging import Logger
from collections import deque
import ujson  # 比json更快的JSON处理库

T = TypeVar('T')

class DataBatch(Generic[T]):
    """数据批处理"""
    def __init__(self, max_size: int = 1000,
                 max_wait: float = 1.0):
        self.max_size = max_size
        self.max_wait = max_wait
        self.items: deque[T] = deque()
        self.last_flush: datetime = datetime.now()
        self._lock = asyncio.Lock()

    async def add(self, item: T) -> bool:
        """添加数据项"""
        async with self._lock:
            self.items.append(item)
            return len(self.items) >= self.max_size

    async def should_flush(self) -> bool:
        """检查是否应该刷新"""
        if not self.items:
            return False
            
        async with self._lock:
            return (
                len(self.items) >= self.max_size or
                (datetime.now() - self.last_flush).total_seconds() >= self.max_wait
            )

    async def flush(self) -> List[T]:
        """刷新数据"""
        async with self._lock:
            items = list(self.items)
            self.items.clear()
            self.last_flush = datetime.now()
            return items

class DataProcessor:
    """数据处理器"""
    def __init__(self, logger: Logger):
        self.logger = logger
        self.batches: Dict[str, DataBatch] = {}
        self.processors: Dict[str, callable] = {}
        self._running = False
        self._tasks: List[asyncio.Task] = []

    async def start(self):
        """启动处理器"""
        self._running = True
        self._tasks = [
            asyncio.create_task(self._process_batch(name))
            for name in self.batches.keys()
        ]
        self.logger.info("Data processor started")

    async def stop(self):
        """停止处理器"""
        self._running = False
        for task in self._tasks:
            task.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        self.logger.info("Data processor stopped")

    def register_batch(self, name: str, max_size: int = 1000,
                      max_wait: float = 1.0):
        """注册批处理"""
        self.batches[name] = DataBatch(max_size, max_wait)
        self.logger.info(f"Registered batch processor: {name}")

    def register_processor(self, name: str, processor: callable):
        """注册处理器"""
        self.processors[name] = processor
        self.logger.info(f"Registered data processor: {name}")

    async def process(self, name: str, data: Any):
        """处理数据"""
        if name not in self.batches:
            raise ValueError(f"Batch not found: {name}")
            
        batch = self.batches[name]
        should_flush = await batch.add(data)
        
        if should_flush:
            await self._flush_batch(name)

    async def _process_batch(self, name: str):
        """批处理循环"""
        try:
            while self._running:
                batch = self.batches[name]
                if await batch.should_flush():
                    await self._flush_batch(name)
                await asyncio.sleep(0.1)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            self.logger.error(
                f"Error in batch processor {name}: {str(e)}",
                exc_info=True
            )

    async def _flush_batch(self, name: str):
        """刷新批处理"""
        try:
            batch = self.batches[name]
            items = await batch.flush()
            
            if items and name in self.processors:
                processor = self.processors[name]
                await processor(items)
                
        except Exception as e:
            self.logger.error(
                f"Error flushing batch {name}: {str(e)}",
                exc_info=True
            )
