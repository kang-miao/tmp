from typing import Dict, Any, Optional, List, Union
import asyncio
from datetime import datetime, timedelta
from logging import Logger
import ujson
import aioredis
from collections import OrderedDict

class LocalCache:
    """本地缓存"""
    def __init__(self, max_size: int = 1000):
        self.max_size = max_size
        self.cache: OrderedDict = OrderedDict()
        self._lock = asyncio.Lock()

    async def get(self, key: str) -> Optional[Any]:
        """获取缓存"""
        async with self._lock:
            if key in self.cache:
                value = self.cache.pop(key)
                self.cache[key] = value  # 移动到最后（LRU）
                return value
            return None

    async def set(self, key: str, value: Any):
        """设置缓存"""
        async with self._lock:
            if key in self.cache:
                self.cache.pop(key)
            elif len(self.cache) >= self.max_size:
                self.cache.popitem(last=False)  # 移除最早的项
            self.cache[key] = value

    async def delete(self, key: str):
        """删除缓存"""
        async with self._lock:
            self.cache.pop(key, None)

    async def clear(self):
        """清空缓存"""
        async with self._lock:
            self.cache.clear()

class CacheManager:
    """缓存管理器"""
    def __init__(self, logger: Logger,
                 redis_config: Dict[str, Any],
                 local_cache_size: int = 1000):
        self.logger = logger
        self.redis_config = redis_config
        self.local_cache = LocalCache(local_cache_size)
        self.redis: Optional[aioredis.Redis] = None
        self._lock = asyncio.Lock()

    async def start(self):
        """启动缓存管理器"""
        self.redis = await aioredis.create_redis_pool(**self.redis_config)
        self.logger.info("Cache manager started")

    async def stop(self):
        """停止缓存管理器"""
        if self.redis:
            self.redis.close()
            await self.redis.wait_closed()
        self.logger.info("Cache manager stopped")

    async def get(self, key: str,
                 use_local: bool = True) -> Optional[Any]:
        """获取缓存"""
        # 先检查本地缓存
        if use_local:
            local_value = await self.local_cache.get(key)
            if local_value is not None:
                return ujson.loads(local_value)

        # 检查Redis缓存
        if self.redis:
            try:
                value = await self.redis.get(key)
                if value:
                    if use_local:
                        await self.local_cache.set(key, value)
                    return ujson.loads(value)
            except Exception as e:
                self.logger.error(
                    f"Redis get error: {str(e)}",
                    exc_info=True
                )

        return None

    async def set(self, key: str, value: Any,
                 expire: Optional[int] = None,
                 use_local: bool = True):
        """设置缓存"""
        json_value = ujson.dumps(value)

        # 设置本地缓存
        if use_local:
            await self.local_cache.set(key, json_value)

        # 设置Redis缓存
        if self.redis:
            try:
                if expire:
                    await self.redis.setex(key, expire, json_value)
                else:
                    await self.redis.set(key, json_value)
            except Exception as e:
                self.logger.error(
                    f"Redis set error: {str(e)}",
                    exc_info=True
                )

    async def delete(self, key: str, use_local: bool = True):
        """删除缓存"""
        # 删除本地缓存
        if use_local:
            await self.local_cache.delete(key)

        # 删除Redis缓存
        if self.redis:
            try:
                await self.redis.delete(key)
            except Exception as e:
                self.logger.error(
                    f"Redis delete error: {str(e)}",
                    exc_info=True
                )

    async def clear(self, use_local: bool = True):
        """清空缓存"""
        # 清空本地缓存
        if use_local:
            await self.local_cache.clear()

        # 清空Redis缓存
        if self.redis:
            try:
                await self.redis.flushdb()
            except Exception as e:
                self.logger.error(
                    f"Redis clear error: {str(e)}",
                    exc_info=True
                )
