# core/data_source.py

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List
from datetime import datetime
import logging
import asyncio
from dataclasses import dataclass

@dataclass
class ConnectionStatus:
    """连接状态数据类"""
    is_connected: bool
    last_connected: Optional[datetime]
    last_error: Optional[str]
    retry_count: int
    message_count: int
    error_count: int

class DataSource(ABC):
    """数据源抽象基类
    
    为所有市场数据适配器提供统一的接口规范，定义了数据源必须实现的方法。
    包含连接管理、数据订阅、错误处理等基本功能。
    """

    def __init__(self, config: Dict[str, Any]):
        """初始化数据源
        
        Args:
            config: 数据源配置字典，包含连接参数和订阅设置
        """
        self.config = config
        self.logger = logging.getLogger(f"data_source.{self.__class__.__name__}")
        self.status = ConnectionStatus(
            is_connected=False,
            last_connected=None,
            last_error=None,
            retry_count=0,
            message_count=0,
            error_count=0
        )
        self._stop_event = asyncio.Event()

    @abstractmethod
    async def connect(self) -> bool:
        """建立与数据源的连接
        
        Returns:
            bool: 连接是否成功
        """
        pass

    @abstractmethod
    async def disconnect(self) -> None:
        """断开与数据源的连接"""
        pass

    @abstractmethod
    async def subscribe(self, symbols: List[str], channels: List[str]) -> bool:
        """订阅指定交易对的指定数据类型
        
        Args:
            symbols: 交易对列表
            channels: 数据类型列表 (如 trades, order_book, kline)
            
        Returns:
            bool: 订阅是否成功
        """
        pass

    @abstractmethod
    async def unsubscribe(self, symbols: List[str], channels: List[str]) -> bool:
        """取消订阅指定交易对的指定数据类型
        
        Args:
            symbols: 交易对列表
            channels: 数据类型列表
            
        Returns:
            bool: 取消订阅是否成功
        """
        pass

    async def handle_message(self, message: Dict[str, Any]) -> None:
        """处理接收到的数据消息
        
        Args:
            message: 接收到的数据消息
        """
        try:
            self.status.message_count += 1
            await self._process_message(message)
        except Exception as e:
            self.status.error_count += 1
            self.logger.error(f"Error processing message: {e}", exc_info=True)
            await self.handle_error(e)

    @abstractmethod
    async def _process_message(self, message: Dict[str, Any]) -> None:
        """具体的消息处理逻辑，由子类实现
        
        Args:
            message: 接收到的数据消息
        """
        pass

    async def handle_error(self, error: Exception) -> None:
        """错误处理
        
        Args:
            error: 捕获到的异常
        """
        self.status.last_error = str(error)
        self.logger.error(f"Error in data source: {error}", exc_info=True)
        if self._should_reconnect(error):
            await self._attempt_reconnect()

    async def _attempt_reconnect(self) -> None:
        """重连逻辑"""
        self.status.retry_count += 1
        max_retries = self.config.get('max_retries', 3)
        retry_delay = self.config.get('retry_delay', 5)

        if self.status.retry_count <= max_retries:
            self.logger.info(f"Attempting reconnection {self.status.retry_count}/{max_retries}")
            await asyncio.sleep(retry_delay)
            try:
                if await self.connect():
                    self.status.retry_count = 0
                    self.logger.info("Reconnection successful")
            except Exception as e:
                self.logger.error(f"Reconnection failed: {e}", exc_info=True)
        else:
            self.logger.error("Max retry attempts reached")
            await self.stop()

    def _should_reconnect(self, error: Exception) -> bool:
        """判断是否应该进行重连
        
        Args:
            error: 捕获到的异常
            
        Returns:
            bool: 是否应该重连
        """
        # 可以根据具体的错误类型来决定是否重连
        return True

    async def start(self) -> None:
        """启动数据源"""
        self.logger.info("Starting data source")
        self._stop_event.clear()
        if await self.connect():
            self.status.is_connected = True
            self.status.last_connected = datetime.now()
        else:
            self.logger.error("Failed to start data source")
            raise ConnectionError("Could not connect to data source")

    async def stop(self) -> None:
        """停止数据源"""
        self.logger.info("Stopping data source")
        self._stop_event.set()
        await self.disconnect()
        self.status.is_connected = False

    async def health_check(self) -> Dict[str, Any]:
        """健康检查
        
        Returns:
            Dict[str, Any]: 健康状态信息
        """
        return {
            "is_connected": self.status.is_connected,
            "last_connected": self.status.last_connected,
            "last_error": self.status.last_error,
            "retry_count": self.status.retry_count,
            "message_count": self.status.message_count,
            "error_count": self.status.error_count,
            "error_rate": self.status.error_count / self.status.message_count if self.status.message_count > 0 else 0
        }

    def __repr__(self) -> str:
        """返回数据源的字符串表示"""
        return f"{self.__class__.__name__}(connected={self.status.is_connected})"