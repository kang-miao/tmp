# core/data_link.py

import asyncio
import logging
from typing import Dict, Any, List, Optional, Set
from datetime import datetime, timedelta
import json

from adapters.base.base_adapter import BaseAdapter
from adapters.crypto.binance_adapter import BinanceAdapter
from core.market_data import MarketType, DataType
from monitor.data_monitor import DataMonitor
from storage.connectors.keydb_connector import KeyDBConnector
from storage.connectors.redpanda_connector import RedpandaConnector
from storage.connectors.risingwave_connector import RisingWaveConnector
from storage.connectors.tdengine_connector import TDengineConnector
from storage.connectors.minio_connector import MinIOConnector
from utils.config_loader import ConfigLoader
from utils.error_handler import enhanced_error_handler, RetryStrategy
from utils.error_handler import ErrorHandler
from validators.market_validator import MarketDataValidator
from monitor.performance_monitor import PerformanceMonitor
from monitor.latency_monitor import LatencyMonitor
from consistency.data_checker import DataConsistencyChecker, ConsistencyCheckResult

class DataLink:
    """DataLink核心控制组件
    
    负责协调数据流、管理适配器和存储连接器，具体功能包括：
    - 适配器生命周期管理
    - 数据流路由和分发
    - 存储系统协调
    - 系统状态监控
    """

    def __init__(self, config_path: str = 'config/settings.py'):
        """初始化DataLink
        
        Args:
            config_path: 配置文件路径
        """
        self.logger = logging.getLogger("core.datalink")
        self.config = ConfigLoader(config_path).load_config()
        
        # 初始化监控器
        self.monitor = DataMonitor()
        
        # 适配器管理
        self.adapters: Dict[str, BaseAdapter] = {}
        self.active_subscriptions: Dict[str, Set[str]] = {}
        
        # 存储连接器
        self.storage = {
            'keydb': KeyDBConnector(self.config['KEYDB_CONFIG']),
            'redpanda': RedpandaConnector(self.config['REDPANDA_CONFIG']),
            'risingwave': RisingWaveConnector(self.config['RISINGWAVE_CONFIG']),
            'tdengine': TDengineConnector(self.config['TDENGINE_CONFIG']),
            'minio': MinIOConnector(self.config['MINIO_CONFIG'])
        }
        
        # 运行状态
        self.is_running = False
        self._stop_event = asyncio.Event()

        self.error_handler = ErrorHandler()
        self.retry_strategy = RetryStrategy(
            max_retries=self.config.get('max_retries', 3),
            backoff_factor=self.config.get('backoff_factor', 1.5),
            max_delay=self.config.get('max_delay', 30.0)
        )

        self.validator = MarketDataValidator()

        self.performance_monitor = PerformanceMonitor()
        self.latency_monitor = LatencyMonitor()

        self.consistency_checker = DataConsistencyChecker(self.storage)

    async def initialize(self) -> bool:
        """初始化系统组件
        
        Returns:
            bool: 初始化是否成功
        """
        try:
            # 检查存储连接
            connection_status = await self._check_storage_connections()
            if not all(connection_status.values()):
                self.logger.error("Storage connection check failed")
                return False
            
            # 初始化存储结构
            await self.storage['tdengine'].init_database()
            await self.storage['minio'].init_buckets()
            
            # 创建Redpanda topics
            market_topics = [
                'trades.raw', 'trades.processed',
                'orderbooks.raw', 'orderbooks.processed',
                'klines.1m'
            ]
            await self.storage['redpanda'].create_topics(market_topics)
            
            # 创建RisingWave视图
            await self.storage['risingwave'].create_materialized_view('minute_klines')
            await self.storage['risingwave'].create_materialized_view('market_depth')
            
            # 初始化适配器
            self._initialize_adapters()
            
            return True
        except Exception as e:
            self.logger.error(f"Initialization error: {e}")
            return False

    async def _check_storage_connections(self) -> Dict[str, bool]:
        """检查所有存储连接状态
        
        Returns:
            Dict[str, bool]: 各存储连接的状态
        """
        status = {}
        for name, connector in self.storage.items():
            status[name] = await connector.check_connection()
            self.logger.info(f"Storage connection status - {name}: {status[name]}")
        return status

    def _initialize_adapters(self) -> None:
        """初始化市场数据适配器"""
        try:
            # 加载加密货币适配器
            crypto_config = self.config['DATA_SOURCES']['crypto']
            if 'Binance' in crypto_config['exchanges']:
                self.adapters['binance'] = BinanceAdapter(
                    config=crypto_config,
                    callbacks={
                        DataType.TRADE: self._handle_trade,
                        DataType.ORDER_BOOK: self._handle_order_book,
                        DataType.KLINE: self._handle_kline
                    }
                )
            
            # TODO: 初始化其他交易所适配器
            
        except Exception as e:
            self.logger.error(f"Error initializing adapters: {e}")

    async def start(self) -> None:
        """启动DataLink系统"""
        try:
            self.logger.info("Starting DataLink system")
            
            # 初始化系统
            if not await self.initialize():
                raise RuntimeError("System initialization failed")
            
            # 启动监控
            self.monitor.start_monitoring()
            
            # 启动适配器
            for name, adapter in self.adapters.items():
                self.logger.info(f"Starting adapter: {name}")
                await adapter.start()
            
            self.is_running = True
            self._stop_event.clear()
            
            # 启动主循环
            await self._main_loop()
            
        except Exception as e:
            self.logger.error(f"Error starting system: {e}")
            await self.stop()

    async def stop(self) -> None:
        """停止DataLink系统"""
        try:
            self.logger.info("Stopping DataLink system")
            
            # 设置停止标志
            self.is_running = False
            self._stop_event.set()
            
            # 停止适配器
            for name, adapter in self.adapters.items():
                self.logger.info(f"Stopping adapter: {name}")
                await adapter.stop()
            
            # 停止监控
            self.monitor.stop_monitoring()
            
            # 关闭存储连接
            for connector in self.storage.values():
                await connector.close()
            
        except Exception as e:
            self.logger.error(f"Error stopping system: {e}")

    async def _main_loop(self) -> None:
        """主循环处理"""
        while self.is_running:
            try:
                # 检查存储连接状态
                connection_status = await self._check_storage_connections()
                if not all(connection_status.values()):
                    self.logger.warning("Some storage connections are down")
                
                # 执行定期任务
                await self._periodic_tasks()
                
                # 等待一段时间
                await asyncio.sleep(60)  # 1分钟检查一次
                
            except Exception as e:
                self.logger.error(f"Error in main loop: {e}")
                await asyncio.sleep(5)  # 错误发生时等待较短时间

    async def _periodic_tasks(self) -> None:
        """执行定期任务"""
        try:
            # 清理过期数据
            await self.storage['minio'].cleanup_expired_data()
            
            # 获取存储统计
            stats = await self.storage['minio'].get_storage_stats()
            self.logger.info(f"Storage stats: {json.dumps(stats, indent=2)}")
            
            # 检查处理延迟
            lag = await self.storage['risingwave'].monitor_processing_lag()
            self.logger.info(f"Processing lag: {json.dumps(lag, indent=2)}")
            
        except Exception as e:
            self.logger.error(f"Error in periodic tasks: {e}")

    async def _handle_trade(self, trade_data: Dict[str, Any]) -> None:
        """处理交易数据
        
        Args:
            trade_data: 交易数据
        """
        try:
            # 更新监控统计
            self.monitor.update_stats(
                f"trade_{trade_data['exchange']}_{trade_data['symbol']}",
                len(json.dumps(trade_data))
            )
            
            # 发布到Redpanda
            await self.storage['redpanda'].publish_message(
                'trades.raw',
                trade_data,
                key=f"{trade_data['exchange']}_{trade_data['symbol']}"
            )
            
            # 写入TDengine
            await self.storage['tdengine'].insert_trade(trade_data)
            
        except Exception as e:
            self.logger.error(f"Error handling trade data: {e}")

    @enhanced_error_handler('DataLink')
    async def _handle_order_book(self, order_book_data: Dict[str, Any]) -> None:
        """处理订单簿数据"""
        operation_id = f"orderbook_{order_book_data['exchange']}_{order_book_data['symbol']}"
        self.latency_monitor.start_operation(operation_id)
        
        try:
            # 添加数据验证
            validation_result = await self.validator.validate({
                **order_book_data,
                'type': 'orderbook'
            })
            
            if not validation_result.is_valid:
                self.logger.error(
                    f"Invalid orderbook data: {validation_result.errors}"
                )
                if validation_result.warnings:
                    self.logger.warning(
                        f"Orderbook warnings: {validation_result.warnings}"
                    )
                raise ValidationError(
                    f"Invalid orderbook data: {validation_result.errors}"
                )

            # 更新监控统计
            self.monitor.update_stats(
                f"orderbook_{order_book_data['exchange']}_{order_book_data['symbol']}",
                len(json.dumps(order_book_data)),
                metadata=validation_result.metadata
            )
            
            # 更新KeyDB缓存
            await self.storage['keydb'].update_order_book(
                order_book_data['exchange'],
                order_book_data['symbol'],
                order_book_data['bids'],
                order_book_data['asks'],
                order_book_data['timestamp']
            )
            
            # 发布到Redpanda
            await self.storage['redpanda'].publish_message(
                'orderbooks.raw',
                order_book_data,
                key=f"{order_book_data['exchange']}_{order_book_data['symbol']}"
            )
            
        except Exception as e:
            self.error_handler.handle_error(
                e,
                'DataLink._handle_order_book',
                {
                    'order_book_data': order_book_data,
                    'validation_result': validation_result
                }
            )
            raise

        finally:
            self.latency_monitor.end_operation(
                operation_id,
                {
                    'type': 'orderbook',
                    'exchange': order_book_data['exchange'],
                    'symbol': order_book_data['symbol']
                }
            )

    @enhanced_error_handler('DataLink')
    async def _handle_kline(self, kline_data: Dict[str, Any]) -> None:
        """处理K线数据"""
        # 添加数据验证
        validation_result = await self.validator.validate({
            **kline_data,
            'type': 'kline'
        })
        
        if not validation_result.is_valid:
            self.logger.error(
                f"Invalid kline data: {validation_result.errors}"
            )
            if validation_result.warnings:
                self.logger.warning(
                    f"Kline warnings: {validation_result.warnings}"
                )
            raise ValidationError(
                f"Invalid kline data: {validation_result.errors}"
            )

        try:
            # 更新监控统计
            self.monitor.update_stats(
                f"kline_{kline_data['exchange']}_{kline_data['symbol']}",
                len(json.dumps(kline_data)),
                metadata=validation_result.metadata
            )
            
            # 写入TDengine
            await self.storage['tdengine'].insert_kline(kline_data)
            
            # 发布到Redpanda
            await self.storage['redpanda'].publish_message(
                'klines.1m',
                kline_data,
                key=f"{kline_data['exchange']}_{kline_data['symbol']}"
            )
            
        except Exception as e:
            self.error_handler.handle_error(
                e,
                'DataLink._handle_kline',
                {
                    'kline_data': kline_data,
                    'validation_result': validation_result
                }
            )
            raise

    async def subscribe(self, market_type: str, exchange: str,
                       symbols: List[str], channels: List[str]) -> bool:
        """订阅市场数据
        
        Args:
            market_type: 市场类型
            exchange: 交易所
            symbols: 交易对列表
            channels: 数据类型列表
            
        Returns:
            bool: 订阅是否成功
        """
        try:
            adapter = self._get_adapter(market_type, exchange)
            if not adapter:
                raise ValueError(f"No adapter found for {market_type}/{exchange}")
            
            # 执行订阅
            success = await adapter.subscribe(symbols, channels)
            if success:
                # 更新订阅记录
                key = f"{market_type}_{exchange}"
                if key not in self.active_subscriptions:
                    self.active_subscriptions[key] = set()
                self.active_subscriptions[key].update(symbols)
                
                self.logger.info(f"Subscribed to {exchange} {symbols} {channels}")
            return success
            
        except Exception as e:
            self.logger.error(f"Error subscribing to market data: {e}")
            return False

    def _get_adapter(self, market_type: str, exchange: str) -> Optional[BaseAdapter]:
        """获取适配器实例
        
        Args:
            market_type: 市场类型
            exchange: 交易所
            
        Returns:
            Optional[BaseAdapter]: 适配器实例
        """
        adapter_key = exchange.lower()
        return self.adapters.get(adapter_key)

    async def get_system_status(self) -> Dict[str, Any]:
        """获取系统状态信息
        
        Returns:
            Dict[str, Any]: 系统状态信息
        """
        status = {
            'is_running': self.is_running,
            'adapters': {},
            'storage': {},
            'subscriptions': dict(self.active_subscriptions),
            'monitor': await self.monitor.get_stats()
        }
        
        # 获取适配器状态
        for name, adapter in self.adapters.items():
            status['adapters'][name] = await adapter.health_check()
        
        # 获取存储状态
        for name, connector in self.storage.items():
            status['storage'][name] = await connector.check_connection()
        
        return status

    async def get_error_stats(self) -> Dict[str, Any]:
        """获取错误统计信息"""
        return self.error_handler.get_error_stats()

    async def get_monitoring_stats(self) -> Dict[str, Any]:
        """获取监控统计信息"""
        return {
            'performance': await self.performance_monitor.get_performance_report(),
            'latency': {
                'orderbook': self.latency_monitor.get_latency_stats('orderbook'),
                'trade': self.latency_monitor.get_latency_stats('trade'),
                'kline': self.latency_monitor.get_latency_stats('kline')
            },
            'resource_usage': self.performance_monitor.get_resource_usage()
        }

    async def check_data_consistency(self,
                                   market_type: str,
                                   exchange: str,
                                   symbol: str,
                                   time_window: timedelta = timedelta(minutes=5)
                                   ) -> ConsistencyCheckResult:
        """检查数据一致性"""
        end_time = datetime.now()
        start_time = end_time - time_window
        
        return await self.consistency_checker.check_consistency(
            market_type=market_type,
            exchange=exchange,
            symbol=symbol,
            start_time=start_time,
            end_time=end_time
        )
    
    async def get_consistency_stats(self) -> Dict[str, Any]:
        """获取一致性检查统计信息"""
        return self.consistency_checker.get_consistency_stats()

if __name__ == "__main__":
    # 设置日志
    logging.basicConfig(level=logging.INFO)
    
    # 创建DataLink实例
    datalink = DataLink()
    
    # 运行
    try:
        asyncio.run(datalink.start())
    except KeyboardInterrupt:
        asyncio.run(datalink.stop())