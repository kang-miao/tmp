# core/market_data.py

from dataclasses import dataclass
from datetime import datetime
from typing import List, Dict, Optional, Union, Any
from enum import Enum

class MarketType(Enum):
    """市场类型枚举"""
    CRYPTO = "crypto"      # 加密货币市场
    STOCK_CN = "stock_cn"  # 中国股票市场
    STOCK_US = "stock_us"  # 美国股票市场
    STOCK_CA = "stock_ca"  # 加拿大股票市场
    FUTURES = "futures"    # 期货市场

class DataType(Enum):
    """数据类型枚举"""
    TRADE = "trade"           # 成交数据
    ORDER_BOOK = "order_book" # 订单簿数据
    KLINE = "kline"          # K线数据
    TICKER = "ticker"         # 24小时行情
    FUNDING = "funding"       # 资金费率（加密货币期货）

@dataclass
class BaseData:
    """基础数据类"""
    market_type: MarketType              # 市场类型
    exchange: str                        # 交易所
    symbol: str                          # 交易对/股票代码
    timestamp: datetime                  # 时间戳
    data_type: DataType                 # 数据类型
    source: str                         # 数据来源
    raw_data: Optional[Dict] = None     # 原始数据

@dataclass
class TradeData(BaseData):
    """交易数据类"""
    price: float                        # 成交价格
    volume: float                       # 成交数量
    amount: float                       # 成交金额
    trade_id: str                       # 成交ID
    side: str                          # 买卖方向
    is_maker: bool                     # 是否是挂单方

    def validate(self) -> bool:
        """验证交易数据的有效性"""
        return (
            self.price > 0 and
            self.volume > 0 and
            self.amount > 0 and
            self.trade_id != "" and
            self.side in ["buy", "sell"]
        )

@dataclass
class OrderBookLevel:
    """订单簿价格档位"""
    price: float                        # 价格
    volume: float                       # 数量
    count: Optional[int] = None         # 订单数量（如果有）

@dataclass
class OrderBookData(BaseData):
    """订单簿数据类"""
    bids: List[OrderBookLevel]          # 买单列表
    asks: List[OrderBookLevel]          # 卖单列表
    snapshot: bool                      # 是否为快照数据
    update_id: Optional[int] = None     # 更新ID

    def validate(self) -> bool:
        """验证订单簿数据的有效性"""
        if not self.bids or not self.asks:
            return False
        
        # 检查价格排序（买单降序，卖单升序）
        for i in range(1, len(self.bids)):
            if self.bids[i].price >= self.bids[i-1].price:
                return False
        
        for i in range(1, len(self.asks)):
            if self.asks[i].price <= self.asks[i-1].price:
                return False
        
        # 检查买卖价格交叉
        if self.bids[0].price >= self.asks[0].price:
            return False
        
        return True

    def get_mid_price(self) -> float:
        """获取中间价格"""
        if self.bids and self.asks:
            return (self.bids[0].price + self.asks[0].price) / 2
        return 0

    def get_spread(self) -> float:
        """获取买卖价差"""
        if self.bids and self.asks:
            return self.asks[0].price - self.bids[0].price
        return 0

@dataclass
class KlineData(BaseData):
    """K线数据类"""
    interval: str                       # K线周期
    open: float                         # 开盘价
    high: float                         # 最高价
    low: float                          # 最低价
    close: float                        # 收盘价
    volume: float                       # 成交量
    amount: float                       # 成交额
    trade_count: Optional[int] = None   # 成交笔数
    
    def validate(self) -> bool:
        """验证K线数据的有效性"""
        return (
            self.open > 0 and
            self.high > 0 and
            self.low > 0 and
            self.close > 0 and
            self.volume >= 0 and
            self.amount >= 0 and
            self.high >= self.low and
            self.high >= self.open and
            self.high >= self.close and
            self.low <= self.open and
            self.low <= self.close
        )

    def get_amplitude(self) -> float:
        """获取振幅"""
        if self.low > 0:
            return (self.high - self.low) / self.low * 100
        return 0

    def get_change_percent(self) -> float:
        """获取涨跌幅"""
        if self.open > 0:
            return (self.close - self.open) / self.open * 100
        return 0

class MarketDataFactory:
    """市场数据工厂类"""
    
    @staticmethod
    def create_trade(
        market_type: MarketType,
        exchange: str,
        symbol: str,
        timestamp: datetime,
        price: float,
        volume: float,
        amount: float,
        trade_id: str,
        side: str,
        is_maker: bool,
        source: str,
        raw_data: Optional[Dict] = None
    ) -> TradeData:
        """创建交易数据"""
        return TradeData(
            market_type=market_type,
            exchange=exchange,
            symbol=symbol,
            timestamp=timestamp,
            data_type=DataType.TRADE,
            source=source,
            raw_data=raw_data,
            price=price,
            volume=volume,
            amount=amount,
            trade_id=trade_id,
            side=side,
            is_maker=is_maker
        )

    @staticmethod
    def create_order_book(
        market_type: MarketType,
        exchange: str,
        symbol: str,
        timestamp: datetime,
        bids: List[OrderBookLevel],
        asks: List[OrderBookLevel],
        snapshot: bool,
        source: str,
        update_id: Optional[int] = None,
        raw_data: Optional[Dict] = None
    ) -> OrderBookData:
        """创建订单簿数据"""
        return OrderBookData(
            market_type=market_type,
            exchange=exchange,
            symbol=symbol,
            timestamp=timestamp,
            data_type=DataType.ORDER_BOOK,
            source=source,
            raw_data=raw_data,
            bids=bids,
            asks=asks,
            snapshot=snapshot,
            update_id=update_id
        )

    @staticmethod
    def create_kline(
        market_type: MarketType,
        exchange: str,
        symbol: str,
        timestamp: datetime,
        interval: str,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float,
        amount: float,
        source: str,
        trade_count: Optional[int] = None,
        raw_data: Optional[Dict] = None
    ) -> KlineData:
        """创建K线数据"""
        return KlineData(
            market_type=market_type,
            exchange=exchange,
            symbol=symbol,
            timestamp=timestamp,
            data_type=DataType.KLINE,
            source=source,
            raw_data=raw_data,
            interval=interval,
            open=open,
            high=high,
            low=low,
            close=close,
            volume=volume,
            amount=amount,
            trade_count=trade_count
        )